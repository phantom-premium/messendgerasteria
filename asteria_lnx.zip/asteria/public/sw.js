// Service Worker — единственное, что реально может показать уведомление,
// когда PWA полностью закрыт (ни одной открытой вкладки/окна нет). Браузер
// сам "будит" именно этот файл в фоне, когда с сервера приходит push (см.
// lib/webpush.js + pushNotifyConversation() в server.js), даже если само
// приложение никто не открывал последние часы — в этом весь смысл: не
// нужен постоянный WebSocket, как у Android-версии (AsteriaPushService).

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (e) {
    data = { title: 'Asteria', body: event.data ? event.data.text() : '' };
  }
  const title = data.title || 'Asteria';
  const options = {
    body: data.body || '',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    // tag + renotify: новое сообщение в ТОМ ЖЕ чате заменяет предыдущее
    // уведомление вместо того, чтобы копиться отдельной плашкой на каждое
    // сообщение (как это обычно ведёт себя Telegram/WhatsApp).
    tag: data.conversationId || undefined,
    renotify: !!data.conversationId,
    data: { url: data.url || '/', conversationId: data.conversationId || null },
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const conversationId = event.notification.data && event.notification.data.conversationId;
  const targetUrl = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      // Приложение уже открыто в каком-то окне/вкладке — просто выводим
      // его на передний план и просим открыть нужный чат, вместо того
      // чтобы плодить второе окно.
      for (const client of list) {
        if ('focus' in client) {
          client.focus();
          if (conversationId && client.postMessage) {
            client.postMessage({ type: 'open-conversation', conversationId });
          }
          return;
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(targetUrl);
    })
  );
});
