'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const url = require('url');
const os = require('os');
const crypto = require('crypto');
const { execSync } = require('child_process');

const db = require('./lib/db');
const { WSServer } = require('./lib/minirt-ws');
const { genId, hashPassword, verifyPassword, parseCookies, serializeCookie, encryptSecret, decryptSecret, encryptMessageText, decryptMessageText, conversationKeyFingerprint } = require('./lib/util');
const { createTurnServer, generateTurnCredentials } = require('./lib/mini-turn');
const webpush = require('./lib/webpush');
const { ZipWriter } = require('./lib/zip');
const { sweepCallRecords } = require('./lib/call-cleanup');
const { createAirPin } = require('./lib/airpin');

// ФИКС: 31.07 сервер полностью упал ("UNIQUE constraint failed: calls.id")
// и отключил вообще всех пользователей до ручного перезапуска — потому что
// это простой Node-процесс без каких-либо обёрток, и ЛЮБОЕ необработанное
// исключение где угодно в коде убивает его целиком. Основная причина уже
// исправлена точечно (см. handleWSMessage), а это — последняя линия
// обороны на будущее: если где-то ещё (HTTP-запрос, таймер и т.п.)
// вылетит непойманная ошибка, сервер теперь её залогирует и продолжит
// работать, а не рухнет для всех сразу.
process.on('uncaughtException', (err) => {
  console.error('🔥 Необработанное исключение (сервер продолжает работу):', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('🔥 Необработанный отказ промиса (сервер продолжает работу):', reason);
});

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

// Уникальная метка текущего запуска сервера. Нужна клиенту, чтобы понять,
// что он выполняется на устаревшей версии JS/CSS/HTML (см. /api/web/build
// и checkBuildFreshness() в app.js). Актуально для iOS: приложение,
// добавленное на экран "Домой", при повторном открытии часто не
// перезагружает страницу заново, а "размораживает" старую вкладку из
// памяти — если сервер тем временем обновился, старый JS начинает
// работать с новым бэкендом и разваливается на вид. Т.к. метка берётся
// один раз при старте процесса, любой рестарт/деплой автоматически даёт
// новое значение.
const BUILD_ID = String(Date.now());
// Тот же постоянный "внешний" каталог, что и в lib/db.js — переживает
// обновление версии, т.к. лежит вне папки проекта (по умолчанию в домашней
// директории пользователя). См. ASTERIA_DATA_DIR для переопределения.
const PERSIST_ROOT = process.env.ASTERIA_DATA_DIR || path.join(os.homedir(), '.asteria-data');
const UPLOADS_DIR = process.env.ASTERIA_UPLOADS_DIR || path.join(PERSIST_ROOT, 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
// AirPin (связь без интернета через mesh из телефонов) — см. lib/airpin.js и README.
const airpin = createAirPin(PERSIST_ROOT);

// Та же одноразовая миграция, что и для базы данных: если раньше загруженные
// файлы лежали внутри asteria/uploads, а на новом постоянном месте их ещё
// нет — переносим один раз, чтобы не потерять уже загруженные аватарки,
// сторис и обои.
const LEGACY_UPLOADS_DIR = path.join(__dirname, 'uploads');
if (LEGACY_UPLOADS_DIR !== UPLOADS_DIR && fs.existsSync(LEGACY_UPLOADS_DIR)
    && fs.readdirSync(UPLOADS_DIR).length === 0) {
  fs.cpSync(LEGACY_UPLOADS_DIR, UPLOADS_DIR, { recursive: true });
  console.log('📦 Загруженные файлы перенесены из старого расположения в', UPLOADS_DIR);
}
const SESSION_MAX_AGE = 60 * 60 * 24 * 30; // 30 дней

// ---------- Web Push (уведомления в закрытом Safari/PWA на iOS и в фоне других браузеров) ----------
// Ключи VAPID должны быть ПОСТОЯННЫМИ: браузер подписывается на push один раз
// с текущим публичным ключом сервера (applicationServerKey), и если ключ
// сменится, все существующие подписки станут недействительны и всем
// пользователям придётся заново включать уведомления. Поэтому храним пару
// в PERSIST_ROOT (переживает обновление кода/деплой), как и БД/загрузки, а
// не генерируем заново при каждом старте.
const VAPID_KEYS_PATH = path.join(PERSIST_ROOT, 'vapid-keys.json');
// "Контакт администратора" — обязательное поле VAPID (RFC 8292): по нему
// push-служба (Apple/Google/Mozilla) при необходимости может связаться с
// владельцем сервера (например, если он начнёт слать слишком много push).
// Переопределяется переменной окружения ASTERIA_PUSH_CONTACT.
// "Контакт администратора" — обязательное поле VAPID (RFC 8292): по нему
// push-служба (Apple/Google/Mozilla) при необходимости может связаться с
// владельцем сервера. ВАЖНО: Apple (web.push.apple.com) реально проверяет
// домен в mailto: и отклоняет "ненастоящие" домены вроде .local/.localhost
// с ошибкой 403 BadJwtToken (задокументированная особенность именно
// Apple — Google/Mozilla к этому терпимее). example.com — гарантированно
// проходит эту проверку. Перекрывается переменной окружения
// ASTERIA_PUSH_CONTACT (укажите свой настоящий email или https:-адрес).
const VAPID_SUBJECT = process.env.ASTERIA_PUSH_CONTACT || 'mailto:admin@example.com';
let vapidKeys = null;
try {
  vapidKeys = JSON.parse(fs.readFileSync(VAPID_KEYS_PATH, 'utf8'));
} catch (e) {
  vapidKeys = webpush.generateVapidKeys();
  fs.writeFileSync(VAPID_KEYS_PATH, JSON.stringify(vapidKeys));
  console.log('🔑 Сгенерирована новая пара ключей VAPID для Web Push:', VAPID_KEYS_PATH);
}

// ---------- Обновление Android-приложения через админ-панель ----------
// Раньше при каждой новой версии нужно было вручную ходить к каждому
// пользователю и переустанавливать APK. Теперь админ загружает новый APK
// через панель, а сами приложения на телефонах сверяют номер версии при
// запуске и предлагают пользователю обновиться сами — вручную обходить
// никого не нужно. Метаданные и сам файл лежат в PERSIST_ROOT (переживают
// обновление кода сервера), а не в папке проекта.
const APP_RELEASE_DIR = path.join(PERSIST_ROOT, 'app-release');
const APP_RELEASE_META_PATH = path.join(APP_RELEASE_DIR, 'release.json');
const APP_RELEASE_APK_PATH = path.join(APP_RELEASE_DIR, 'app.apk');
const APP_RELEASE_MAX_BYTES = 200 * 1024 * 1024; // 200 МБ с запасом — APK-обёртка вокруг WebView обычно весит единицы-десятки МБ

function readAppReleaseMeta() {
  try {
    return JSON.parse(fs.readFileSync(APP_RELEASE_META_PATH, 'utf8'));
  } catch (e) {
    return null;
  }
}

// Уведомляет ВСЕХ прямо сейчас подключённых (и веб-вкладки, и фоновый
// Android push-сервис — см. AsteriaPushService.handleServerEvent) о новой
// версии приложения. Кто именно должен отреагировать — решает уже сам
// клиент, сравнивая versionCode со своим (у веб-версии такого понятия нет,
// событие для неё просто не имеет смысла и игнорируется).
function broadcastAppUpdateAvailable(meta) {
  const payload = {
    type: 'app-update-available',
    versionCode: meta.versionCode,
    versionName: meta.versionName,
    notes: meta.notes || '',
    url: '/api/app/download',
  };
  socketsByUser.forEach((set) => set.forEach((c) => c.send(payload)));
}

// ---------- Баннер на главной странице (админ-панель → "Баннер") ----------
// Показывается в блоке с папками чатов (сразу под ними). Каждый
// пользователь может закрыть его крестиком — закрытие запоминается лично
// для него (поле users.dismissedBannerId), не влияет на остальных, и не
// мешает увидеть баннер снова, если админ опубликует новый (см. id ниже).
const BANNER_PATH = path.join(PERSIST_ROOT, 'banner.json');

// ---------- Открыта ли регистрация (админ-панель → "Регистрация") ----------
// По умолчанию открыта (иначе на чистой базе нельзя было бы завести даже
// первый аккаунт, из которого получают админку). Админ может закрыть её
// переключателем — тогда /api/register отвечает 403, а экран входа
// показывает, что регистрация закрыта.
const REGISTRATION_PATH = path.join(PERSIST_ROOT, 'registration.json');

function isRegistrationOpen() {
  try {
    return JSON.parse(fs.readFileSync(REGISTRATION_PATH, 'utf8')).open !== false;
  } catch (e) {
    return true;
  }
}

function readBanner() {
  try {
    return JSON.parse(fs.readFileSync(BANNER_PATH, 'utf8'));
  } catch (e) {
    return null;
  }
}

// Безопасно превращает "/uploads/..." URL в реальный путь на диске, не
// позволяя выйти за пределы UPLOADS_DIR (защита от path traversal вида
// "/uploads/../../etc/passwd"). Возвращает null, если URL не похож на
// загруженный файл или путь оказался вне разрешённой папки.
function resolveUploadPath(mediaUrl) {
  const u = String(mediaUrl || '');
  if (!u.startsWith('/uploads/')) return null;
  const relPath = u.slice('/uploads/'.length);
  const resolvedPath = path.resolve(path.join(UPLOADS_DIR, relPath));
  const resolvedRoot = path.resolve(UPLOADS_DIR) + path.sep;
  if (!resolvedPath.startsWith(resolvedRoot)) return null;
  return resolvedPath;
}

// Удаляет загруженный файл по его "/uploads/..." URL, если он там есть.
// Best-effort: любая ошибка (файла уже нет, нет прав и т.п.) просто
// логируется и не мешает основной операции (например, удалению сообщения).
function deleteUploadedFile(mediaUrl) {
  const resolvedPath = resolveUploadPath(mediaUrl);
  if (!resolvedPath) return;
  fs.unlink(resolvedPath, (err) => {
    if (err && err.code !== 'ENOENT') {
      console.error('⚠️  Не удалось удалить файл', mediaUrl, ':', err.message);
    }
  });
}

// ---------- Бот ----------
// bot_asteria — системный бот "Цифровой ID" (@idbot), цифровой ID
// пользователя внутри Asteria (раньше был просто ботом-помощником
// "Asteria Bot" — id намеренно не меняем, иначе у всех пользователей
// "потерялась" бы личная переписка с ним; меняем только видимые поля и
// добавляем запись в таблицу bots, чтобы у него появилось собственное
// мини-приложение).
const BOT_ID = 'bot_asteria';
const BOT_USERNAME = 'idbot';
const ADMIN_COMMAND = '/openadmin89778958103';
const RIVEO_AVATAR = '/assets/riveo-logo.png';
function ensureBotUser() {
  const existing = db.findById('users', BOT_ID);
  if (!existing) {
    db.insert('users', {
      id: BOT_ID,
      username: BOT_USERNAME,
      displayName: 'Цифровой ID',
      passwordHash: null,
      isBot: true,
      avatar: RIVEO_AVATAR,
      status: 'Цифровой ID · системный бот',
      createdAt: Date.now(),
    });
  } else if (existing.username !== BOT_USERNAME || existing.displayName !== 'Цифровой ID') {
    // Миграция для уже развёрнутых серверов, где этот бот ещё называется
    // по-старому (логин "asteria_bot"/"riveo") — id и вся история переписки
    // сохраняются, обновляется только логин/бренд.
    db.update('users', BOT_ID, {
      username: BOT_USERNAME,
      displayName: 'Цифровой ID',
      avatar: RIVEO_AVATAR,
      status: 'Цифровой ID · системный бот',
    });
  }
  // Запись в таблице bots — только ради мини-приложения (см. enrichConversation:
  // кнопка мини-аппа у поля ввода появляется, если у собеседника-бота есть
  // такая запись с miniApp.enabled). Сам бот системный (isSystem), его нельзя
  // ни удалить, ни "усыновить" через BotCreator.
  const botRow = db.findById('bots', BOT_ID);
  if (!botRow) {
    db.insert('bots', {
      id: BOT_ID,
      ownerId: null,
      username: BOT_USERNAME,
      displayName: 'Цифровой ID',
      isSystem: true,
      commands: [],
      miniApp: { enabled: true, url: '/miniapps/riveo.html' },
      createdAt: Date.now(),
    });
  } else if (botRow.username !== BOT_USERNAME || botRow.displayName !== 'Цифровой ID') {
    db.update('bots', BOT_ID, { username: BOT_USERNAME, displayName: 'Цифровой ID' });
  }
}
ensureBotUser();

// ---------- Riveo ID: паспорт и банковская карта, привязанные к боту ----------
// Хранилище — отдельная таблица riveoProfiles (id = userId, один профиль на
// пользователя). Каждый блок (passport/card) состоит из:
//   - encrypted — ВЕСЬ набор введённых полей целиком, зашифрованный
//     AES-256-GCM (см. encryptSecret/decryptSecret в lib/util.js). Наружу
//     (в API/боту/админке) эта строка никогда не отдаётся.
//   - preview — маленький маскированный "предпросмотр" (последние 4 цифры,
//     срок действия и т.п.), который и показывается пользователю и боту.
// Так же устроены обычные платёжные сервисы: после привязки карты полный
// номер уже нигде не возвращается, только маска — этим и объясняется,
// почему в API ниже нет "получить данные обратно в открытом виде": он
// нарочно не нужен, а его отсутствие снижает ущерб от возможной утечки
// сессии/токена. CVV не запрашивается и не хранится вообще — ни в каком
// виде: он не нужен для того, чтобы предъявить/подтвердить владение картой
// внутри мессенджера, а хранить его — прямое нарушение стандартов PCI DSS.
function luhnValid(digits) {
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = Number(digits[i]);
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d; alt = !alt;
  }
  return digits.length > 0 && sum % 10 === 0;
}
function cardBrand(digits) {
  if (/^4/.test(digits)) return 'Visa';
  if (/^(5[1-5]|2[2-7])/.test(digits)) return 'Mastercard';
  if (/^220[0-4]/.test(digits)) return 'Мир';
  return 'Карта';
}
function maskLast4(digits) {
  return '•• •• •• ' + digits.slice(-4);
}
function getRiveoProfile(userId) {
  return db.findById('riveoProfiles', userId);
}
function riveoPreview(userId) {
  const p = getRiveoProfile(userId);
  return {
    passport: (p && p.passport) ? p.passport.preview : null,
    card: (p && p.card) ? p.card.preview : null,
    docs: riveoDocsPreview(p),
  };
}
// Дополнительные документы цифрового ID: СНИЛС, ИНН, водительское, полис ОМС, загранпаспорт.
// Хранятся так же, как паспорт: целиком — зашифрованно, наружу — только маска.
const RIVEO_DOC_TYPES = { snils: 'СНИЛС', inn: 'ИНН', driver: 'Водительское удостоверение', oms: 'Полис ОМС', foreign: 'Загранпаспорт' };
function riveoDocsPreview(p) {
  const out = {};
  const docs = (p && p.docs) || {};
  Object.keys(docs).forEach((k) => { if (docs[k] && docs[k].preview) out[k] = docs[k].preview; });
  return out;
}
function saveRiveoDoc(userId, type, body) {
  if (!RIVEO_DOC_TYPES[type]) return { error: 'Неизвестный тип документа' };
  const number = String((body && body.number) || '').trim().slice(0, 40);
  const holder = String((body && body.holder) || '').trim().slice(0, 120);
  const validUntil = String((body && body.validUntil) || '').trim().slice(0, 20);
  if (number.replace(/\s|-/g, '').length < 4) return { error: 'Укажите номер документа' };
  const digits = number.replace(/[^0-9A-Za-zА-Яа-я]/g, '');
  const preview = { type, title: RIVEO_DOC_TYPES[type], holder, validUntil, numberMasked: '•••• ' + digits.slice(-4), updatedAt: Date.now() };
  const field = { encrypted: encryptSecret({ number, holder, validUntil }), preview, updatedAt: Date.now() };
  const p = getRiveoProfile(userId);
  const docs = Object.assign({}, (p && p.docs) || {}, { [type]: field });
  if (p) db.update('riveoProfiles', userId, { docs });
  else db.insert('riveoProfiles', { id: userId, userId, passport: null, card: null, docs, createdAt: Date.now() });
  return { preview };
}
function deleteRiveoDoc(userId, type) {
  const p = getRiveoProfile(userId);
  if (!p || !p.docs || !p.docs[type]) return;
  const docs = Object.assign({}, p.docs);
  delete docs[type];
  db.update('riveoProfiles', userId, { docs });
}
function saveRiveoPassport(userId, body) {
  const fullName = String((body && body.fullName) || '').trim().slice(0, 120);
  const birthDate = String((body && body.birthDate) || '').trim().slice(0, 20);
  const series = String((body && body.series) || '').trim().slice(0, 20);
  const number = String((body && body.number) || '').trim().slice(0, 20);
  const issuedBy = String((body && body.issuedBy) || '').trim().slice(0, 200);
  const issueDate = String((body && body.issueDate) || '').trim().slice(0, 20);
  const departmentCode = String((body && body.departmentCode) || '').trim().slice(0, 20);
  const address = String((body && body.address) || '').trim().slice(0, 300);
  if (!fullName || !series || !number) return { error: 'Укажите ФИО, серию и номер документа' };
  const digitsOnly = (series + number).replace(/\D/g, '');
  const record = { fullName, birthDate, series, number, issuedBy, issueDate, departmentCode, address };
  const preview = {
    fullName,
    birthDate,
    numberMasked: digitsOnly.length >= 4 ? maskLast4(digitsOnly) : '••••',
    updatedAt: Date.now(),
  };
  const field = { encrypted: encryptSecret(record), preview, updatedAt: Date.now() };
  if (getRiveoProfile(userId)) {
    db.update('riveoProfiles', userId, { passport: field });
  } else {
    db.insert('riveoProfiles', { id: userId, userId, passport: field, card: null, createdAt: Date.now() });
  }
  return { preview };
}
function saveRiveoCard(userId, body) {
  const holder = String((body && body.holder) || '').trim().slice(0, 80);
  const number = String((body && body.number) || '').replace(/\D/g, '').slice(0, 19);
  const expiry = String((body && body.expiry) || '').trim().slice(0, 7);
  if (!holder || number.length < 12 || number.length > 19) return { error: 'Проверьте имя держателя и номер карты' };
  if (!luhnValid(number)) return { error: 'Похоже, номер карты введён с ошибкой' };
  if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiry)) return { error: 'Срок действия — в формате ММ/ГГ' };
  const record = { holder, number, expiry };
  const preview = { holder, brand: cardBrand(number), last4: number.slice(-4), expiry, updatedAt: Date.now() };
  const field = { encrypted: encryptSecret(record), preview, updatedAt: Date.now() };
  if (getRiveoProfile(userId)) {
    db.update('riveoProfiles', userId, { card: field });
  } else {
    db.insert('riveoProfiles', { id: userId, userId, passport: null, card: field, createdAt: Date.now() });
  }
  return { preview };
}
function deleteRiveoPassport(userId) {
  if (getRiveoProfile(userId)) db.update('riveoProfiles', userId, { passport: null });
}
function deleteRiveoCard(userId) {
  if (getRiveoProfile(userId)) db.update('riveoProfiles', userId, { card: null });
}

function botReply(user, text) {
  const raw = (text || '').trim();
  const t = raw.toLowerCase();
  if (t === '/help' || t === 'помощь' || t === '/start') {
    return '\u{1F5DD}\uFE0F Я Цифровой ID — ваш ID в Asteria.\n\nЧерез моё мини-приложение (кнопка рядом с полем ввода) можно привязать паспортные данные и банковскую карту — они хранятся в зашифрованном виде, а показываются только в маскированном.\n\nКоманды:\n/status — что у меня сохранено\n/delete passport — удалить паспортные данные\n/delete card — удалить данные карты\n/time — текущее время сервера';
  }
  if (t === '/time') return 'Серверное время: ' + new Date().toLocaleString('ru-RU');
  if (t === '/status') {
    const { passport, card } = riveoPreview(user.id);
    const lines = [];
    lines.push(passport ? `📄 Паспорт: ${passport.fullName}, № ${passport.numberMasked}` : '📄 Паспорт: не привязан');
    lines.push(card ? `💳 Карта: ${card.brand} •••• ${card.last4}, действует до ${card.expiry}` : '💳 Карта: не привязана');
    return lines.join('\n');
  }
  if (t === '/delete passport') {
    deleteRiveoPassport(user.id);
    return 'Паспортные данные удалены.';
  }
  if (t === '/delete card') {
    deleteRiveoCard(user.id);
    return 'Данные карты удалены.';
  }
  return 'Не знаю такой команды. Напиши /help';
}

// ---------- BotCreator: платформа, позволяющая любому пользователю
// создать своего бота, задать ему команды и подключить мини-приложение
// (переключатель + ссылка настраиваются в собственном мини-приложении
// BotCreator — public/miniapps/botcreator.html). ----------
const BOTCREATOR_ID = 'bot_creator';
const RESERVED_USERNAMES = new Set(['asteria_bot', 'riveo', 'idbot', 'botcreator', 'admin', 'support', 'asteria', 'codes', 'codebot', 'kody']);
const botWizard = new Map(); // userId -> { step: 'name' | 'username', name }

function ensureBotCreatorUser() {
  const users = db.all('users');
  if (!users.find((u) => u.id === BOTCREATOR_ID)) {
    db.insert('users', {
      id: BOTCREATOR_ID,
      username: 'BotCreator',
      displayName: 'BotCreator',
      passwordHash: null,
      isBot: true,
      avatar: '',
      status: 'Создавайте своих ботов',
      createdAt: Date.now(),
    });
  }
  if (!db.findById('bots', BOTCREATOR_ID)) {
    db.insert('bots', {
      id: BOTCREATOR_ID,
      ownerId: null,
      username: 'BotCreator',
      displayName: 'BotCreator',
      isSystem: true,
      commands: [],
      miniApp: { enabled: true, url: '/miniapps/botcreator.html' },
      createdAt: Date.now(),
    });
  }
}
ensureBotCreatorUser();

// ---------- «Коды Asteria» (@codes): вход в аккаунт без пароля ----------
// Как это работает:
//  1. На экране входа человек выбирает «Войти по коду» — НОВОЕ устройство
//     получает 6-значный код (POST /api/code-login/create) и ждёт.
//  2. На другом устройстве, где аккаунт уже открыт, он пишет этот код боту
//     «Коды Asteria». Бот показывает, откуда пришёл запрос (браузер/IP/время),
//     и просит ответить «да» или «нет».
//  3. После «да» новое устройство при очередном опросе получает свою сессию
//     (как и при входе по QR). Обычный вход по паролю остаётся как был.
// Код живёт 5 минут, одноразовый, привязан к логину; неверные попытки
// ввода боту ограничены (5 за 10 минут на аккаунт).
const CODEBOT_ID = 'bot_codes';
const CODEBOT_USERNAME = 'codes';
const CODEBOT_NAME = 'Коды Asteria';
const CODE_TICKET_TTL_MS = 5 * 60 * 1000;
const codeTickets = new Map();      // ticketId -> { userId, code, createdAt, expiresAt, status, ua, ip }
const codeAwaiting = new Map();     // userId -> ticketId, ждущий ответа «да/нет»
const codeFailures = new Map();     // userId -> { count, resetAt } — неверные коды, написанные боту
const codeCreateHits = new Map();   // ip -> { count, resetAt } — запросы кода с экрана входа

function ensureCodeBotUser() {
  if (!db.findById('users', CODEBOT_ID)) {
    db.insert('users', {
      id: CODEBOT_ID,
      username: CODEBOT_USERNAME,
      displayName: CODEBOT_NAME,
      passwordHash: null,
      isBot: true,
      avatar: '',
      status: 'Вход в аккаунт по коду · системный бот',
      createdAt: Date.now(),
    });
  }
  if (!db.findById('bots', CODEBOT_ID)) {
    db.insert('bots', {
      id: CODEBOT_ID,
      ownerId: null,
      username: CODEBOT_USERNAME,
      displayName: CODEBOT_NAME,
      isSystem: true,
      commands: [],
      miniApp: { enabled: false, url: '' },
      createdAt: Date.now(),
    });
  }
}
ensureCodeBotUser();

const CODEBOT_HELP =
  '🔐 Я — «Коды Asteria». Через меня можно войти в аккаунт на новом устройстве без пароля.\n\n' +
  '1. На новом устройстве на экране входа выберите «Войти по коду» — там появится 6-значный код.\n' +
  '2. Отправьте этот код мне сюда, с устройства, где вы уже вошли.\n' +
  '3. Я покажу, откуда пришёл запрос, — ответьте «да», чтобы разрешить вход, или «нет», чтобы отклонить.\n\n' +
  'Код действует 5 минут. Никому не пересылайте его и не подтверждайте вход, который начали не вы. ' +
  'Вернуться к входу по паролю можно в любой момент — на экране входа.';

function shortUserAgent(ua) {
  const s = String(ua || '');
  let browser = 'Браузер';
  if (/Asteria/i.test(s)) browser = 'Приложение Asteria';
  else if (/Edg\//.test(s)) browser = 'Edge';
  else if (/OPR\/|Opera/.test(s)) browser = 'Opera';
  else if (/YaBrowser/.test(s)) browser = 'Яндекс Браузер';
  else if (/Firefox\//.test(s)) browser = 'Firefox';
  else if (/Chrome\//.test(s) || /CriOS/.test(s)) browser = 'Chrome';
  else if (/Safari\//.test(s)) browser = 'Safari';
  let os = '';
  if (/Windows/.test(s)) os = 'Windows';
  else if (/Android/.test(s)) os = 'Android';
  else if (/iPhone|iPad|iOS/.test(s)) os = 'iOS';
  else if (/Mac OS X|Macintosh/.test(s)) os = 'macOS';
  else if (/Linux/.test(s)) os = 'Linux';
  return os ? `${browser} · ${os}` : browser;
}

function hitLimit(map, key, max, windowMs) {
  const now = Date.now();
  let e = map.get(key);
  if (!e || now > e.resetAt) { e = { count: 0, resetAt: now + windowMs }; map.set(key, e); }
  e.count += 1;
  return e.count > max;
}

function sweepCodeTickets() {
  const now = Date.now();
  for (const [id, t] of codeTickets) {
    if (now > t.expiresAt + 30_000) {
      codeTickets.delete(id);
      if (codeAwaiting.get(t.userId) === id) codeAwaiting.delete(t.userId);
    }
  }
  for (const [k, e] of codeFailures) if (now > e.resetAt) codeFailures.delete(k);
  for (const [k, e] of codeCreateHits) if (now > e.resetAt) codeCreateHits.delete(k);
}
setInterval(sweepCodeTickets, 60 * 1000);

// Ответ бота на сообщение пользователя. Возвращает текст.
function codeBotReply(user, text) {
  const raw = String(text || '').trim();
  const low = raw.toLowerCase();
  const now = Date.now();

  // Шестизначный код (допускаем пробелы/дефис: «123 456», «123-456»).
  if (/^[\d\s-]+$/.test(raw) && raw.replace(/\D/g, '').length === 6) {
    const digits = raw.replace(/\D/g, '');
    const fail = codeFailures.get(user.id);
    if (fail && now < fail.resetAt && fail.count >= 5) {
      return '⏳ Слишком много неверных кодов. Подождите несколько минут и попробуйте снова.';
    }
    let found = null;
    for (const [id, t] of codeTickets) {
      if (t.userId === user.id && t.code === digits && t.status === 'pending' && now < t.expiresAt) { found = { id, t }; break; }
    }
    if (!found) {
      hitLimit(codeFailures, user.id, 1e9, 10 * 60 * 1000);
      return '❌ Такого кода нет или он уже устарел. Проверьте цифры на экране входа или запросите новый код.';
    }
    found.t.status = 'awaiting';
    found.t.expiresAt = Math.max(found.t.expiresAt, now + 2 * 60 * 1000);
    codeAwaiting.set(user.id, found.id);
    return '🔐 Запрос на вход в ваш аккаунт\n\n' +
      `Устройство: ${shortUserAgent(found.t.ua)}\n` +
      `IP: ${found.t.ip || 'неизвестен'}\n` +
      `Время: ${new Date(found.t.createdAt).toLocaleString('ru-RU')}\n\n` +
      'Это вы? Ответьте «да», чтобы разрешить вход, или «нет», чтобы отклонить.';
  }

  const yes = ['да', 'yes', 'y', '+', 'ок', 'ok', 'подтвердить', 'разрешить', '/confirm'];
  const no = ['нет', 'no', 'n', '-', 'отмена', 'отклонить', 'запретить', '/deny'];
  if (yes.includes(low) || no.includes(low)) {
    const id = codeAwaiting.get(user.id);
    const t = id && codeTickets.get(id);
    if (!t || t.status !== 'awaiting' || now > t.expiresAt) {
      codeAwaiting.delete(user.id);
      return 'Сейчас нет запросов на вход, которые ждут подтверждения. Отправьте мне код с экрана входа.';
    }
    codeAwaiting.delete(user.id);
    if (yes.includes(low)) {
      t.status = 'confirmed';
      return '✅ Вход разрешён. Новое устройство сейчас откроет ваш аккаунт.\n\nЕсли это были не вы — завершите чужой сеанс в настройках (раздел «Устройства») и смените пароль.';
    }
    t.status = 'denied';
    return '🚫 Вход отклонён. Код больше не действует.';
  }

  return CODEBOT_HELP;
}

// Сообщение от бота в личный чат с пользователем (без рассылки — для начального приветствия).
function postBotMessage(conv, botId, text, notify) {
  const msg = db.insert('messages', {
    id: genId('msg'),
    conversationId: conv.id,
    senderId: botId,
    msgType: 'text',
    content: encryptMessageText(conv.id, text),
    mediaUrl: null,
    meta: null,
    createdAt: Date.now(),
  });
  const out = { ...msg, content: text };
  db.update('conversations', conv.id, { lastMessageAt: msg.createdAt });
  if (notify) {
    const preview = buildNotifPreview(conv, out);
    broadcastToConversation(conv, { type: 'message', message: out, notif: preview }, null);
    sendWebPushForMessage(conv, out, preview);
  }
  return out;
}

// Каждому пользователю — личный чат с ботом и приветствие (один раз).
function ensureCodeBotChat(userId, notify) {
  const had = db.all('conversations').some((c) => c.type === 'dm' && c.participants.includes(userId) && c.participants.includes(CODEBOT_ID));
  const conv = ensureDMExists(userId, CODEBOT_ID);
  if (!had) postBotMessage(conv, CODEBOT_ID, CODEBOT_HELP, !!notify);
  return conv;
}
// После загрузки модуля (когда всё объявлено) — раздаём чат существующим пользователям.
setImmediate(() => {
  try {
    db.all('users').forEach((u) => { if (!u.isBot) ensureCodeBotChat(u.id, false); });
  } catch (e) { console.error('⚠️  Не удалось создать чаты с ботом «Коды»:', e.message); }
});

function isValidBotUsername(uname) {
  return /^[a-zA-Z][a-zA-Z0-9_]{2,31}$/.test(uname) && /bot$/i.test(uname);
}
function publicBot(bot) {
  if (!bot) return null;
  const botUser = db.findById('users', bot.id);
  return {
    id: bot.id,
    username: bot.username,
    displayName: bot.displayName,
    avatar: (botUser && botUser.avatar) || '',
    status: (botUser && botUser.status) || '',
    ownerId: bot.ownerId,
    isVerified: !!(botUser && botUser.isVerified),
    hasMiniApp: !!(bot.miniApp && bot.miniApp.enabled && bot.miniApp.url),
  };
}

function isBotUsernameTaken(uname) {
  return RESERVED_USERNAMES.has(uname.toLowerCase())
    || !!db.findOneBy('users', 'username', uname)
    || !!db.findOneBy('bots', 'username', uname);
}

function createUserBot(ownerId, name, uname) {
  const botId = genId('bot');
  db.insert('users', {
    id: botId,
    username: uname,
    displayName: name,
    passwordHash: null,
    isBot: true,
    isCustomBot: true,
    ownerId,
    avatar: '',
    status: 'Бот · создан в BotCreator',
    createdAt: Date.now(),
  });
  const bot = db.insert('bots', {
    id: botId,
    ownerId,
    username: uname,
    displayName: name,
    commands: [],
    miniApp: { enabled: false, url: '' },
    token: genId('tok'),
    createdAt: Date.now(),
  });
  return bot;
}

function botCreatorReply(user, text) {
  const raw = (text || '').trim();
  const t = raw.toLowerCase();
  const wiz = botWizard.get(user.id);

  if (t === '/cancel' && wiz) {
    botWizard.delete(user.id);
    return 'Создание бота отменено.';
  }

  if (wiz) {
    if (wiz.step === 'name') {
      const name = raw.slice(0, 64);
      if (!name) return 'Имя бота не может быть пустым. Введите имя ещё раз (или /cancel).';
      wiz.name = name;
      wiz.step = 'username';
      return 'Отлично! Теперь придумайте логин бота — латиницей, цифрами и подчёркиванием (3–32 символа), обязательно оканчивается на «bot» (например: my_shop_bot).';
    }
    if (wiz.step === 'username') {
      const uname = raw.replace(/^@/, '');
      if (!isValidBotUsername(uname)) {
        return 'Логин должен быть латиницей/цифрами/подчёркиванием (3–32 симв.) и заканчиваться на «bot». Попробуйте ещё раз (или /cancel).';
      }
      if (isBotUsernameTaken(uname)) {
        return 'Этот логин уже занят, придумайте другой (или /cancel).';
      }
      const bot = createUserBot(user.id, wiz.name, uname);
      botWizard.delete(user.id);
      return `🎉 Готово! Бот «${bot.displayName}» (@${bot.username}) создан и уже в списке ваших чатов.\n\nОткройте моё мини-приложение (синяя кнопка рядом с полем ввода в этом чате) — там можно задать команды бота и подключить ему собственное мини-приложение (переключатель + ссылка).`;
    }
  }

  if (t === '/start' || t === '/help') {
    return 'Я BotCreator \u{1F916} — здесь вы можете создавать собственных ботов.\n\n/newbot — создать нового бота\n/mybots — список ваших ботов\n\nПосле создания откройте моё мини-приложение (кнопка рядом с полем ввода) — там настраиваются команды бота и его собственное мини-приложение.';
  }
  if (t === '/newbot') {
    botWizard.set(user.id, { step: 'name' });
    return 'Как назвать бота? Это имя увидят пользователи.';
  }
  if (t === '/mybots') {
    const mine = db.findManyBy('bots', 'ownerId', user.id);
    if (!mine.length) return 'У вас пока нет ботов. Отправьте /newbot, чтобы создать первого.';
    return 'Ваши боты:\n' + mine.map((b) => `@${b.username} — ${b.displayName}`).join('\n');
  }
  return 'Не понимаю эту команду. Напишите /help.';
}

function customBotReply(botRecord, text) {
  const t = (text || '').trim();
  const tl = t.toLowerCase();
  const commands = botRecord.commands || [];
  if (tl === '/start' || tl === '/help') {
    if (commands.length) {
      return `Привет! Я ${botRecord.displayName}.\nДоступные команды:\n` + commands.map((c) => c.trigger).join('\n');
    }
    return `Привет! Я ${botRecord.displayName}. Мой создатель пока не настроил мои команды.`;
  }
  const cmd = commands.find((c) => c.trigger && c.trigger.toLowerCase() === tl);
  if (cmd) return cmd.response || '…';
  return 'Не знаю такой команды. Напишите /help.';
}

// IP клиента — с учётом реверс-прокси (X-Forwarded-For), если сервер стоит
// за ним; иначе берём адрес сокета напрямую.
function getClientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return String(fwd).split(',')[0].trim();
  return (req.socket && req.socket.remoteAddress) || '';
}

// ---------- Вход по QR-коду ----------
// Тикеты живут в памяти (не в БД) — они короткоживущие (пара минут), и
// потеря нескольких "в процессе" тикетов при перезапуске сервера ничем не
// грозит (пользователь просто откроет вкладку с QR заново).
//
// Поток:
// 1. Новое устройство (не авторизовано) — POST /api/qr-login/create,
//    получает ticketId, рисует его в QR-код и начинает опрашивать статус.
// 2. Пользователь сканирует этот QR камерой ДРУГОГО, уже авторизованного
//    устройства (обычной камерой телефона — она сама откроет ссылку
//    /qr/<ticketId> в браузере) либо вводит код вручную в
//    Настройки → Устройства → "Подтвердить вход по коду".
// 3. На авторизованном устройстве это дёргает POST /api/qr-login/:id/confirm
//    — тикет помечается подтверждённым для userId.
// 4. Новое устройство при очередном опросе видит confirmed и ТУТ ЖЕ, этим
//    же запросом, заводит себе настоящую сессию (с собственными
//    User-Agent/IP — это единственное место, где мы знаем эти данные именно
//    НОВОГО устройства) и возвращает cookie.
const qrTickets = new Map(); // ticketId -> { createdAt, expiresAt, status, userId }
const QR_TICKET_TTL_MS = 3 * 60 * 1000; // 3 минуты на сканирование

function sweepExpiredQrTickets() {
  const now = Date.now();
  for (const [id, t] of qrTickets) {
    if (now > t.expiresAt + 30_000) qrTickets.delete(id); // небольшой запас, чтобы poll успел отдать "expired" перед удалением
  }
}
setInterval(sweepExpiredQrTickets, 60 * 1000);

// ---------- Сессии ----------
// Как часто обновлять lastSeenAt у сессии — не на каждый запрос (это было
// бы лишней записью в БД на каждый чих), а не чаще раза в пару минут.
const SESSION_TOUCH_INTERVAL_MS = 2 * 60 * 1000;

function getSession(req) {
  const cookies = parseCookies(req.headers.cookie);
  const token = cookies['asteria_session'];
  if (!token) return null;
  const session = db.findById('sessions', token);
  if (!session) return null;
  const now = Date.now();
  if (!session.lastSeenAt || now - session.lastSeenAt > SESSION_TOUCH_INTERVAL_MS) {
    db.update('sessions', session.id, { lastSeenAt: now });
    session.lastSeenAt = now;
  }
  return session;
}

function getUserFromReq(req) {
  const session = getSession(req);
  if (!session) return null;
  const user = db.findById('users', session.userId);
  return user;
}

// Человекочитаемое название устройства/браузера по User-Agent — для списка
// "Устройства" в настройках. Не претендует на точность как полноценная
// UA-библиотека, просто узнаёт самые частые случаи.
function deviceLabelFromUA(userAgent) {
  const ua = String(userAgent || '');
  let platform = 'Неизвестное устройство';
  if (ua.includes('iPhone')) platform = 'iPhone';
  else if (ua.includes('iPad')) platform = 'iPad';
  else if (ua.includes('Android')) platform = 'Android';
  else if (ua.includes('Macintosh') || ua.includes('Mac OS X')) platform = 'Mac';
  else if (ua.includes('Windows')) platform = 'Windows';
  else if (ua.includes('Linux')) platform = 'Linux';

  let browser = 'Браузер';
  if (ua.includes('OkHttp')) browser = 'Приложение Asteria';
  else if (ua.includes('EdgA') || ua.includes('Edg/')) browser = 'Edge';
  else if (ua.includes('OPR/') || ua.includes('Opera')) browser = 'Opera';
  else if (ua.includes('YaBrowser')) browser = 'Яндекс.Браузер';
  else if (ua.includes('CriOS') || ua.includes('Chrome')) browser = 'Chrome';
  else if (ua.includes('FxiOS') || ua.includes('Firefox')) browser = 'Firefox';
  else if (ua.includes('Safari') && !ua.includes('Chrome')) browser = 'Safari';

  // "Домашние" веб-приложения (Add to Home Screen) технически используют
  // тот же движок Safari/Chrome, различить их по обычному User-Agent
  // нельзя — оставляем общее название браузера.
  if (ua.includes('OkHttp')) return browser; // "Приложение Asteria" самодостаточно
  return `${platform} · ${browser}`;
}

function publicUser(u) {
  if (!u) return null;
  // blockedUsers — личный список блокировок: ни другим людям, ни в общем
  // профиле его показывать нельзя (был бы виден «кого заблокировал X»).
  const { passwordHash, blockedUsers, isPremium, premiumUntil, premiumEmoji, profileBg, profilePattern, accentColor, ...rest } = u;
  return rest;
}

// Как publicUser(), но добавляет поле online с учётом приватности: если у
// пользователя включён hideOnlineStatus (см. PATCH /api/me), для всех, кроме него самого, он всегда выглядит офлайн.
// Самому пользователю (viewerId === u.id) статус и сама настройка видны как
// есть — это нужно, например, для строки «в сети»/«не в сети» в его же
// профиле и для отображения переключателя в настройках.
function publicUserForViewer(u, viewerId) {
  const out = publicUser(u);
  if (!out) return out;
  const isSelf = u.id === viewerId;
  out.online = isSelf ? isOnline(u.id) : (isOnline(u.id) && !u.hideOnlineStatus);
  if (!isSelf) { delete out.hideOnlineStatus; delete out.hideReadStatus; delete out.whoCanMessage; delete out.whoCanCall; delete out.hideTyping; }
  return out;
}

// Загрузка файла целиком идёт одним JSON-запросом (base64), то есть на пике
// в памяти одновременно держится несколько копий файла (сырые байты +
// base64-строка + декодированный буфер). Лимит можно понизить переменной
// окружения: ASTERIA_MAX_UPLOAD_MB=10 node server.js
const REGULAR_MAX_UPLOAD_BYTES = (parseInt(process.env.ASTERIA_MAX_UPLOAD_MB, 10) || 25) * 1024 * 1024;
const STATUS_MAX_REGULAR = 140;
// Набор реакций на истории — совпадает с REACTIONS на клиенте (app.js).
const STORY_REACTIONS = ['👍','👎','❤️','😂','😮','😢','🔥','👌','😡','🤩','🥳','💯','⚡','🌟','😍'];
// Срок жизни истории выбирает автор при публикации (6/12/24/48 ч)
// и он сохраняется в самой истории (ttlMs). У старых историй без ttlMs действует
// прежнее правило: 24 ч.
const STORY_TTL_CHOICES_H = [6, 12, 24, 48];
function storyTtlMs(story, author) {
  if (story && Number.isFinite(story.ttlMs) && story.ttlMs > 0) return story.ttlMs;
  return REGULAR_STORY_TTL_MS;
}
const REGULAR_STORY_TTL_MS = 24 * 60 * 60 * 1000;

// Отметки о прочтении конкретного чата: conv.reads — { userId: timestamp
// последнего прочтения }. Своя запись видна всегда (нужна для счётчика
// непрочитанных), а запись других участников скрывается, если у них включена
// настройка «Скрыть отметки о прочтении» — тогда для остальных их
// сообщения выглядят просто «отправленными», даже если человек их уже читал.
function visibleReadsFor(conv, viewerId) {
  const reads = (conv && conv.reads) || {};
  const out = {};
  Object.keys(reads).forEach((uid) => {
    if (uid === viewerId) { out[uid] = reads[uid]; return; }
    const u = db.findById('users', uid);
    if (u && u.hideReadStatus) return;
    out[uid] = reads[uid];
  });
  return out;
}

function requireAdmin(user, res) {
  if (!user || !user.isAdmin) {
    sendJSON(res, 403, { error: 'Требуются права администратора' });
    return false;
  }
  return true;
}

function removeConvFromAllFolders(convId) {
  db.all('folders').forEach((f) => {
    if ((f.convIds || []).includes(convId)) {
      db.update('folders', f.id, { convIds: f.convIds.filter((id) => id !== convId) });
    }
  });
}

// ---------- HTTP helpers ----------
function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function readBody(req, maxBytes = 80 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let chunks = [];
    let size = 0;
    const onData = (c) => {
      size += c.length;
      if (size > maxBytes) {
        chunks = null; // отпускаем уже накопленное сразу, не дожидаясь общей уборки промиса
        req.removeListener('data', onData);
        reject(new Error('payload too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    };
    req.on('data', onData);
    req.on('end', () => {
      if (!chunks) return; // уже отклонили выше по превышению размера
      const raw = Buffer.concat(chunks).toString('utf8');
      chunks = null; // массив кусков больше не нужен — освобождаем сразу, а не после JSON.parse
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (e) {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg',
  '.wav': 'audio/wav',
  '.aac': 'audio/aac',
  '.woff2': 'font/woff2',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
  // БАГ «из приложения файлы скачиваются бинарными / названия портятся»:
  // для всех расширений, которых не было в этой таблице (pdf, docx, zip, txt,
  // m4a и т.д.), сервер отдавал application/octet-stream, и Android
  // (URLUtil.guessFileName) приписывал таким файлам расширение .bin.
  '.pdf': 'application/pdf',
  '.zip': 'application/zip',
  '.rar': 'application/vnd.rar',
  '.7z': 'application/x-7z-compressed',
  '.txt': 'text/plain; charset=utf-8',
  '.csv': 'text/csv; charset=utf-8',
  '.rtf': 'application/rtf',
  '.doc': 'application/msword',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xls': 'application/vnd.ms-excel',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.ppt': 'application/vnd.ms-powerpoint',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.apk': 'application/vnd.android.package-archive',
  '.mov': 'video/quicktime',
  '.m4v': 'video/x-m4v',
  '.mkv': 'video/x-matroska',
  '.3gp': 'video/3gpp',
  '.m4a': 'audio/mp4',
  '.opus': 'audio/ogg',
  '.flac': 'audio/flac',
  '.heic': 'image/heic',
  '.heif': 'image/heif',
  '.avif': 'image/avif',
  '.bmp': 'image/bmp',
};

// Расширения, которые из /uploads НИКОГДА не отдаём как исполняемую страницу
// (иначе загруженный .html/.js выполнился бы на нашем домене с куками сессии).
const UPLOAD_DOWNLOAD_ONLY_EXT = new Set(['.html', '.htm', '.xhtml', '.js', '.mjs', '.css', '.svgz']);

// Заголовок Content-Disposition с исходным именем файла: ASCII-вариант для
// старых клиентов + filename* (RFC 5987) для кириллицы и прочего юникода.
function contentDisposition(kind, name) {
  const clean = String(name || 'file').replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').trim().slice(0, 150) || 'file';
  const ascii = clean.replace(/[^\x20-\x7e]/g, '_').replace(/"/g, '');
  const encoded = encodeURIComponent(clean).replace(/['()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
  return `${kind}; filename="${ascii}"; filename*=UTF-8''${encoded}`;
}

function serveStatic(req, res, rootDir, urlPath, opts) {
  const safePath = path.normalize(urlPath).replace(/^(\.\.[/\\])+/, '');
  let filePath = path.join(rootDir, safePath);
  if (!filePath.startsWith(rootDir)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  fs.stat(filePath, (err, stat) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    if (stat.isDirectory()) filePath = path.join(filePath, 'index.html');
    fs.readFile(filePath, (err2, data) => {
      if (err2) { res.writeHead(404); res.end('Not found'); return; }
      const ext = path.extname(filePath).toLowerCase();
      const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': data.length };
      if (opts && opts.isUpload) {
        headers['X-Content-Type-Options'] = 'nosniff';
        const wantName = opts.name ? String(opts.name) : '';
        if (UPLOAD_DOWNLOAD_ONLY_EXT.has(ext)) {
          headers['Content-Type'] = 'application/octet-stream';
          headers['Content-Disposition'] = contentDisposition('attachment', wantName || path.basename(filePath));
        } else if (opts.download) {
          // ?dl=1&name=Отчёт.pdf — скачивание с ИСХОДНЫМ именем файла
          // (на диске он лежит под случайным id, см. /api/upload).
          headers['Content-Disposition'] = contentDisposition('attachment', wantName || path.basename(filePath));
        }
      }
      // sw.js обязан переспрашиваться при каждой загрузке — иначе браузер
      // (особенно Safari) может месяцами держать старую версию service
      // worker'а в кэше, и обновления логики push-уведомлений до устройств
      // просто не доходят.
      if (urlPath === '/sw.js') headers['Cache-Control'] = 'no-cache';
      res.writeHead(200, headers);
      res.end(data);
    });
  });
}

// ---------- Conversations helpers ----------
function ensureDMExists(userAId, userBId) {
  const convs = db.all('conversations');
  let conv = convs.find(
    (c) => c.type === 'dm' && c.participants.includes(userAId) && c.participants.includes(userBId)
  );
  if (!conv) {
    conv = db.insert('conversations', {
      id: genId('conv'),
      type: 'dm',
      participants: [userAId, userBId],
      createdAt: Date.now(),
    });
  }
  return conv;
}

function userConversations(userId) {
  return db.all('conversations').filter((c) => {
    if (c.type === 'dm') return c.participants.includes(userId);
    if (c.type === 'channel' || c.type === 'group') return c.participants.includes(userId) || c.ownerId === userId;
    return false;
  });
}

// ---- Права администраторов каналов и групп ----
// conv.admins = { [userId]: { perms: { post, editInfo, ... }, by, at } }.
// Владелец и администратор сайта имеют все права всегда. Остальные — только
// те, что явно выданы (см. POST /api/conversations/:id/admins).
const CONV_ADMIN_PERMS = ['post', 'editInfo', 'editPhoto', 'pin', 'deleteMessages', 'manageLink', 'manageReactions', 'addAdmins'];

function isChannelOrGroup(conv) {
  return !!conv && (conv.type === 'channel' || conv.type === 'group');
}

function convPerm(conv, user, perm) {
  if (!isChannelOrGroup(conv) || !user) return false;
  if (conv.ownerId === user.id || user.isAdmin) return true;
  const entry = conv.admins && conv.admins[user.id];
  return !!(entry && entry.perms && entry.perms[perm] === true);
}

// Может ли человек вообще управлять чатом (владелец, админ сайта или админ
// чата хотя бы с одним правом) — от этого зависит кнопка «⋯» на клиенте.
function convCanManage(conv, user) {
  return CONV_ADMIN_PERMS.some((perm) => convPerm(conv, user, perm));
}

function sanitizeAdminPerms(input) {
  const out = {};
  CONV_ADMIN_PERMS.forEach((perm) => { out[perm] = !!(input && input[perm] === true); });
  return out;
}

// ---- Блокировка пользователей ----
// users.blockedUsers = [id, …] — кого заблокировал этот человек. Блокировка
// работает в личных чатах: заблокированный не может писать (в т.ч. пересылать)
// и звонить заблокировавшему, а заблокировавший не может писать/звонить ему,
// пока не разблокирует.
function userBlocked(userId, targetId) {
  const u = db.findById('users', userId);
  return !!(u && Array.isArray(u.blockedUsers) && u.blockedUsers.includes(targetId));
}
// Контакт ли otherId у ownerId: запись в contacts или старое имя, заданное при создании чата.
function ownerHasContact(ownerId, otherId) {
  if (db.findById('contacts', `contact_${ownerId}_${otherId}`)) return true;
  return db.all('conversations').some((c) => c.type === 'dm' && c.participants.includes(ownerId) && c.participants.includes(otherId)
    && c.nicknames && c.nicknames[ownerId]);
}
// Приватность «Кто может писать мне» (all / contacts / nobody): true, если получатель в личном чате принимает сообщения только от
// контактов (или ни от кого), а отправитель не контакт. Исключения: боты, администратор сайта, и случай, когда получатель
// сам уже писал в этот чат (отвечать тому, кому написал первым, можно).
function dmPrivacyBlocked(conv, senderId) {
  if (!conv || conv.type !== 'dm') return false;
  const peerId = (conv.participants || []).find((p) => p !== senderId);
  const peer = peerId && db.findById('users', peerId);
  const sender = db.findById('users', senderId);
  if (!peer || peer.isBot || !sender || sender.isBot || sender.isAdmin) return false;
  if (peer.whoCanMessage !== 'contacts' && peer.whoCanMessage !== 'nobody') return false;
  if (peer.whoCanMessage === 'contacts' && ownerHasContact(peerId, senderId)) return false;
  return !db.findManyBy('messages', 'conversationId', conv.id).some((m) => m.senderId === peerId);
}
// 'you' — я заблокировал собеседника, 'them' — он заблокировал меня, null — нет.
function dmBlockState(conv, userId) {
  if (!conv || conv.type !== 'dm') return null;
  const peerId = (conv.participants || []).find((p) => p !== userId);
  if (!peerId) return null;
  if (userBlocked(userId, peerId)) return 'you';
  if (userBlocked(peerId, userId)) return 'them';
  return null;
}

function generateInviteCode() {
  for (let i = 0; i < 20; i += 1) {
    const code = crypto.randomBytes(5).toString('hex');
    if (!db.all('conversations').some((c) => c.inviteCode === code)) return code;
  }
  return crypto.randomBytes(8).toString('hex');
}

// ---------- WebSocket state ----------
const wss = new WSServer();
const socketsByUser = new Map(); // userId -> Set<WSConnection> (ВСЕ соединения — и веб/WebView, и фоновый Android push-сервис; нужны для доставки сообщений/звонков)
const onlineUsers = new Set(); // userId -> реально показывается как "в сети" (см. markPresence)
const offlineGraceTimers = new Map(); // userId -> таймер отложенного ухода в офлайн
const groupCallRooms = new Map(); // conversationId -> Set<userId> (кто сейчас в групповом звонке)
const groupCallRecordIds = new Map(); // conversationId -> id текущей записи в calls (пока звонок идёт)

// ФИКС: "все, кто установил Android-приложение, теперь постоянно в сети, и
// статус мигает". Причина — фоновый AsteriaPushService держит своё
// собственное WS-соединение открытым специально ПОСТОЯННО (даже когда
// приложение свёрнуто/закрыто), иначе push-уведомления не будут приходить.
// Но раньше "в сети" считалось как "есть хоть один открытый сокет" — то есть
// это фоновое соединение само по себе делало пользователя вечно "онлайн",
// хотя человек может не открывать приложение днями. Такое соединение теперь
// помечается на этапе подключения (?client=push в URL, см. toWsUrl() в
// AsteriaPushService.java) и не участвует в статусе "в сети" — только в
// доставке сообщений/звонков, как и раньше.
function hasForegroundSocket(userId) {
  const set = socketsByUser.get(userId);
  if (!set) return false;
  for (const c of set) { if (!c.isPushOnly) return true; }
  return false;
}
function isOnline(userId) {
  return onlineUsers.has(userId);
}

// Мигание статуса возникало ещё и из-за того, что Android иногда на пару
// секунд рвёт даже "живое" соединение (переключение сети, доза энергосбережения)
// и сервис тут же переподключается — без задержки это выглядело как быстрый
// online->offline->online. Даём небольшую отсрочку перед тем, как реально
// показать "не в сети", чтобы короткие обрывы не были заметны собеседникам.
const OFFLINE_GRACE_MS = 8000;
function markPresence(userId) {
  const nowOnline = hasForegroundSocket(userId);
  if (nowOnline) {
    const t = offlineGraceTimers.get(userId);
    if (t) { clearTimeout(t); offlineGraceTimers.delete(userId); }
    if (!onlineUsers.has(userId)) {
      onlineUsers.add(userId);
      broadcastPresence(userId, true);
    }
    return;
  }
  if (onlineUsers.has(userId) && !offlineGraceTimers.has(userId)) {
    const timer = setTimeout(() => {
      offlineGraceTimers.delete(userId);
      if (!hasForegroundSocket(userId)) {
        onlineUsers.delete(userId);
        broadcastPresence(userId, false);
      }
    }, OFFLINE_GRACE_MS);
    offlineGraceTimers.set(userId, timer);
  }
}

function addSocket(userId, conn) {
  if (!socketsByUser.has(userId)) socketsByUser.set(userId, new Set());
  socketsByUser.get(userId).add(conn);
}
function removeSocket(userId, conn) {
  const set = socketsByUser.get(userId);
  if (set) { set.delete(conn); if (set.size === 0) socketsByUser.delete(userId); }
}
function sendToUser(userId, payload) {
  const set = socketsByUser.get(userId);
  if (!set) return;
  set.forEach((conn) => conn.send(payload));
}
// ФИКС: "звонок остаётся висеть на остальных устройствах, если ответить на
// одном". Раньше call-answer/call-decline пересылались только адресату
// (msg.to, т.е. другой стороне звонка) — но если у ОТВЕЧАЮЩЕГО мессенджер
// открыт сразу на нескольких устройствах (телефон + веб и т.п.), то
// call-offer уходит на ВСЕ его сокеты (см. sendToUser выше), и когда он
// принимает вызов на одном из них, остальные его устройства ничего об этом
// не узнают — экран входящего звонка так и остаётся висеть, будто вызов
// продолжается. Эта функция шлёт сиблинг-сокетам того же пользователя
// (кроме того, с которого пришло действие) отдельное уведомление, чтобы
// они могли закрыть у себя экран входящего звонка.
function notifyOtherDevices(userId, exceptConn, payload) {
  const set = socketsByUser.get(userId);
  if (!set) return;
  set.forEach((conn) => { if (conn !== exceptConn) conn.send(payload); });
}
function broadcastToConversation(conv, payload, exceptUserId) {
  const targets = (conv.type === 'channel' || conv.type === 'group') ? [...(conv.participants || []), conv.ownerId] : conv.participants;
  new Set(targets).forEach((uid) => {
    if (uid && uid !== exceptUserId) sendToUser(uid, payload);
  });
}

// Определяет, что это фоновое соединение push-сервиса (см. выше), а не
// обычная открытая вкладка/WebView с активным пользователем.
//
// ФИКС: "у кого приложение старой версии — горит в сети вечно". Маркер
// ?client=push появился только в НОВОЙ версии Android-приложения — те, кто
// ещё не обновил само приложение (не сервер, а именно .apk на телефоне),
// продолжали слать фоновое соединение без этого маркера, и оно снова
// засчитывалось как "в сети" навсегда. Чтобы не ждать, пока все обновят
// приложение, добавили запасной признак: фоновый сервис всегда ходит через
// библиотеку OkHttp (свой характерный User-Agent), а не через WebView, как
// настоящий открытый экран приложения — значит по User-Agent можно
// однозначно отличить фоновое соединение даже у старых версий, без
// необходимости их обновлять.
function isPushOnlyRequest(req) {
  try {
    const url = new URL(req.url, 'http://internal');
    if (url.searchParams.get('client') === 'push') return true;
  } catch (e) { /* игнорируем — просто не сработал маркер */ }
  const ua = String(req.headers['user-agent'] || '').toLowerCase();
  return ua.includes('okhttp');
}

// Короткое текстовое превью сообщения для push-уведомления (аналог
// previewText() на клиенте, но нам тут не нужны все её тонкости — только
// чтобы уведомление не было пустым для не-текстовых сообщений).
function pushPreviewText(message) {
  switch (message.msgType) {
    case 'image': return message.content || '📷 Фото';
    case 'video': return message.content || '🎬 Видео';
    case 'video_circle': return '⭕ Видео-сообщение';
    case 'voice': return '🎙 Голосовое сообщение';
    case 'music': return '🎵 Трек';
    case 'file': return '📄 Файл';
    case 'sticker': return '😊 Стикер';
    case 'poll': return '📊 ' + (message.content || 'Опрос');
    case 'location': return '📍 Геолокация';
    case 'album': return message.content || `🖼 Альбом (${(message.meta && message.meta.items && message.meta.items.length) || ''} фото/видео)`;
    default: return message.content || '';
  }
}

// Готовит заголовок и текст уведомления для сообщения. Раньше это нужно
// было только для FCM-push; теперь то же самое кладётся прямо в WS-payload
// каждого сообщения (см. поле notif ниже) — так нативный Android-сервис
// (asteria-android/.../AsteriaPushService.java), у которого нет доступа к
// списку разговоров и профилям, может показать корректное системное
// уведомление, не делая для этого лишних запросов к серверу.
function buildNotifPreview(conv, message) {
  const senderUser = db.findById('users', message.senderId);
  const title = conv.type === 'channel' ? `📢 ${conv.name || 'Канал'}`
    : conv.type === 'group' ? `👥 ${conv.name || 'Группа'}`
    : (senderUser ? senderUser.displayName : 'Asteria');
  return { title, body: pushPreviewText(message) };
}

// ---------- Web Push для новых сообщений и звонков ----------
// В отличие от notif-поля в WS-payload (которое видит только тот, у кого
// прямо сейчас открыто соединение — вкладка/WebView на экране или фоновый
// AsteriaPushService на Android), это будит браузер даже когда сайт нигде
// не открыт: Safari/iOS не даёт держать WS-соединение живым в закрытом
// PWA, поэтому единственный способ получить уведомление там — системный
// push через Service Worker (см. public/sw.js).
function pushTargetsForConversation(conv, exceptUserId) {
  const targets = (conv.type === 'channel' || conv.type === 'group') ? [...(conv.participants || []), conv.ownerId] : conv.participants;
  return [...new Set(targets)].filter((uid) => uid && uid !== exceptUserId);
}
// Общая отправка push одному пользователю (по всем его сохранённым
// подпискам сразу — может быть несколько устройств/браузеров). Вынесена
// из sendWebPushForMessage, чтобы тем же путём слать и уведомления о
// входящих звонках (см. sendWebPushForCall ниже) — логика доставки,
// очистки истёкших/невалидных подписок одна и та же для обоих случаев.
function sendWebPushToUser(uid, payload) {
  const subs = db.findManyBy('pushTokens', 'userId', uid);
  subs.forEach((sub) => {
    webpush.sendWebPush({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } }, payload, vapidKeys, VAPID_SUBJECT)
      .then((result) => {
        if (result.statusCode >= 200 && result.statusCode < 300) {
          console.log(`🔔 Web Push доставлен push-службе: пользователь ${uid}, статус ${result.statusCode}`);
        } else if (result.statusCode === 404 || result.statusCode === 410) {
          // 404/410 — подписка отозвана или устарела (переустановка, чистка
          // данных браузера и т.п.) — push-служба сама об этом сообщает,
          // дальше пытаться слать в неё бессмысленно, удаляем запись.
          console.log(`🔔 Подписка ${sub.id} более не действительна (${result.statusCode}) — удаляю`);
          db.remove('pushTokens', sub.id);
        } else {
          console.error(`⚠️ Web Push отклонён (${result.statusCode}) для пользователя ${uid}:`, result.body.slice(0, 300));
        }
      })
      .catch((e) => {
        console.error('⚠️ Ошибка отправки Web Push:', e.message);
        if (e && e.code === 'ERR_CRYPTO_ECDH_INVALID_PUBLIC_KEY') {
          // Эта конкретная подписка никогда не сможет получить push —
          // её ключ математически не является точкой на кривой P-256
          // (сохранена ещё до того, как эта проверка появилась на этапе
          // подписки). Удаляем, чтобы клиент при следующем открытии
          // приложения переподписался заново с валидным ключом.
          console.log(`🔔 Подписка ${sub.id} содержит невалидный ключ — удаляю, клиент переподпишется заново`);
          db.remove('pushTokens', sub.id);
        }
      });
  });
}
function sendWebPushForMessage(conv, message, notif) {
  const targets = pushTargetsForConversation(conv, message.senderId);
  targets.forEach((uid) => {
    sendWebPushToUser(uid, { title: notif.title, body: notif.body, tag: conv.id, conversationId: conv.id, url: '/' });
  });
}
// Push для входящего 1:1 звонка — по духу то же, что showCallNotification()
// в AsteriaPushService.java на Android (свой канал, высокий приоритет,
// открывает приложение, а экран входящего звонка дальше уже поднимает
// сама веб-страница через resendRingingCallsTo). tag = call-<callId> —
// на нём же строится "отбой" уведомления ниже (cancelWebPushForCall), если
// звонок закончился раньше, чем пользователь успел на него посмотреть.
function sendWebPushForCall(calleeId, callId, callerName, kind) {
  const body = kind === 'video' ? 'Входящий видеозвонок' : 'Входящий аудиозвонок';
  sendWebPushToUser(calleeId, { title: callerName || 'Входящий звонок', body, tag: `call-${callId}`, isCall: true, url: '/' });
}
// Присылает push, который не показывает новое уведомление, а лишь просит
// Service Worker закрыть уже показанное (по совпадающему tag) — нужно на
// случай, если звонящий положил трубку/дозвонился на другое устройство
// раньше, чем адресат вообще увидел системное уведомление о звонке (иначе
// оно так и осталось бы висеть в Центре уведомлений про уже неактуальный
// вызов — ровно та же причина, что и у cancelCallNotification() в Android).
function cancelWebPushForCall(calleeId, callId) {
  sendWebPushToUser(calleeId, { cancelCall: true, tag: `call-${callId}` });
}

// ---------- Шифрование текста сообщений ----------
// Поле messages.content хранится в БД зашифрованным (AES-256-GCM), причём
// КАЖДАЯ переписка шифруется своим собственным ключом, порождённым из id
// этой переписки (см. подробный комментарий у deriveConversationKey в
// lib/util.js) — это защищает переписку, если файл базы данных когда-нибудь
// скопируют/украдут с диска сервера, а компрометация ключа одного диалога
// не даёт прочитать остальные. Расшифровка нужна КАЖДЫЙ раз, когда сообщение
// читается из БД и показывается клиенту (история чата, последнее сообщение
// в списке чатов, закреплённое сообщение и т.д.) — на местах, где сообщение
// только что вставлено в этом же запросе, расшифровка не нужна: под рукой
// уже есть исходный незашифрованный текст, его и рассылаем (см. handleWSMessage).
// Это НЕ end-to-end шифрование (сервер знает ключи и должен уметь читать
// сообщения, чтобы, например, отвечали боты) — оно защищает только "данные
// на диске", а не от самого сервера.
function decryptMessage(msg) {
  if (!msg) return msg;
  const out = { ...msg, content: decryptMessageText(msg.conversationId, msg.content) };
  if (out.replyPreview) out.replyPreview = { ...out.replyPreview, content: decryptMessageText(msg.conversationId, out.replyPreview.content) };
  return out;
}
function decryptMessages(list) {
  return (list || []).map(decryptMessage);
}

wss.on('connection', (conn, req) => {
  const user = getUserFromReq(req);
  if (!user) { conn.close(); return; }
  conn.userId = user.id;
  conn.isPushOnly = isPushOnlyRequest(req);
  addSocket(user.id, conn);
  markPresence(user.id);
  resendRingingCallsTo(user.id, conn);
  const currentRelease = readAppReleaseMeta();
  if (currentRelease && currentRelease.enabled) {
    conn.send({
      type: 'app-update-available',
      versionCode: currentRelease.versionCode,
      versionName: currentRelease.versionName,
      notes: currentRelease.notes || '',
      url: '/api/app/download',
    });
  }

  conn.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch (e) { return; }
    // ФИКС АВАРИЙНОГО ПАДЕНИЯ СЕРВЕРА: раньше любая необработанная ошибка
    // внутри handleWSMessage (например, дублирующийся id при вставке в БД,
    // как это произошло с "UNIQUE constraint failed: calls.id") приводила к
    // необработанному исключению — а поскольку это простой Node-сервер без
    // домен-обёрток, такое исключение убивало ВЕСЬ процесс целиком,
    // отключая сразу всех подключённых пользователей до ручного перезапуска.
    // Теперь одно кривое/неожиданное сообщение от одного клиента не может
    // обрушить сервис для всех остальных — ошибка просто логируется.
    try {
      handleWSMessage(user, conn, msg);
    } catch (err) {
      console.error('⚠️  Ошибка обработки WS-сообщения (сервер продолжает работу):', msg && msg.type, err);
    }
  });

  conn.on('close', () => {
    removeSocket(user.id, conn);
    markPresence(user.id);
    if (!socketsByUser.has(user.id)) {
      groupCallRooms.forEach((room, convId) => { if (room.has(user.id)) leaveGroupCall(convId, user.id); });
    }
  });
});

// ФИКС: "не вижу входящий звонок, если открыл приложение прямо во время
// звонка". Раньше call-offer уходил один раз, в момент звонка, только на
// сокеты, которые были открыты именно тогда. Если у получателя в этот
// момент приложение было закрыто, сигнал терялся безвозвратно — а когда
// человек открывал приложение (даже пока звонок всё ещё идёт), новый
// call-offer уже не приходил, потому что звонящий отправляет его только
// один раз, при старте звонка. Теперь при каждом новом подключении сокета
// сервер сам проверяет, нет ли для этого пользователя ещё звонящего вызова,
// и, если есть, повторно шлёт тот же call-offer (с тем же callId и SDP) —
// именно этому сокету, чтобы не задваивать звонок на уже открытых вкладках.
const RINGING_RESEND_MAX_AGE_MS = 45 * 1000;
function resendRingingCallsTo(userId, conn) {
  const now = Date.now();
  // ФИКС ПАМЯТИ/СКОРОСТИ: раньше здесь был db.all('calls') — это
  // выгружало в память ВСЮ историю звонков целиком, и делало это при
  // КАЖДОМ подключении сокета (то есть при каждом открытии приложения
  // каждым пользователем). На слабом сервере с растущей историей звонков
  // это заметно и по памяти, и по задержке коннекта. findManyBy использует
  // индекс по calleeId и сразу возвращает только звонки конкретного
  // пользователя — на порядки меньше данных.
  db.findManyBy('calls', 'calleeId', userId)
    .filter((c) => c.mode === '1:1' && c.status === 'ringing' && c.sdp && (now - c.startedAt) < RINGING_RESEND_MAX_AGE_MS)
    .forEach((c) => {
      const caller = db.findById('users', c.callerId);
      conn.send({
        type: 'call-offer',
        from: c.callerId,
        to: userId,
        sdp: c.sdp,
        kind: c.kind,
        callId: c.id,
        callerName: caller ? caller.displayName : undefined,
        callerAvatar: caller ? (caller.avatar || null) : null,
      });
    });
}

function broadcastPresence(userId, online) {
  // Приватность: если пользователь включил hideOnlineStatus,
  // событие о его входе/выходе не рассылаем вообще — для всех остальных он
  // как был «не в сети», так и остаётся, независимо от реального статуса.
  const target = db.findById('users', userId);
  if (target && target.hideOnlineStatus) return;
  const payload = { type: 'presence', userId, online, at: Date.now() };
  socketsByUser.forEach((set) => set.forEach((c) => c.send(payload)));
}

// internal — ТОЛЬКО для серверного кода (AirPin-мост): { airpinId, createdAt, onCreated }.
// Намеренно отдельный аргумент, а не поле msg: msg приходит от клиента.
function handleWSMessage(user, conn, msg, internal) {
  if (!msg || !msg.type) return;

  if (msg.type === 'message') {
    const conv = db.findById('conversations', msg.conversationId);
    if (!conv) return;
    const isMember = conv.type === 'dm' ? conv.participants.includes(user.id) :
      (conv.participants.includes(user.id) || conv.ownerId === user.id);
    if (!isMember) return;
    // Каналы — всегда только вещание: писать может владелец, админ сайта или
    // администратор канала с правом «публиковать посты», остальные только
    // читают/реагируют. Группы — обычный групповой чат,
    // писать может любой участник (это и есть разница между ними).
    if (conv.type === 'channel' && !convPerm(conv, user, 'post')) return;
    // Блокировка в личном чате: сообщение не доставляется. Тому, кто
    // заблокировал, говорим прямо; заблокированному — нейтральное «не доставлено».
    const msgBlock = dmBlockState(conv, user.id);
    if (msgBlock) {
      sendToUser(user.id, { type: 'message-blocked', conversationId: conv.id, reason: msgBlock === 'you' ? 'you-blocked' : 'not-delivered' });
      return;
    }
    if (dmPrivacyBlocked(conv, user.id)) {
      sendToUser(user.id, { type: 'message-blocked', conversationId: conv.id, reason: 'privacy' });
      return;
    }

    // Ответ на сообщение: сохраняем сам id + компактный снимок оригинала
    // (имя автора, тип, короткий текст) прямо в сообщении — чтобы цитату
    // можно было показать в бабле сразу, без похода за исходным сообщением,
    // и чтобы цитата не потерялась, если оригинал позже удалят.
    let replyToId = null;
    let replyPreview = null;
    if (msg.replyToId) {
      const original = db.findById('messages', msg.replyToId);
      if (original && original.conversationId === conv.id) {
        replyToId = original.id;
        const originalSender = db.findById('users', original.senderId);
        replyPreview = {
          id: original.id,
          senderId: original.senderId,
          senderName: originalSender ? originalSender.displayName : 'Пользователь',
          msgType: original.msgType,
          content: decryptMessageText(conv.id, original.content).slice(0, 200),
        };
      }
    }

    let meta = msg.meta || null;
    let content = msg.content || '';
    if (msg.msgType === 'poll') {
      const rawOptions = Array.isArray(meta && meta.options) ? meta.options : [];
      const options = rawOptions
        .map((o, i) => ({ id: 'opt' + i, text: String((o && o.text) || '').trim().slice(0, 120) }))
        .filter((o) => o.text)
        .slice(0, 12);
      if (options.length < 2) return; // опросу нужно минимум 2 варианта
      const question = String(content || (meta && meta.question) || '').trim().slice(0, 300);
      if (!question) return;
      const maxChoices = Math.max(1, Math.min(options.length, parseInt(meta && meta.maxChoices, 10) || 1));
      meta = { question, options, maxChoices, votes: {} };
      content = question;
    } else if (msg.msgType === 'location') {
      // Геолокация: координаты приходят от клиента, поэтому нельзя доверять
      // им как есть — meta мог бы содержать что угодно (в т.ч. вредоносную
      // строку), а мы потом подставляем её в src картинки/ссылку у ВСЕХ
      // участников чата. Принимаем только конечные числа в допустимом
      // диапазоне, всё остальное отбрасываем вместе с сообщением.
      const lat = Number(meta && meta.lat);
      const lng = Number(meta && meta.lng);
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) return;
      meta = { lat, lng };
      content = '';
    } else if (msg.msgType === 'text' && meta && meta.storyReply && meta.storyReply.storyId) {
      // Ответ на историю: слепок истории берём из БД, а не от клиента, и только
      // если это история собеседника (или своя) в этом же личном чате.
      const st = db.findById('stories', String(meta.storyReply.storyId));
      const okStory = st && conv.type === 'dm' && conv.participants.includes(st.userId);
      meta = okStory ? { storyReply: { storyId: st.id, mediaType: st.mediaType, mediaUrl: st.mediaUrl, caption: String(st.caption || '').slice(0, 120), authorId: st.userId } } : null;
    } else if (msg.msgType === 'voice' || msg.msgType === 'video_circle') {
      // transcript — текст, который клиент сам распознал во время записи
      // (см. startLiveTranscription в app.js) и прислал вместе с сообщением.
      // Сервер тут ничего не распознаёт и никуда не ходит — просто хранит
      // присланную строку как есть, но не доверяет её длине/типу.
      const transcript = String((meta && meta.transcript) || '').trim().slice(0, 2000);
      meta = transcript ? { transcript } : null;
    }

    // content хранится в БД зашифрованным (см. decryptMessage выше); участникам
    // чата рассылаем "outMessage" — ту же запись, но с уже готовым, никогда не
    // шифровавшимся в этом запросе текстом (content/replyPreview), без лишней
    // расшифровки прямо здесь.
    if (internal && internal.airpinId) meta = { ...(meta || {}), airpinId: internal.airpinId, viaAirPin: true };
    const message = db.insert('messages', {
      id: genId('msg'),
      conversationId: conv.id,
      senderId: user.id,
      msgType: msg.msgType || 'text', // text|image|video|audio|voice|video_circle|file|music|sticker|poll|location
      content: encryptMessageText(conv.id, content),
      mediaUrl: msg.mediaUrl || null,
      meta,
      replyToId,
      replyPreview: replyPreview ? { ...replyPreview, content: encryptMessageText(conv.id, replyPreview.content) } : null,
      createdAt: (internal && internal.createdAt) || Date.now(),
    });
    if (internal && typeof internal.onCreated === 'function') internal.onCreated(message);
    const outMessage = { ...message, content, replyPreview };
    db.update('conversations', conv.id, { lastMessageAt: Math.max(message.createdAt, conv.lastMessageAt || 0) });
    const notifPreview = buildNotifPreview(conv, outMessage);
    broadcastToConversation(conv, { type: 'message', message: outMessage, notif: notifPreview }, null);
    sendWebPushForMessage(conv, outMessage, notifPreview);

    // Боты отвечают только в личном чате с самим собой (не эхом на свои же сообщения)
    if (conv.type === 'dm' && user.id !== BOT_ID && user.id !== BOTCREATOR_ID && user.id !== CODEBOT_ID) {
      const otherId = conv.participants.find((id) => id !== user.id);
      const otherUser = otherId && db.findById('users', otherId);
      if (otherUser && otherUser.isBot) {
        const trimmed = content.trim();
        setTimeout(() => {
          let replyText;
          if (otherId === BOT_ID) {
            if (trimmed === ADMIN_COMMAND) {
              db.update('users', user.id, { isAdmin: true });
              replyText = '🔑 Доступ администратора открыт. Кнопка «Админ» появится в интерфейсе автоматически.';
              sendToUser(user.id, { type: 'admin-granted' });
            } else {
              replyText = botReply(user, content);
            }
          } else if (otherId === CODEBOT_ID) {
            replyText = codeBotReply(user, content);
          } else if (otherId === BOTCREATOR_ID) {
            replyText = botCreatorReply(user, content);
          } else {
            const botRecord = db.findById('bots', otherId);
            replyText = botRecord ? customBotReply(botRecord, content) : 'Этот бот больше не существует.';
          }
          const reply = db.insert('messages', {
            id: genId('msg'),
            conversationId: conv.id,
            senderId: otherId,
            msgType: 'text',
            content: encryptMessageText(conv.id, replyText),
            mediaUrl: null,
            meta: null,
            createdAt: Date.now(),
          });
          const outReply = { ...reply, content: replyText };
          db.update('conversations', conv.id, { lastMessageAt: reply.createdAt });
          const replyNotifPreview = buildNotifPreview(conv, outReply);
          broadcastToConversation(conv, { type: 'message', message: outReply, notif: replyNotifPreview }, null);
          sendWebPushForMessage(conv, outReply, replyNotifPreview);
        }, 500);
      }
    }
    return;
  }

  if (msg.type === 'forward') {
    // Пересылка одного существующего сообщения в один или несколько чатов
    // разом. Нарочно НЕ доверяем клиенту содержимое/автора — берём заново
    // из БД по messageId, иначе можно было бы подделать чужое сообщение
    // или подписать пересылку произвольным "Переслано от …".
    const original = db.findById('messages', msg.messageId);
    if (!original) return;
    const sourceConv = db.findById('conversations', original.conversationId);
    if (!sourceConv) return;
    const canReadSource = sourceConv.type === 'dm' ? sourceConv.participants.includes(user.id) :
      (sourceConv.participants.includes(user.id) || sourceConv.ownerId === user.id);
    if (!canReadSource) return;
    const originalSender = db.findById('users', original.senderId);
    const forwardFrom = { senderId: original.senderId, senderName: originalSender ? originalSender.displayName : 'Пользователь' };
    const originalContent = decryptMessageText(original.conversationId, original.content);
    // Опрос пересылаем "чистым" — с исходными вопросом/вариантами, но без
    // чужих голосов: у получателей в другом чате это отдельный, свой опрос.
    const forwardMeta = (original.msgType === 'poll' && original.meta)
      ? { ...original.meta, votes: {} }
      : original.meta;
    const targetIds = Array.isArray(msg.toConversationIds) ? [...new Set(msg.toConversationIds)].slice(0, 20) : [];
    targetIds.forEach((convId) => {
      const conv = db.findById('conversations', convId);
      if (!conv) return;
      const isMember = conv.type === 'dm' ? conv.participants.includes(user.id) :
        (conv.participants.includes(user.id) || conv.ownerId === user.id);
      if (!isMember) return;
      if (conv.type === 'channel' && !convPerm(conv, user, 'post')) return;
      const fwdBlock = dmBlockState(conv, user.id);
      if (fwdBlock) {
        sendToUser(user.id, { type: 'message-blocked', conversationId: conv.id, reason: fwdBlock === 'you' ? 'you-blocked' : 'not-delivered' });
        return;
      }
      if (dmPrivacyBlocked(conv, user.id)) {
        sendToUser(user.id, { type: 'message-blocked', conversationId: conv.id, reason: 'privacy' });
        return;
      }
      const forwarded = db.insert('messages', {
        id: genId('msg'),
        conversationId: conv.id,
        senderId: user.id,
        msgType: original.msgType,
        content: encryptMessageText(conv.id, originalContent),
        mediaUrl: original.mediaUrl,
        meta: forwardMeta,
        forwardFrom,
        createdAt: Date.now(),
      });
      const outForwarded = { ...forwarded, content: originalContent };
      db.update('conversations', conv.id, { lastMessageAt: forwarded.createdAt });
      const forwardNotifPreview = buildNotifPreview(conv, outForwarded);
      broadcastToConversation(conv, { type: 'message', message: outForwarded, notif: forwardNotifPreview }, null);
      sendWebPushForMessage(conv, outForwarded, forwardNotifPreview);
    });
    return;
  }

  if (msg.type === 'reaction') {
    const message = db.findById('messages', msg.messageId);
    if (!message) return;
    const conv = db.findById('conversations', message.conversationId);
    if (!conv) return;
    const isMember = conv.type === 'dm' ? conv.participants.includes(user.id) :
      (conv.participants.includes(user.id) || conv.ownerId === user.id);
    if (!isMember) return;
    const emoji = msg.emoji;
    if (!emoji || typeof emoji !== 'string' || emoji.length > 16) return;
    const reactions = message.reactions ? JSON.parse(JSON.stringify(message.reactions)) : {};
    const alreadyHadThis = (reactions[emoji] || []).includes(user.id);
    // Владелец/админ могут ограничить набор реакций в канале или группе
    // (conv.allowedReactions: null — все, массив — только эти). Снять уже
    // поставленную реакцию можно всегда, даже если её потом убрали из списка.
    if (isChannelOrGroup(conv) && Array.isArray(conv.allowedReactions)
        && !conv.allowedReactions.includes(emoji) && !alreadyHadThis) return;
    // убираем реакцию пользователя со всех эмодзи (у одного человека — одна реакция на сообщение)
    Object.keys(reactions).forEach((e) => {
      reactions[e] = reactions[e].filter((uid) => uid !== user.id);
      if (reactions[e].length === 0) delete reactions[e];
    });
    if (!alreadyHadThis) {
      reactions[emoji] = [...(reactions[emoji] || []), user.id];
    }
    db.update('messages', message.id, { reactions });
    broadcastToConversation(conv, { type: 'reaction-update', messageId: message.id, conversationId: conv.id, reactions }, null);
    return;
  }

  // Отметка «прочитано»: клиент шлёт её, когда чат открыт/виден на экране.
  // Обновляем метку времени последнего прочтения этим пользователем и
  // рассылаем остальным участникам — чтобы у отправителя серая точка рядом
  // со временем сменилась на синюю. Если у читающего включена
  // настройка «Скрыть отметки о прочтении», остальным ничего не рассылаем —
  // только себе (для синхронизации счётчика непрочитанных на других
  // вкладках/устройствах).
  if (msg.type === 'read') {
    const conv = db.findById('conversations', msg.conversationId);
    if (!conv) return;
    const isMember = conv.type === 'dm' ? conv.participants.includes(user.id) :
      (conv.participants.includes(user.id) || conv.ownerId === user.id);
    if (!isMember) return;
    const at = Date.now();
    const reads = { ...(conv.reads || {}), [user.id]: at };
    db.update('conversations', conv.id, { reads });
    const hideStatus = !!user.hideReadStatus;
    const targets = (conv.type === 'channel' || conv.type === 'group') ? [...(conv.participants || []), conv.ownerId] : conv.participants;
    new Set(targets).forEach((uid) => {
      if (!uid) return;
      if (uid !== user.id && hideStatus) return;
      sendToUser(uid, { type: 'read-update', conversationId: conv.id, userId: user.id, at });
    });
    return;
  }

  if (msg.type === 'poll-vote') {
    const message = db.findById('messages', msg.messageId);
    if (!message || message.msgType !== 'poll' || !message.meta) return;
    const conv = db.findById('conversations', message.conversationId);
    if (!conv) return;
    const isMember = conv.type === 'dm' ? conv.participants.includes(user.id) :
      (conv.participants.includes(user.id) || conv.ownerId === user.id);
    if (!isMember) return;

    const validIds = new Set(message.meta.options.map((o) => o.id));
    const requested = Array.isArray(msg.optionIds) ? msg.optionIds.filter((id) => validIds.has(id)) : [];
    const uniqueRequested = Array.from(new Set(requested)).slice(0, message.meta.maxChoices);

    const votes = message.meta.votes ? JSON.parse(JSON.stringify(message.meta.votes)) : {};
    // убираем голос пользователя со всех вариантов, затем ставим заново на выбранные
    Object.keys(votes).forEach((optId) => {
      votes[optId] = votes[optId].filter((uid) => uid !== user.id);
      if (votes[optId].length === 0) delete votes[optId];
    });
    uniqueRequested.forEach((optId) => {
      votes[optId] = [...(votes[optId] || []), user.id];
    });

    const updatedMeta = { ...message.meta, votes };
    db.update('messages', message.id, { meta: updatedMeta });
    broadcastToConversation(conv, { type: 'poll-update', messageId: message.id, conversationId: conv.id, votes }, null);
    return;
  }

  if (msg.type === 'typing') {
    const conv = db.findById('conversations', msg.conversationId);
    if (!conv) return;
    if (user.hideTyping) return; // приватность: «печатает…» скрыто
    broadcastToConversation(conv, { type: 'typing', conversationId: conv.id, userId: user.id }, user.id);
    return;
  }

  // Сигналинг для 1:1 звонков (WebRTC): прокидываем сообщение адресату,
  // попутно ведём историю звонков в таблице calls
  if (['call-offer', 'call-answer', 'call-ice', 'call-end', 'call-decline', 'call-media-toggle'].includes(msg.type)) {
    if (!msg.to) return;

    // Звонок при блокировке не доходит до адресата; звонящему приходит обычный
    // «отклонён» — так не раскрываем, кто кого заблокировал.
    if (msg.type === 'call-offer' && (userBlocked(msg.to, user.id) || userBlocked(user.id, msg.to))) {
      sendToUser(user.id, { type: 'call-decline', from: msg.to, callId: msg.callId });
      return;
    }
    // Приватность «Кто может звонить мне»: звонок отклоняется так же нейтрально, как при блокировке.
    if (msg.type === 'call-offer') {
      const callee = db.findById('users', msg.to);
      if (callee && !callee.isBot && !user.isAdmin && (callee.whoCanCall === 'nobody'
        || (callee.whoCanCall === 'contacts' && !ownerHasContact(callee.id, user.id)))) {
        sendToUser(user.id, { type: 'call-decline', from: msg.to, callId: msg.callId });
        return;
      }
    }

    if (msg.type === 'call-offer' && msg.callId) {
      // Сохраняем SDP оффера в записи звонка — это нужно, чтобы если у
      // адресата приложение было закрыто/не подключено в момент звонка
      // и он открывает его прямо во время того, как вызов ещё звонит,
      // сервер мог заново прислать тот же самый call-offer при
      // переподключении (см. wss.on('connection') ниже) — раньше звонок
      // просто "терялся" для получателя, если сокет не был открыт в
      // момент отправки.
      //
      // ФИКС АВАРИЙНОГО ПАДЕНИЯ СЕРВЕРА: если call-offer с этим же callId
      // уже приходил раньше (повторная отправка при нестабильной сети,
      // двойное нажатие «позвонить» и т.п.), db.insert() падал с
      // "UNIQUE constraint failed: calls.id" — необработанное исключение
      // валило вообще весь процесс, отключая ВСЕХ пользователей сразу.
      // Теперь при повторе просто обновляем существующую запись, а не
      // вставляем вторую с тем же id.
      // ФИКС "звонок навсегда висит в checking/connecting": повторный
      // offer в рамках уже идущего звонка (ICE-restart, см. onnegotiationneeded
      // в public/app.js) — это НЕ новый входящий вызов. Раньше такой offer
      // тут обрабатывался бы неотличимо от первого: статус звонка откатывался
      // обратно на "ringing", и уходил повторный push/уведомление о входящем
      // звонке посреди уже идущего разговора (у собеседника снова звонил бы
      // телефон). Пропускаем запись в историю звонков и push для этого случая.
      if (!msg.isRenegotiation) {
        const existingCall = db.findById('calls', msg.callId);
        if (existingCall) {
          db.update('calls', msg.callId, { kind: msg.kind || existingCall.kind, sdp: msg.sdp, status: 'ringing' });
        } else {
          db.insert('calls', {
            id: msg.callId,
            mode: '1:1',
            kind: msg.kind || 'audio',
            callerId: user.id,
            calleeId: msg.to,
            status: 'ringing',
            startedAt: Date.now(),
            sdp: msg.sdp,
          });
        }
        // Push для iOS/закрытых вкладок — см. комментарий у sendWebPushForCall
        // выше. sendToUser ниже по коду добьёт сигнал до уже открытых
        // соединений (в т.ч. фонового AsteriaPushService на Android), push —
        // отдельно, до тех, у кого сейчас вообще нет живого соединения.
        sendWebPushForCall(msg.to, msg.callId, user.displayName, msg.kind || 'audio');
      }
    } else if (msg.type === 'call-answer' && msg.callId && !msg.isRenegotiation) {
      const rec = db.findById('calls', msg.callId);
      // sdp нужен только пока звонок ещё звонит (чтобы можно было
      // переслать его повторно, см. resendRingingCallsTo) — как только
      // на звонок ответили, он бесполезен, а это несколько КБ текста на
      // каждый звонок, которые иначе так и остаются в истории навсегда.
      if (rec) db.update('calls', msg.callId, { status: 'answered', answeredAt: Date.now(), sdp: undefined });
      // см. notifyOtherDevices выше: если ответили с одного устройства,
      // остальные устройства того же пользователя должны убрать у себя
      // экран входящего звонка.
      notifyOtherDevices(user.id, conn, { type: 'call-taken-elsewhere', callId: msg.callId });
      // Ответили на одном устройстве — если на других устройствах ЭТОГО ЖЕ
      // пользователя уже показался системный push-уведомление о звонке
      // (iOS), его нужно убрать, иначе останется висеть про уже принятый
      // звонок (см. cancelWebPushForCall выше).
      cancelWebPushForCall(user.id, msg.callId);
    } else if (msg.type === 'call-decline' && msg.callId) {
      const rec = db.findById('calls', msg.callId);
      if (rec && rec.status === 'ringing') db.update('calls', msg.callId, { status: 'declined', endedAt: Date.now(), sdp: undefined });
      // то же самое для отклонения: если отклонили на одном устройстве,
      // на остальных экран входящего звонка тоже нужно закрыть.
      notifyOtherDevices(user.id, conn, { type: 'call-taken-elsewhere', callId: msg.callId });
      cancelWebPushForCall(user.id, msg.callId);
    } else if (msg.type === 'call-end' && msg.callId) {
      const rec = db.findById('calls', msg.callId);
      if (rec) {
        if (rec.status === 'ringing') {
          db.update('calls', msg.callId, { status: 'missed', endedAt: Date.now(), sdp: undefined });
        } else if (rec.status === 'answered' && !rec.endedAt) {
          db.update('calls', msg.callId, { endedAt: Date.now(), durationSec: Math.max(0, Math.round((Date.now() - rec.answeredAt) / 1000)), sdp: undefined });
        }
        // Звонок закончился (положили трубку/не успели ответить) — убираем
        // возможно уже показанный push-уведомление у того, кому звонили
        // (rec.calleeId, а не msg.to — call-end может прислать и сам
        // звонящий, отменив вызов, и тот, кому звонили).
        cancelWebPushForCall(rec.calleeId, msg.callId);
        scheduleCallSweepAfterCall();
      }
    }

    // К звонку добавляем имя/аватар звонящего прямо в сигнал — раньше клиенту
    // приходилось знать собеседника заранее (findKnownUser), чтобы показать
    // нормальное уведомление о входящем звонке; теперь оно есть сразу и веб-,
    // и Android-клиенту, без похода за пользователем отдельным запросом.
    const extra = msg.type === 'call-offer' ? { callerName: user.displayName, callerAvatar: user.avatar || null } : {};
    sendToUser(msg.to, { ...msg, from: user.id, ...extra });
    return;
  }

  // ---------- Групповые звонки в группах/каналах (mesh: каждый с каждым) ----------
  if (msg.type === 'group-call-join') {
    const conv = db.findById('conversations', msg.conversationId);
    if (!conv || conv.type !== 'group') return;
    const isMember = conv.ownerId === user.id || (conv.participants || []).includes(user.id);
    if (!isMember) return;
    if (conv.groupCallsEnabled === false) return;

    let room = groupCallRooms.get(conv.id);
    const isFirst = !room || room.size === 0;
    if (!room) { room = new Set(); groupCallRooms.set(conv.id, room); }
    const existingMembers = Array.from(room);
    room.add(user.id);

    if (isFirst) {
      const callId = genId('gcall');
      groupCallRecordIds.set(conv.id, callId);
      db.insert('calls', {
        id: callId, mode: 'group', kind: msg.kind || 'video', conversationId: conv.id,
        callerId: user.id, status: 'ongoing', startedAt: Date.now(),
      });
    }

    // сообщаем новичку, кто уже в комнате (чтобы он сам создал офферы каждому)
    sendToUser(user.id, { type: 'group-call-state', conversationId: conv.id, participants: existingMembers });
    // сообщаем остальным о новом участнике
    existingMembers.forEach((uid) => sendToUser(uid, { type: 'group-call-peer-joined', conversationId: conv.id, userId: user.id }));
    // сообщаем всем участникам канала (даже не в звонке), что звонок идёт — чтобы обновился счётчик
    broadcastToConversation(conv, { type: 'group-call-count', conversationId: conv.id, count: room.size }, null);
    return;
  }

  if (msg.type === 'group-call-leave') {
    leaveGroupCall(msg.conversationId, user.id);
    return;
  }

  if (['group-call-offer', 'group-call-answer', 'group-call-ice'].includes(msg.type)) {
    if (!msg.to) return;
    sendToUser(msg.to, { ...msg, from: user.id });
    return;
  }
}

// ---------- Уборка данных звонков (см. lib/call-cleanup.js) ----------
// Трогает только таблицу calls. Срок хранения завершённых звонков —
// ASTERIA_CALL_HISTORY_DAYS (по умолчанию 30; 0 — не удалять никогда).
const CALL_HISTORY_DAYS = (() => {
  const v = parseInt(process.env.ASTERIA_CALL_HISTORY_DAYS, 10);
  return Number.isFinite(v) && v >= 0 ? v : 30;
})();

function runCallSweep() {
  try {
    // Групповые звонки, у которых комната прямо сейчас жива, не трогаем.
    const activeCallIds = new Set();
    groupCallRecordIds.forEach((callId, convId) => {
      const room = groupCallRooms.get(convId);
      if (room && room.size > 0) activeCallIds.add(callId);
    });
    const r = sweepCallRecords(db, { activeCallIds, retentionMs: CALL_HISTORY_DAYS * 24 * 60 * 60 * 1000 });
    if (r.finalized || r.stripped || r.deleted) {
      console.log(`🧹 Звонки: закрыто повисших ${r.finalized}, очищено SDP ${r.stripped}, удалено старых записей ${r.deleted}.`);
    }
  } catch (e) {
    console.error('⚠️  Ошибка при очистке данных звонков (не критично):', e.message);
  }
}

// После завершения звонка — небольшая отложенная уборка (с дебаунсом: если
// звонки идут один за другим, она выполнится один раз, после последнего).
let callSweepTimer = null;
function scheduleCallSweepAfterCall() {
  if (callSweepTimer) clearTimeout(callSweepTimer);
  callSweepTimer = setTimeout(() => { callSweepTimer = null; runCallSweep(); }, 2 * 60 * 1000);
  if (callSweepTimer.unref) callSweepTimer.unref();
}

function leaveGroupCall(conversationId, userId) {
  const room = groupCallRooms.get(conversationId);
  if (!room || !room.has(userId)) return;
  room.delete(userId);
  room.forEach((uid) => sendToUser(uid, { type: 'group-call-peer-left', conversationId, userId }));
  const conv = db.findById('conversations', conversationId);
  if (conv) broadcastToConversation(conv, { type: 'group-call-count', conversationId, count: room.size }, null);
  if (room.size === 0) {
    groupCallRooms.delete(conversationId);
    const callId = groupCallRecordIds.get(conversationId);
    if (callId) {
      const rec = db.findById('calls', callId);
      if (rec) db.update('calls', callId, { status: 'ended', endedAt: Date.now(), durationSec: Math.max(0, Math.round((Date.now() - rec.startedAt) / 1000)) });
      groupCallRecordIds.delete(conversationId);
      scheduleCallSweepAfterCall();
    }
  }
}


// ---------- API маршруты ----------
async function handleAPI(req, res, pathname, query = {}) {
  const method = req.method;

  // Проверка занятости логина — используется на экранах входа (логин должен
  // существовать) и регистрации (логин должен быть свободен), без авторизации.
  if (pathname === '/api/check-username' && method === 'POST') {
    const body = await readBody(req);
    const username = (body.username || '').trim();
    if (!username) return sendJSON(res, 400, { error: 'Укажите логин' });
    const exists = !!db.findOneBy('users', 'username', username);
    return sendJSON(res, 200, { exists });
  }

  // Открыта ли регистрация — без авторизации (спрашивает экран входа).
  if (pathname === '/api/registration-status' && method === 'GET') {
    return sendJSON(res, 200, { open: isRegistrationOpen() });
  }

  if (pathname === '/api/register' && method === 'POST') {
    if (!isRegistrationOpen()) {
      return sendJSON(res, 403, { error: 'Регистрация закрыта администратором', registrationClosed: true });
    }
    const body = await readBody(req);
    const { username, password, displayName, description } = body;
    if (!username || !password || password.length < 4) {
      return sendJSON(res, 400, { error: 'Укажите логин и пароль (минимум 4 символа)' });
    }
    if (db.findOneBy('users', 'username', username)) {
      return sendJSON(res, 400, { error: 'Такой логин уже занят' });
    }
    const bio = (description || '').trim();
    const user = db.insert('users', {
      id: genId('u'),
      username,
      displayName: displayName || username,
      passwordHash: hashPassword(password),
      isBot: false,
      avatar: '',
      status: bio || 'Привет! Я в Asteria',
      theme: 'light',
      chatWallpaper: '',
      discoverable: true,
      createdAt: Date.now(),
    });
    // авто-DM с ботом-помощником (BotCreator теперь не добавляется
    // автоматически — как и каналы, его нужно найти через глобальный поиск)
    ensureDMExists(user.id, BOT_ID);
    ensureCodeBotChat(user.id, false);
    const token = genId('sess');
    db.insert('sessions', {
      id: token, token, userId: user.id, createdAt: Date.now(), lastSeenAt: Date.now(),
      userAgent: req.headers['user-agent'] || '', ip: getClientIp(req),
    });
    res.setHeader('Set-Cookie', serializeCookie('asteria_session', token, { maxAge: SESSION_MAX_AGE }));
    return sendJSON(res, 200, { user: publicUser(user) });
  }

  if (pathname === '/api/login' && method === 'POST') {
    const body = await readBody(req);
    const { username, password } = body;
    const user = db.findOneBy('users', 'username', username);
    if (!user || user.isBot || !verifyPassword(password || '', user.passwordHash)) {
      return sendJSON(res, 401, { error: 'Неверный логин или пароль' });
    }
    const token = genId('sess');
    db.insert('sessions', {
      id: token, token, userId: user.id, createdAt: Date.now(), lastSeenAt: Date.now(),
      userAgent: req.headers['user-agent'] || '', ip: getClientIp(req),
    });
    res.setHeader('Set-Cookie', serializeCookie('asteria_session', token, { maxAge: SESSION_MAX_AGE }));
    return sendJSON(res, 200, { user: publicUser(user) });
  }

  // ---- Вход по коду через бота «Коды Asteria» ----
  // Новое (неавторизованное) устройство запрашивает код для логина.
  if (pathname === '/api/code-login/create' && method === 'POST') {
    const body = await readBody(req);
    const ip = getClientIp(req);
    if (hitLimit(codeCreateHits, ip, 10, 10 * 60 * 1000)) {
      return sendJSON(res, 429, { error: 'Слишком много запросов. Подождите несколько минут.' });
    }
    const target = db.findOneBy('users', 'username', String(body.username || '').trim());
    if (!target || target.isBot) return sendJSON(res, 404, { error: 'Пользователь не найден' });
    // Старые неподтверждённые коды этого устройства для этого аккаунта отзываем.
    for (const [id, t] of codeTickets) {
      if (t.userId === target.id && t.ip === ip && t.status !== 'confirmed') codeTickets.delete(id);
    }
    let code;
    do {
      code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    } while ([...codeTickets.values()].some((t) => t.userId === target.id && t.code === code));
    const id = genId('cl');
    const now = Date.now();
    codeTickets.set(id, {
      userId: target.id, code, createdAt: now, expiresAt: now + CODE_TICKET_TTL_MS, status: 'pending',
      ua: req.headers['user-agent'] || '', ip,
    });
    return sendJSON(res, 200, { id, code: code.slice(0, 3) + ' ' + code.slice(3), expiresAt: now + CODE_TICKET_TTL_MS, bot: CODEBOT_USERNAME, botName: CODEBOT_NAME });
  }

  // Опрос статуса; при подтверждении ботом выдаём сессию ЭТОМУ устройству (один раз).
  const codePollMatch = pathname.match(/^\/api\/code-login\/([^/]+)\/poll$/);
  if (codePollMatch && method === 'GET') {
    const tid = codePollMatch[1];
    const ticket = codeTickets.get(tid);
    if (!ticket) return sendJSON(res, 200, { status: 'expired' });
    if (Date.now() > ticket.expiresAt) { codeTickets.delete(tid); return sendJSON(res, 200, { status: 'expired' }); }
    if (ticket.status === 'denied') { codeTickets.delete(tid); return sendJSON(res, 200, { status: 'denied' }); }
    if (ticket.status !== 'confirmed') return sendJSON(res, 200, { status: ticket.status });
    codeTickets.delete(tid);
    const targetUser = db.findById('users', ticket.userId);
    if (!targetUser) return sendJSON(res, 200, { status: 'expired' });
    const token = genId('sess');
    db.insert('sessions', {
      id: token, token, userId: targetUser.id, createdAt: Date.now(), lastSeenAt: Date.now(),
      userAgent: req.headers['user-agent'] || '', ip: getClientIp(req),
    });
    res.setHeader('Set-Cookie', serializeCookie('asteria_session', token, { maxAge: SESSION_MAX_AGE }));
    return sendJSON(res, 200, { status: 'confirmed', user: publicUser(targetUser) });
  }

  if (pathname === '/api/logout' && method === 'POST') {
    const cookies = parseCookies(req.headers.cookie);
    const token = cookies['asteria_session'];
    if (token) {
      db.remove('sessions', token);
    }
    res.setHeader('Set-Cookie', serializeCookie('asteria_session', '', { maxAge: 0 }));
    return sendJSON(res, 200, { ok: true });
  }

  // Создать тикет для входа по QR-коду — без авторизации (это как раз
  // делает НЕавторизованное устройство, которое хочет войти).
  if (pathname === '/api/qr-login/create' && method === 'POST') {
    const id = genId('qr');
    const now = Date.now();
    qrTickets.set(id, { createdAt: now, expiresAt: now + QR_TICKET_TTL_MS, status: 'pending', userId: null });
    return sendJSON(res, 200, { id, expiresAt: now + QR_TICKET_TTL_MS });
  }

  // Опрос статуса тикета — тоже без авторизации (тот же неавторизованный
  // "новый" браузер). Как только видим confirmed — заводим сессию ПРЯМО
  // ЗДЕСЬ, этим самым запросом, чтобы User-Agent/IP в сессии были от
  // настоящего нового устройства, а не от того, кто подтверждал сканом.
  const qrPollMatch = pathname.match(/^\/api\/qr-login\/([^/]+)\/poll$/);
  if (qrPollMatch && method === 'GET') {
    const ticket = qrTickets.get(qrPollMatch[1]);
    if (!ticket) return sendJSON(res, 200, { status: 'expired' });
    if (Date.now() > ticket.expiresAt) { qrTickets.delete(qrPollMatch[1]); return sendJSON(res, 200, { status: 'expired' }); }
    if (ticket.status !== 'confirmed') return sendJSON(res, 200, { status: ticket.status });
    // confirmed и ещё не "выдан" — выдаём один раз и сразу забываем тикет,
    // чтобы повторный опрос (или кто-то посторонний, узнавший id) не мог
    // получить вторую сессию по тому же тикету.
    const targetUser = db.findById('users', ticket.userId);
    qrTickets.delete(qrPollMatch[1]);
    if (!targetUser) return sendJSON(res, 200, { status: 'expired' });
    const token = genId('sess');
    db.insert('sessions', {
      id: token, token, userId: targetUser.id, createdAt: Date.now(), lastSeenAt: Date.now(),
      userAgent: req.headers['user-agent'] || '', ip: getClientIp(req),
    });
    res.setHeader('Set-Cookie', serializeCookie('asteria_session', token, { maxAge: SESSION_MAX_AGE }));
    return sendJSON(res, 200, { status: 'confirmed', user: publicUser(targetUser) });
  }

  // Проверка обновлений Android-приложения — без авторизации, чтобы
  // приложение могло спросить сразу при запуске, даже до входа в аккаунт.
  // Никаких приватных данных тут нет, только номер версии и заметки.
  // Лёгкая проверка "свежести" веб-клиента, без авторизации — вызывается
  // из app.js при каждом возврате приложения на передний план (важно для
  // iOS home-screen приложений, см. комментарий у BUILD_ID выше).
  if (pathname === '/api/web/build' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify({ build: BUILD_ID }));
    return;
  }

  // БАГ: ссылки на профиль и QR-коды строились из location.origin —
  // адреса, который браузер использовал ПРЯМО СЕЙЧАС, чтобы открыть
  // страницу. Если сервер настроен на нормальный домен (PUBLIC_HOST=
  // messenger.example.com, см. README — именно на него выписывается HTTPS-
  // сертификат), но конкретный человек в моменте зашёл по голому IP
  // (например, по старой ссылке, из истории браузера, или потому что так
  // было проще ввести вручную) — ссылка на его профиль/QR-код получалась
  // с тем же голым IP, хотя официальный, "сертифицированный" адрес сервиса
  // — это домен. Отдаём канонический публичный адрес отдельным эндпоинтом,
  // чтобы buildProfileLink() в app.js могла использовать именно его, а не
  // то, чем угодно оказался location.origin в конкретной вкладке.
  if (pathname === '/api/public-config' && method === 'GET') {
    const configuredHost = (process.env.PUBLIC_HOST || '').split(',')[0].trim() || null;
    return sendJSON(res, 200, { publicOrigin: configuredHost ? `https://${configuredHost}` : null });
  }

  if (pathname === '/api/app/version' && method === 'GET') {
    const release = readAppReleaseMeta();
    // release.enabled === false — админ выключил автообновление (см.
    // /api/admin/app-release/toggle) — для клиентов (и нативного диалога, и
    // веб-баннера) это неотличимо от "обновление ещё не публиковали".
    if (!release || !release.enabled) return sendJSON(res, 200, { available: false });
    return sendJSON(res, 200, {
      available: true,
      versionCode: release.versionCode,
      versionName: release.versionName,
      notes: release.notes || '',
      sizeBytes: release.sizeBytes || 0,
      url: '/api/app/download',
    });
  }

  // Скачивание самого APK — тоже без авторизации: системный установщик
  // Android сам открывает эту ссылку, никакой сессии/куки у него нет.
  if (pathname === '/api/app/download' && method === 'GET') {
    const release = readAppReleaseMeta();
    // Выключенное автообновление (release.enabled === false) — файл вообще
    // перестаёт раздаваться, даже по прямой ссылке, не только пропадает из
    // /api/app/version.
    if (!release || !release.enabled || !fs.existsSync(APP_RELEASE_APK_PATH)) return sendJSON(res, 404, { error: 'Обновление недоступно' });
    const stat = fs.statSync(APP_RELEASE_APK_PATH);
    res.writeHead(200, {
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Length': stat.size,
      'Content-Disposition': `attachment; filename="asteria-${release.versionName}.apk"`,
      'Cache-Control': 'no-store',
    });
    fs.createReadStream(APP_RELEASE_APK_PATH).pipe(res);
    return;
  }

  // Всё что ниже требует авторизации
  const user = getUserFromReq(req);
  if (!user) return sendJSON(res, 401, { error: 'Не авторизован' });

  if (pathname === '/api/me' && method === 'GET') {
    return sendJSON(res, 200, { user: publicUser(user) });
  }

  // ---------- AirPin: ключи и мост mesh <-> интернет ----------
  // Ключи нужны клиенту, чтобы шифровать/читать конверты без сервера (офлайн).
  // Отдаём только ключи чатов, в которых пользователь состоит, и его личный
  // ключ подписи. Клиент кеширует их и использует, когда интернета нет.
  if (pathname === '/api/airpin/keys' && method === 'GET') {
    const convs = {};
    userConversations(user.id).forEach((c) => { convs[c.id] = airpin.convKey(c.id).toString('base64'); });
    return sendJSON(res, 200, { v: 1, userId: user.id, userKey: airpin.userKey(user.id).toString('base64'), convKeys: convs, serverTime: Date.now() });
  }

  // Устройство-мост (у него есть интернет) заливает сюда конверты, собранные
  // в mesh, и в ответ получает сообщения для соседей без интернета.
  //   body: { envelopes: [...], peers: [{ u: userId, since: ms }] }
  //   ответ: { results: {envId: 'ok'|'dup'|'rejected:<причина>'}, deliver: [envelopes], serverTime }
  if (pathname === '/api/airpin/ingest' && method === 'POST') {
    const body = await readBody(req, 2 * 1024 * 1024);
    const envelopes = Array.isArray(body.envelopes) ? body.envelopes.slice(0, 200) : [];
    const results = {};
    for (const env of envelopes) {
      const id = env && typeof env.id === 'string' ? env.id : null;
      if (!id) continue;
      if (airpin.wasSeen(id) || db.findById('messages', id)) { results[id] = 'dup'; continue; }
      const opened = airpin.open(env);
      if (!opened.ok) { results[id] = 'rejected:' + opened.reason; continue; }
      const author = db.findById('users', env.f);
      const conv = db.findById('conversations', env.c);
      if (!author || !conv || !conv.participants.includes(author.id) && conv.ownerId !== author.id) { results[id] = 'rejected:member'; continue; }
      const p = opened.plain;
      let created = null;
      try {
        handleWSMessage(author, { send() {} }, {
          type: 'message',
          conversationId: conv.id,
          msgType: p.mt,
          content: p.mt === 'text' ? p.c : '',
          meta: p.mt === 'location' ? (p.m || null) : null,
          replyToId: typeof p.r === 'string' ? p.r : null,
        }, {
          airpinId: id,
          createdAt: Math.min(Date.now(), Math.max(env.t, Date.now() - 7 * 24 * 3600 * 1000)),
          onCreated: (m) => { created = m; },
        });
      } catch (err) {
        console.error('AirPin ingest error:', err);
      }
      airpin.markSeen(id); // и успешные, и отклонённые (блок/нет прав) — повторять бессмысленно
      results[id] = created ? 'ok' : 'rejected:blocked';
    }

    // Downlink: что нового для соседей моста, у которых нет интернета.
    const deliver = [];
    const peers = Array.isArray(body.peers) ? body.peers.slice(0, 30) : [];
    const floor = Date.now() - 3 * 24 * 3600 * 1000;
    for (const peer of peers) {
      if (!peer || typeof peer.u !== 'string' || deliver.length >= 120) continue;
      if (!db.findById('users', peer.u)) continue;
      const since = Math.max(Number(peer.since) || 0, floor);
      for (const c of userConversations(peer.u)) {
        if (deliver.length >= 120) break;
        const { items } = db.findPageBy('messages', 'conversationId', c.id, { beforeCreatedAt: null, limit: 30 });
        const fresh = items.filter((m) => m.createdAt > since && m.senderId !== peer.u && (m.msgType === 'text' || m.msgType === 'location'));
        decryptMessages(fresh).forEach((m) => {
          if (deliver.length >= 120) return;
          const meta = m.msgType === 'location' && m.meta ? { lat: m.meta.lat, lng: m.meta.lng } : null;
          airpin.markSeen(m.id);
          const sealed = airpin.seal(
            { mt: m.msgType, c: m.content || '', r: m.replyToId || null, m: meta, mid: m.id, aid: (m.meta && m.meta.airpinId) || null },
            { id: m.id, convId: c.id, fromId: m.senderId, t: m.createdAt, ttl: 12 }
          );
          sealed.dl = 1; // downlink: мост не заливает такие конверты обратно на сервер
          deliver.push(sealed);
        });
      }
    }
    return sendJSON(res, 200, { results, deliver, serverTime: Date.now() });
  }

  // ---------- Web Push подписки ----------
  // Публичный ключ VAPID, которым клиент должен подписаться (applicationServerKey
  // в pushManager.subscribe) — см. subscribeToPush() в app.js.
  if (pathname === '/api/push/vapid-public-key' && method === 'GET') {
    return sendJSON(res, 200, { publicKey: vapidKeys.publicKey });
  }

  // Сохраняет подписку браузера/PWA на push. endpoint однозначно определяет
  // конкретную подписку конкретного браузера на конкретном устройстве —
  // если он уже был сохранён (переустановка, повторный вход и т.п.),
  // обновляем запись, а не плодим дубликаты.
  if (pathname === '/api/push/subscribe' && method === 'POST') {
    const body = await readBody(req);
    const endpoint = String((body && body.endpoint) || '').trim();
    const p256dh = body && body.keys && String(body.keys.p256dh || '').trim();
    const auth = body && body.keys && String(body.keys.auth || '').trim();
    if (!endpoint || !p256dh || !auth) return sendJSON(res, 400, { error: 'Некорректная push-подписка' });
    // Проверяем сразу на этом шаге, а не только в момент отправки push —
    // если ключ браузера не декодируется в корректную точку кривой P-256,
    // лучше явно отклонить подписку с понятной причиной в логе, чем молча
    // сохранить нерабочие данные и упасть намного позже при реальной
    // отправке (см. ERR_CRYPTO_ECDH_INVALID_PUBLIC_KEY).
    let p256dhBuf, authBuf;
    try {
      p256dhBuf = webpush.fromB64url(p256dh);
      authBuf = webpush.fromB64url(auth);
    } catch (e) {
      console.error(`⚠️ Push-подписка отклонена: не удалось декодировать base64 (${e.message})`);
      return sendJSON(res, 400, { error: 'Некорректный формат ключей подписки' });
    }
    if (p256dhBuf.length !== 65 || p256dhBuf[0] !== 0x04) {
      console.error(`⚠️ Push-подписка отклонена: p256dh имеет длину ${p256dhBuf.length} байт (ожидалось 65, первый байт 0x04), первые байты: ${p256dhBuf.slice(0, 8).toString('hex')}, исходная строка (${p256dh.length} симв.): ${p256dh}`);
      return sendJSON(res, 400, { error: 'Некорректный публичный ключ подписки (p256dh)' });
    }
    // Проверка длины/префикса выше — только поверхностная. Настоящая
    // проверка "лежит ли эта точка на самой кривой P-256" — единственная,
    // которая по-настоящему предсказывает ERR_CRYPTO_ECDH_INVALID_PUBLIC_KEY
    // при реальной отправке push — это попытка computeSecret прямо сейчас,
    // с одноразовым ключом сервера (результат никуда не идёт, только
    // проверяем, что вызов не бросает исключение).
    try {
      const probe = crypto.createECDH('prime256v1');
      probe.generateKeys();
      probe.computeSecret(p256dhBuf);
    } catch (e) {
      console.error(`⚠️ Push-подписка отклонена: p256dh не является точкой на кривой P-256 (${e.code || e.message}). Полный base64url (${p256dh.length} симв.): ${p256dh} — hex (${p256dhBuf.length} байт): ${p256dhBuf.toString('hex')}`);
      return sendJSON(res, 400, { error: 'Ключ подписки не проходит проверку кривой P-256' });
    }
    if (authBuf.length !== 16) {
      console.error(`⚠️ Push-подписка отклонена: auth имеет длину ${authBuf.length} байт (ожидалось 16), исходная строка (${auth.length} симв.): ${auth}`);
      return sendJSON(res, 400, { error: 'Некорректный auth-секрет подписки' });
    }
    const existing = db.findOneBy('pushTokens', 'endpoint', endpoint);
    if (existing) {
      db.update('pushTokens', existing.id, { userId: user.id, p256dh, auth, userAgent: String(req.headers['user-agent'] || '').slice(0, 300), updatedAt: Date.now() });
    } else {
      db.insert('pushTokens', {
        id: genId('push'),
        userId: user.id,
        endpoint,
        p256dh,
        auth,
        userAgent: String(req.headers['user-agent'] || '').slice(0, 300),
        createdAt: Date.now(),
      });
    }
    console.log(`🔔 Push-подписка сохранена: пользователь ${user.id}, endpoint ${endpoint.slice(0, 60)}…`);
    return sendJSON(res, 200, { ok: true });
  }

  // Отписка (пользователь выключил уведомления в настройках, либо клиент
  // сам обнаружил, что подписка истекла — pushManager.subscribe отдаёт
  // новый endpoint при ротации, старый нужно явно удалить).
  if (pathname === '/api/push/unsubscribe' && method === 'POST') {
    const body = await readBody(req);
    const endpoint = String((body && body.endpoint) || '').trim();
    if (!endpoint) return sendJSON(res, 400, { error: 'Не указан endpoint' });
    const existing = db.findOneBy('pushTokens', 'endpoint', endpoint);
    if (existing && existing.userId === user.id) db.remove('pushTokens', existing.id);
    return sendJSON(res, 200, { ok: true });
  }

  // Баннер для текущего пользователя — null, если баннера нет, он выключен
  // админом, или сам пользователь уже закрыл именно эту версию крестиком.
  if (pathname === '/api/banner' && method === 'GET') {
    const banner = readBanner();
    if (!banner || !banner.enabled || banner.id === user.dismissedBannerId) {
      return sendJSON(res, 200, { banner: null });
    }
    return sendJSON(res, 200, { banner: { id: banner.id, title: banner.title, description: banner.description, imageUrl: banner.imageUrl } });
  }

  // Закрытие баннера крестиком — только для этого пользователя, остальных не касается.
  if (pathname === '/api/banner/dismiss' && method === 'POST') {
    const body = await readBody(req);
    const bannerId = String(body.bannerId || '');
    if (!bannerId) return sendJSON(res, 400, { error: 'Не указан id баннера' });
    db.update('users', user.id, { dismissedBannerId: bannerId });
    return sendJSON(res, 200, { ok: true });
  }

  if (pathname === '/api/me' && method === 'PATCH') {
    const body = await readBody(req);
    const patch = {};
    ['displayName', 'status', 'avatar', 'theme', 'chatWallpaper', 'language'].forEach((k) => {
      if (body[k] !== undefined) patch[k] = body[k];
    });
    if (patch.language !== undefined && !['ru', 'en'].includes(patch.language)) {
      return sendJSON(res, 400, { error: 'Неизвестный язык' });
    }
    // Рингтон звонка: "classic" — встроенный звук (public/ringtones/classic.mp3),
    // "custom" — свой загруженный файл (см. /api/upload с kind: 'ringtone'
    // ниже). Здесь только переключаем выбор и/или сохраняем ссылку на уже
    // загруженный файл — сама загрузка отдельным запросом.
    if (body.ringtoneType !== undefined) {
      if (!['classic', 'custom'].includes(body.ringtoneType)) return sendJSON(res, 400, { error: 'Неизвестный тип рингтона' });
      patch.ringtoneType = body.ringtoneType;
    }
    if (body.ringtoneUrl !== undefined) patch.ringtoneUrl = body.ringtoneUrl;
    if (typeof patch.status === 'string' && patch.status.length > STATUS_MAX_REGULAR) {
      return sendJSON(res, 400, { error: 'Максимум 140 символов в «О себе»' });
    }
    if (body.discoverable !== undefined) patch.discoverable = !!body.discoverable;
    if (body.whoCanMessage !== undefined) {
      if (!['all', 'contacts', 'nobody'].includes(body.whoCanMessage)) return sendJSON(res, 400, { error: 'Некорректное значение' });
      patch.whoCanMessage = body.whoCanMessage;
    }
    if (body.whoCanCall !== undefined) {
      if (!['all', 'contacts', 'nobody'].includes(body.whoCanCall)) return sendJSON(res, 400, { error: 'Некорректное значение' });
      patch.whoCanCall = body.whoCanCall;
    }
    if (body.hideTyping !== undefined) patch.hideTyping = !!body.hideTyping;
    // Скрыть статус «в сети» от всех, кроме себя — (см. isVisiblyOnline()/broadcastPresence() ниже).
    if (body.hideOnlineStatus !== undefined) {
      patch.hideOnlineStatus = !!body.hideOnlineStatus;
    }
    // Скрыть отметки о прочтении (галочки/точки «прочитано») от собеседников
    // — отдельная настройка от скрытия статуса «в сети».
    if (body.hideReadStatus !== undefined) {
      patch.hideReadStatus = !!body.hideReadStatus;
    }
    if (body.username !== undefined) {
      const newUsername = String(body.username).trim();
      if (newUsername.length < 3) return sendJSON(res, 400, { error: 'Логин должен быть не короче 3 символов' });
      const existing = db.findOneBy('users', 'username', newUsername);
      if (existing && existing.id !== user.id) return sendJSON(res, 400, { error: 'Такой логин уже занят' });
      patch.username = newUsername;
    }
    const updated = db.update('users', user.id, patch);
    return sendJSON(res, 200, { user: publicUser(updated) });
  }

  if (pathname === '/api/me/password' && method === 'POST') {
    const body = await readBody(req);
    const { currentPassword, newPassword } = body;
    if (!newPassword || newPassword.length < 4) return sendJSON(res, 400, { error: 'Новый пароль должен быть не короче 4 символов' });
    if (!verifyPassword(currentPassword || '', user.passwordHash)) {
      return sendJSON(res, 400, { error: 'Текущий пароль указан неверно' });
    }
    db.update('users', user.id, { passwordHash: hashPassword(newPassword) });
    return sendJSON(res, 200, { ok: true });
  }

  // ---------- Устройства (управление сессиями) ----------
  // Список всех активных входов текущего пользователя — для раздела
  // "Настройки → Устройства". Сортируем от недавно активных к давним,
  // текущую сессию (по которой пришёл этот самый запрос) помечаем флагом
  // current, чтобы на клиенте её можно было показать первой и без кнопки
  // "Завершить" (выходить с текущего устройства — это обычный "Выйти").
  if (pathname === '/api/sessions' && method === 'GET') {
    const currentSession = getSession(req);
    const sessions = db.findManyBy('sessions', 'userId', user.id)
      .sort((a, b) => (b.lastSeenAt || b.createdAt || 0) - (a.lastSeenAt || a.createdAt || 0))
      .map((s) => ({
        id: s.id,
        device: deviceLabelFromUA(s.userAgent),
        ip: s.ip || '',
        createdAt: s.createdAt || null,
        lastSeenAt: s.lastSeenAt || s.createdAt || null,
        current: !!currentSession && s.id === currentSession.id,
      }));
    return sendJSON(res, 200, { sessions });
  }

  // Завершить один конкретный сеанс (выйти с другого устройства). Нельзя
  // завершить чужую сессию — только свои же (проверяем userId).
  const sessionRevokeMatch = pathname.match(/^\/api\/sessions\/([^/]+)$/);
  if (sessionRevokeMatch && method === 'DELETE') {
    const target = db.findById('sessions', sessionRevokeMatch[1]);
    if (!target || target.userId !== user.id) return sendJSON(res, 404, { error: 'Сеанс не найден' });
    db.remove('sessions', target.id);
    const currentSession = getSession(req);
    const wasCurrent = !!currentSession && currentSession.id === target.id;
    // Если завершили именно ту сессию, с которой сейчас пришёл запрос —
    // заодно и куку у клиента снимаем, иначе браузер продолжит слать
    // теперь уже недействительный токен.
    if (wasCurrent) res.setHeader('Set-Cookie', serializeCookie('asteria_session', '', { maxAge: 0 }));
    return sendJSON(res, 200, { ok: true, wasCurrent });
  }

  // Завершить все сеансы, кроме текущего — «выйти на всех других устройствах».
  if (pathname === '/api/sessions/revoke-others' && method === 'POST') {
    const currentSession = getSession(req);
    const others = db.findManyBy('sessions', 'userId', user.id)
      .filter((s) => !currentSession || s.id !== currentSession.id);
    others.forEach((s) => db.remove('sessions', s.id));
    return sendJSON(res, 200, { ok: true, revoked: others.length });
  }

  // Подтверждение входа по QR-коду — вызывается уже авторизованным
  // устройством (тем, которым отсканировали код или куда вручную ввели
  // код). Само создание сессии для нового устройства произойдёт позже, при
  // его следующем опросе (см. /api/qr-login/:id/poll выше).
  const qrConfirmMatch = pathname.match(/^\/api\/qr-login\/([^/]+)\/confirm$/);
  if (qrConfirmMatch && method === 'POST') {
    const ticket = qrTickets.get(qrConfirmMatch[1]);
    if (!ticket) return sendJSON(res, 404, { error: 'Код недействителен или уже устарел' });
    if (Date.now() > ticket.expiresAt) { qrTickets.delete(qrConfirmMatch[1]); return sendJSON(res, 404, { error: 'Код устарел, обновите его на другом устройстве' }); }
    if (ticket.status === 'confirmed') return sendJSON(res, 400, { error: 'Этот код уже подтверждён' });
    ticket.status = 'confirmed';
    ticket.userId = user.id;
    return sendJSON(res, 200, { ok: true });
  }

  // Блокировка / разблокировка человека (личные чаты и звонки, см. userBlocked).
  if (pathname === '/api/blocks' && method === 'POST') {
    const body = await readBody(req);
    const targetId = String(body.userId || '');
    const target = targetId && db.findById('users', targetId);
    if (!target) return sendJSON(res, 404, { error: 'Пользователь не найден' });
    if (target.id === user.id) return sendJSON(res, 400, { error: 'Нельзя заблокировать себя' });
    if (target.isBot) return sendJSON(res, 400, { error: 'Ботов блокировать нельзя' });
    const me = db.findById('users', user.id);
    const blocked = Array.isArray(me.blockedUsers) ? me.blockedUsers : [];
    if (!blocked.includes(target.id)) db.update('users', me.id, { blockedUsers: [...blocked, target.id] });
    return sendJSON(res, 200, { ok: true, isBlocked: true });
  }
  if (pathname === '/api/blocks' && method === 'GET') {
    const me = db.findById('users', user.id);
    const ids = Array.isArray(me.blockedUsers) ? me.blockedUsers : [];
    const users = ids.map((id) => db.findById('users', id)).filter(Boolean)
      .map((u) => ({ id: u.id, displayName: u.displayName || u.username || '?', username: u.username || '', avatar: u.avatar || '' }));
    return sendJSON(res, 200, { users });
  }
  const blockItemMatch = pathname.match(/^\/api\/blocks\/([^/]+)$/);
  if (blockItemMatch && method === 'DELETE') {
    const me = db.findById('users', user.id);
    const blocked = Array.isArray(me.blockedUsers) ? me.blockedUsers : [];
    if (blocked.includes(blockItemMatch[1])) db.update('users', me.id, { blockedUsers: blocked.filter((id) => id !== blockItemMatch[1]) });
    return sendJSON(res, 200, { ok: true, isBlocked: false });
  }

  const userProfileMatch = pathname.match(/^\/api\/users\/([^/]+)$/);
  if (userProfileMatch && method === 'GET') {
    const target = db.findById('users', userProfileMatch[1]);
    if (!target) return sendJSON(res, 404, { error: 'Пользователь не найден' });
    const out = publicUserForViewer(target, user.id);
    // Отпечаток ключа шифрования переписки с этим человеком — см. комментарий
    // у conversationKeyFingerprint в lib/util.js. Для собственного профиля
    // (target.id === user.id) переписки с самим собой нет — не показываем.
    if (out && target.id !== user.id) {
      const conv = ensureDMExists(user.id, target.id);
      out.encryptionKeyFingerprint = conversationKeyFingerprint(conv.id);
      // Статус "в контактах" — см. комментарий у contacts-таблицы в db.js.
      // Тот же приоритет источников имени, что и в enrichConversation ниже
      // (список чатов): сначала новая таблица contacts, а если там пусто —
      // старое имя, заданное ещё при создании чата через поиск (compose-
      // флоу, conversations.nicknames). ФИКС: раньше тут проверялась
      // только contacts, и имя, заданное старым способом, не показывалось
      // в самом профиле — хотя в списке чатов уже было видно.
      out.isBlocked = userBlocked(user.id, target.id);
      const contact = db.findById('contacts', `contact_${user.id}_${target.id}`);
      const legacyNickname = conv.nicknames && conv.nicknames[user.id];
      out.contactNickname = (contact && contact.nickname) || legacyNickname || '';
      // Если имя когда-либо было задано (пусть даже только старым способом,
      // без явного "Добавить в контакты") — по смыслу это уже контакт:
      // иначе получилось бы странно — сверху написано заданное имя, а
      // снизу всё равно кнопка "Добавить в контакты" вместо "Изменить".
      out.isContact = !!contact || !!legacyNickname;
    }
    return sendJSON(res, 200, { user: out });
  }

  // ---------- Контакты ----------
  // Добавить человека в контакты (кнопка "Добавить в контакты" в профиле —
  // см. openProfilePage в app.js). Идемпотентно: повторный вызов на уже
  // добавленного контакта просто обновит nickname, если он передан, не
  // создавая дубликатов (id составной, см. комментарий в lib/db.js).
  if (pathname === '/api/contacts' && method === 'POST') {
    const body = await readBody(req);
    const targetId = String((body && body.userId) || '').trim();
    if (!targetId || targetId === user.id) return sendJSON(res, 400, { error: 'Некорректный пользователь' });
    const target = db.findById('users', targetId);
    if (!target) return sendJSON(res, 404, { error: 'Пользователь не найден' });
    const nickname = String((body && body.nickname) || '').trim().slice(0, 60);
    const id = `contact_${user.id}_${targetId}`;
    const existing = db.findById('contacts', id);
    const record = existing
      ? db.update('contacts', id, { nickname: nickname || existing.nickname || '' })
      : db.insert('contacts', { id, ownerId: user.id, contactUserId: targetId, nickname, createdAt: Date.now() });
    return sendJSON(res, 200, { contact: record });
  }

  // Изменить локальное имя контакта (кнопка "Изменить" в правом верхнем
  // углу профиля — показывается, если человек уже в контактах, в том числе
  // "по факту" — см. isContact выше, куда попадает и старое legacy-имя).
  // Ведёт себя как upsert: формальной записи в contacts могло ещё не быть
  // (например, имя раньше было задано только старым способом при создании
  // чата) — в этом случае создаём её прямо сейчас, а не требуем, чтобы она
  // существовала заранее.
  const contactPatchMatch = pathname.match(/^\/api\/contacts\/([^/]+)$/);
  if (contactPatchMatch && method === 'PATCH') {
    const targetId = contactPatchMatch[1];
    if (targetId === user.id) return sendJSON(res, 400, { error: 'Некорректный пользователь' });
    if (!db.findById('users', targetId)) return sendJSON(res, 404, { error: 'Пользователь не найден' });
    const id = `contact_${user.id}_${targetId}`;
    const existing = db.findById('contacts', id);
    const body = await readBody(req);
    const nickname = String((body && body.nickname) || '').trim().slice(0, 60);
    const record = existing
      ? db.update('contacts', id, { nickname })
      : db.insert('contacts', { id, ownerId: user.id, contactUserId: targetId, nickname, createdAt: Date.now() });
    return sendJSON(res, 200, { contact: record });
  }

  // Убрать из контактов (доступно из того же диалога изменения имени).
  if (contactPatchMatch && method === 'DELETE') {
    const id = `contact_${user.id}_${contactPatchMatch[1]}`;
    db.remove('contacts', id);
    return sendJSON(res, 200, { ok: true });
  }

  if (pathname === '/api/users' && method === 'GET') {
    const q = String(query.q || '').trim().toLowerCase();
    // Без поискового запроса список не отдаём — иначе это был бы публичный
    // каталог всех пользователей. Ищем только по логину, минимум 2 символа,
    // и только среди тех, кто разрешил находить себя по логину.
    if (q.length < 2) return sendJSON(res, 200, { users: [] });
    const users = db.all('users')
      .filter((u) => u.id !== user.id && (!u.isBot || u.isCustomBot) && u.discoverable !== false && u.username.toLowerCase().includes(q))
      .slice(0, 20)
      .map(publicUser);
    return sendJSON(res, 200, { users });
  }

  if (pathname === '/api/conversations' && method === 'GET') {
    const convs = userConversations(user.id).sort((a, b) => (b.lastMessageAt || 0) - (a.lastMessageAt || 0));
    const enriched = convs.map((c) => enrichConversation(c, user.id));
    return sendJSON(res, 200, { conversations: enriched });
  }

  if (pathname === '/api/conversations' && method === 'POST') {
    const body = await readBody(req);
    if (body.type === 'dm') {
      const conv = ensureDMExists(user.id, body.userId);
      return sendJSON(res, 200, { conversation: enrichConversation(conv, user.id) });
    }
    if (body.type === 'channel') {
      const conv = db.insert('conversations', {
        id: genId('conv'),
        type: 'channel',
        name: body.name || 'Новый канал',
        avatar: body.avatar || '',
        ownerId: user.id,
        participants: [user.id],
        groupCallsEnabled: true,
        inviteCode: generateInviteCode(),
        createdAt: Date.now(),
      });
      return sendJSON(res, 200, { conversation: enrichConversation(conv, user.id) });
    }
    if (body.type === 'group') {
      const conv = db.insert('conversations', {
        id: genId('conv'),
        type: 'group',
        name: body.name || 'Новая группа',
        avatar: body.avatar || '',
        ownerId: user.id,
        participants: [user.id],
        groupCallsEnabled: true,
        inviteCode: generateInviteCode(),
        createdAt: Date.now(),
      });
      return sendJSON(res, 200, { conversation: enrichConversation(conv, user.id) });
    }
    return sendJSON(res, 400, { error: 'Некорректный тип' });
  }

  // Локальное имя контакта в личном чате — видно только тому, кто его задал.
  const nicknameMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/nickname$/);
  if (nicknameMatch && method === 'POST') {
    const conv = db.findById('conversations', nicknameMatch[1]);
    if (!conv || !conv.participants.includes(user.id)) return sendJSON(res, 404, { error: 'Не найдено' });
    const body = await readBody(req);
    const nicknames = { ...(conv.nicknames || {}) };
    const nickname = String(body.nickname || '').trim().slice(0, 60);
    if (nickname) nicknames[user.id] = nickname; else delete nicknames[user.id];
    const updated = db.update('conversations', conv.id, { nicknames });
    return sendJSON(res, 200, { conversation: enrichConversation(updated, user.id) });
  }

  // ---------- Приглашения по ссылке (группы и каналы) ----------
  // Формат ссылки на клиенте: <адрес сайта>/j/<inviteCode>, где inviteCode
  // уже сам начинается с "group_" или "channel_" — так по одной ссылке сразу
  // видно, куда она ведёт.
  const inviteInfoMatch = pathname.match(/^\/api\/invite\/([^/]+)$/);
  if (inviteInfoMatch && method === 'GET') {
    const conv = db.all('conversations').find((c) => c.inviteCode === String(inviteInfoMatch[1]).toLowerCase());
    if (!conv) return sendJSON(res, 404, { error: 'Ссылка недействительна или устарела' });
    const alreadyMember = conv.participants.includes(user.id) || conv.ownerId === user.id;
    return sendJSON(res, 200, {
      preview: {
        id: conv.id,
        type: conv.type,
        name: conv.name,
        avatar: conv.avatar || '',
        memberCount: (conv.participants || []).length,
        alreadyMember,
      },
    });
  }
  const inviteJoinMatch = pathname.match(/^\/api\/invite\/([^/]+)\/join$/);
  if (inviteJoinMatch && method === 'POST') {
    const conv = db.all('conversations').find((c) => c.inviteCode === String(inviteJoinMatch[1]).toLowerCase());
    if (!conv) return sendJSON(res, 404, { error: 'Ссылка недействительна или устарела' });
    if (!conv.participants.includes(user.id) && conv.ownerId !== user.id) {
      const participants = [...conv.participants, user.id];
      const updated = db.update('conversations', conv.id, { participants });
      broadcastToConversation(updated, { type: 'conversation-updated', conversation: updated }, null);
      return sendJSON(res, 200, { conversation: enrichConversation(updated, user.id) });
    }
    return sendJSON(res, 200, { conversation: enrichConversation(conv, user.id) });
  }

  const convMsgMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/messages$/);
  if (convMsgMatch && method === 'GET') {
    const convId = convMsgMatch[1];
    const conv = db.findById('conversations', convId);
    if (!conv) return sendJSON(res, 404, { error: 'Не найдено' });
    // Пагинация: отдаём последние N сообщений (по умолчанию 40), а не всю
    // историю чата разом — на слабом сервере/большой истории именно полная
    // выгрузка при каждом открытии чата и была причиной долгой (несколько
    // секунд) загрузки. ?before=<createdAt> — курсор для подгрузки более
    // старых сообщений при прокрутке ленты вверх (см. loadOlderMessages в
    // app.js).
    const limit = Math.max(1, Math.min(100, parseInt(query.limit, 10) || 40));
    const before = query.before ? Number(query.before) : null;
    const { items, hasMore } = db.findPageBy('messages', 'conversationId', convId, { beforeCreatedAt: before, limit });
    return sendJSON(res, 200, { messages: decryptMessages(items), hasMore });
  }

  const subMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/subscribe$/);
  if (subMatch && method === 'POST') {
    const conv = db.findById('conversations', subMatch[1]);
    if (!conv || (conv.type !== 'channel' && conv.type !== 'group')) return sendJSON(res, 404, { error: 'Не найдено' });
    if (!conv.participants.includes(user.id)) conv.participants.push(user.id);
    db.update('conversations', conv.id, { participants: conv.participants });
    return sendJSON(res, 200, { conversation: enrichConversation(conv, user.id) });
  }

  const unsubMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/unsubscribe$/);
  if (unsubMatch && method === 'POST') {
    const conv = db.findById('conversations', unsubMatch[1]);
    if (!conv || (conv.type !== 'channel' && conv.type !== 'group')) return sendJSON(res, 404, { error: 'Не найдено' });
    if (conv.ownerId === user.id) {
      const msg = conv.type === 'group' ? 'Владелец не может покинуть группу — удалите её' : 'Владелец не может отписаться — удалите канал';
      return sendJSON(res, 400, { error: msg });
    }
    const participants = (conv.participants || []).filter((p) => p !== user.id);
    const leavePatch = { participants };
    if (conv.admins && conv.admins[user.id]) {
      const admins = { ...conv.admins };
      delete admins[user.id];
      leavePatch.admins = admins;
    }
    const updated = db.update('conversations', conv.id, leavePatch);
    broadcastToConversation(updated, { type: 'conversation-updated', conversation: updated }, null);
    return sendJSON(res, 200, { ok: true });
  }

  const pinMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/pin$/);
  if (pinMatch && method === 'POST') {
    const conv = db.findById('conversations', pinMatch[1]);
    if (!conv) return sendJSON(res, 404, { error: 'Не найдено' });
    const body = await readBody(req);
    const pinned = !!body.pinned;
    let pinnedBy = conv.pinnedBy || [];
    if (pinned && !pinnedBy.includes(user.id)) pinnedBy = [...pinnedBy, user.id];
    if (!pinned) pinnedBy = pinnedBy.filter((id) => id !== user.id);
    const updated = db.update('conversations', conv.id, { pinnedBy });
    return sendJSON(res, 200, { conversation: enrichConversation(updated, user.id) });
  }

  // Закрепление СООБЩЕНИЯ внутри чата/канала (отдельно от закрепления самого
  // чата в списке слева, см. /pin выше) — показывается плашкой в шапке под
  // именем собеседника. В личных чатах закрепить/открепить может любой
  // участник, в каналах — только владелец канала или администратор сайта.
  const pinMsgMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/pin-message$/);
  if (pinMsgMatch && method === 'POST') {
    const conv = db.findById('conversations', pinMsgMatch[1]);
    if (!conv) return sendJSON(res, 404, { error: 'Не найдено' });
    const isMember = conv.type === 'dm' ? conv.participants.includes(user.id) :
      (conv.participants.includes(user.id) || conv.ownerId === user.id);
    if (!isMember) return sendJSON(res, 403, { error: 'Недостаточно прав' });
    if (conv.type === 'channel' && !convPerm(conv, user, 'pin')) {
      return sendJSON(res, 403, { error: 'Закреплять сообщения в канале могут только владелец и администраторы с таким правом' });
    }
    const body = await readBody(req);
    let pinnedMessageId = null;
    if (body.messageId) {
      const message = db.findById('messages', body.messageId);
      if (!message || message.conversationId !== conv.id) return sendJSON(res, 404, { error: 'Сообщение не найдено' });
      pinnedMessageId = message.id;
    }
    const updated = db.update('conversations', conv.id, { pinnedMessageId });
    broadcastToConversation(updated, { type: 'pin-update', conversationId: conv.id, pinnedMessage: pinnedMessageId ? decryptMessage(db.findById('messages', pinnedMessageId)) : null }, null);
    return sendJSON(res, 200, { conversation: enrichConversation(updated, user.id) });
  }

  const convItemMatch = pathname.match(/^\/api\/conversations\/([^/]+)$/);
  if (convItemMatch && method === 'PATCH') {
    const conv = db.findById('conversations', convItemMatch[1]);
    if (!conv) return sendJSON(res, 404, { error: 'Не найдено' });
    if (conv.type !== 'channel' && conv.type !== 'group') return sendJSON(res, 400, { error: 'Редактировать можно только каналы и группы' });
    if (!convCanManage(conv, user)) return sendJSON(res, 403, { error: 'Недостаточно прав' });
    const body = await readBody(req);
    const patch = {};
    const deny = () => sendJSON(res, 403, { error: 'Недостаточно прав для этого действия' });
    // Право проверяем только для реально меняющихся полей — клиент может
    // присылать и неизменённые значения, это не должно давать 403.
    const changed = (k) => body[k] !== undefined && JSON.stringify(body[k]) !== JSON.stringify(conv[k]);

    if (changed('name')) {
      if (!convPerm(conv, user, 'editInfo')) return deny();
      const name = String(body.name || '').trim();
      if (!name) return sendJSON(res, 400, { error: 'Название не может быть пустым' });
      patch.name = name.slice(0, 100);
    }
    if (changed('description')) {
      if (!convPerm(conv, user, 'editInfo')) return deny();
      patch.description = String(body.description || '').trim().slice(0, 500);
    }
    if (changed('groupCallsEnabled')) {
      if (!convPerm(conv, user, 'editInfo')) return deny();
      patch.groupCallsEnabled = !!body.groupCallsEnabled;
    }
    if (changed('avatar')) {
      if (!convPerm(conv, user, 'editPhoto')) return deny();
      const avatar = String(body.avatar || '');
      if (avatar && !avatar.startsWith('/uploads/')) return sendJSON(res, 400, { error: 'Некорректное фото' });
      patch.avatar = avatar;
    }
    if (body.inviteCode !== undefined && String(body.inviteCode).trim().toLowerCase() !== String(conv.inviteCode || '')) {
      if (!convPerm(conv, user, 'manageLink')) return deny();
      // Ссылка — любой свободный код из латиницы, цифр, «_» и «-».
      // Никаких обязательных приставок channel_/group_ больше нет.
      const code = String(body.inviteCode || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
      if (!code) return sendJSON(res, 400, { error: 'Пустая ссылка' });
      if (code.length < 3) return sendJSON(res, 400, { error: 'Ссылка слишком короткая — минимум 3 символа' });
      if (code.length > 32) return sendJSON(res, 400, { error: 'Ссылка слишком длинная — максимум 32 символа' });
      const taken = db.all('conversations').find((c) => c.id !== conv.id && c.inviteCode === code);
      if (taken) return sendJSON(res, 400, { error: 'Эта ссылка уже занята' });
      patch.inviteCode = code;
    }
    if (changed('allowedReactions')) {
      if (!convPerm(conv, user, 'manageReactions')) return deny();
      if (body.allowedReactions === null) {
        patch.allowedReactions = null;
      } else if (Array.isArray(body.allowedReactions)) {
        patch.allowedReactions = [...new Set(body.allowedReactions.filter((e) => typeof e === 'string' && e && e.length <= 16))].slice(0, 30);
      } else {
        return sendJSON(res, 400, { error: 'Некорректный список реакций' });
      }
    }
    if (Object.keys(patch).length === 0) return sendJSON(res, 200, { conversation: enrichConversation(conv, user.id) });
    const updated = db.update('conversations', conv.id, patch);
    broadcastToConversation(updated, { type: 'conversation-updated', conversation: updated }, null);
    return sendJSON(res, 200, { conversation: enrichConversation(updated, user.id) });
  }

  // Участники канала/группы с профилями — для экрана «Администраторы».
  // Владелец и админы идут первыми (их отдаём всегда), остальные — с поиском
  // ?q= и ограничением ?limit= (по умолчанию 100), чтобы не гнать весь канал.
  const membersMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/members$/);
  if (membersMatch && method === 'GET') {
    const conv = db.findById('conversations', membersMatch[1]);
    if (!isChannelOrGroup(conv)) return sendJSON(res, 404, { error: 'Не найдено' });
    const isMember = conv.ownerId === user.id || (conv.participants || []).includes(user.id);
    if (!isMember && !user.isAdmin) return sendJSON(res, 403, { error: 'Недостаточно прав' });
    const q = String(query.q || '').trim().toLowerCase();
    const limit = Math.min(Math.max(parseInt(query.limit, 10) || 100, 1), 300);
    const ids = [...new Set([conv.ownerId, ...Object.keys(conv.admins || {}), ...(conv.participants || [])])].filter(Boolean);
    const toRow = (uid) => {
      const u = db.findById('users', uid) || db.findById('bots', uid);
      if (!u) return null;
      const entry = conv.admins && conv.admins[uid];
      return {
        id: u.id,
        displayName: u.displayName || u.username || '?',
        username: u.username || '',
        avatar: u.avatar || '',
        role: uid === conv.ownerId ? 'owner' : (entry ? 'admin' : 'member'),
        perms: entry ? entry.perms : null,
        promotedBy: entry ? entry.by || null : null,
      };
    };
    const rows = ids.map(toRow).filter(Boolean);
    const rank = { owner: 0, admin: 1, member: 2 };
    const leaders = rows.filter((r) => r.role !== 'member').sort((a, b) => rank[a.role] - rank[b.role]);
    const others = rows.filter((r) => r.role === 'member' && (!q
      || r.displayName.toLowerCase().includes(q) || r.username.toLowerCase().includes(q)))
      .sort((a, b) => a.displayName.localeCompare(b.displayName, 'ru'))
      .slice(0, limit);
    return sendJSON(res, 200, { members: [...leaders, ...others] });
  }

  // Назначение / изменение прав / снятие администратора.
  // body: { userId, permissions: {post: bool, ...} } — permissions: null (или
  // все права выключены) снимает администратора.
  const adminsMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/admins$/);
  if (adminsMatch && method === 'POST') {
    const conv = db.findById('conversations', adminsMatch[1]);
    if (!isChannelOrGroup(conv)) return sendJSON(res, 404, { error: 'Не найдено' });
    if (!convPerm(conv, user, 'addAdmins')) return sendJSON(res, 403, { error: 'Недостаточно прав для назначения администраторов' });
    const body = await readBody(req);
    const targetId = String(body.userId || '');
    if (!targetId) return sendJSON(res, 400, { error: 'Не указан пользователь' });
    if (targetId === conv.ownerId) return sendJSON(res, 400, { error: 'Права владельца изменить нельзя' });
    if (!(conv.participants || []).includes(targetId)) {
      return sendJSON(res, 400, { error: conv.type === 'group' ? 'Назначить можно только участника группы' : 'Назначить можно только подписчика канала' });
    }
    const fullAccess = conv.ownerId === user.id || !!user.isAdmin;
    const admins = { ...(conv.admins || {}) };
    const existing = admins[targetId];
    // Делегированный админ меняет/снимает только тех, кого назначил сам.
    if (!fullAccess && existing && existing.by !== user.id) {
      return sendJSON(res, 403, { error: 'Этого администратора назначил другой человек — менять его права вы не можете' });
    }
    let perms = body.permissions === null || body.permissions === undefined ? null : sanitizeAdminPerms(body.permissions);
    if (perms && !fullAccess) {
      // Нельзя выдать больше прав, чем есть у самого назначающего.
      CONV_ADMIN_PERMS.forEach((perm) => { if (perms[perm] && !convPerm(conv, user, perm)) perms[perm] = false; });
    }
    if (perms && !CONV_ADMIN_PERMS.some((perm) => perms[perm])) perms = null;
    if (!perms) {
      delete admins[targetId];
    } else {
      const now = Date.now();
      admins[targetId] = { perms, by: existing ? existing.by : user.id, at: existing ? existing.at : now, updatedAt: now };
    }
    const updated = db.update('conversations', conv.id, { admins });
    broadcastToConversation(updated, { type: 'conversation-updated', conversation: updated }, null);
    return sendJSON(res, 200, { conversation: enrichConversation(updated, user.id) });
  }

  // Полная очистка истории личного чата у ОБОИХ собеседников: удаляются все
  // сообщения и — физически с диска — все прикреплённые к ним файлы (места на
  // сервере мало, поэтому «осиротевшие» файлы не оставляем до ночной уборки).
  // Сам чат остаётся в списке, просто пустой.
  const convHistoryMatch = pathname.match(/^\/api\/conversations\/([^/]+)\/history$/);
  if (convHistoryMatch && method === 'DELETE') {
    const conv = db.findById('conversations', convHistoryMatch[1]);
    if (!conv) return sendJSON(res, 404, { error: 'Не найдено' });
    if (conv.type !== 'dm') return sendJSON(res, 400, { error: 'Очистить историю можно только в личном чате' });
    if (!(conv.participants || []).includes(user.id)) return sendJSON(res, 403, { error: 'Недостаточно прав' });

    const mediaUrls = db.distinctMediaUrlsForConversation(conv.id);
    const removedMessages = db.removeManyBy('messages', 'conversationId', conv.id);
    db.update('conversations', conv.id, { pinnedMessageId: null, lastMessageAt: 0, reads: {} });

    // Файл можно удалять только если на него больше ничто не ссылается:
    // пересланное сообщение в другом чате использует тот же mediaUrl, а один
    // и тот же файл может быть ещё и аватаркой/историей/баннером.
    const keep = collectNonMessageUploadUrls();
    let removedFiles = 0;
    let freedBytes = 0;
    for (const url of mediaUrls) {
      if (keep.has(url) || db.isMediaUrlUsedByMessages(url)) continue;
      const filePath = resolveUploadPath(url);
      if (!filePath) continue;
      try {
        const st = await fs.promises.stat(filePath);
        await fs.promises.unlink(filePath);
        removedFiles++;
        freedBytes += st.size;
      } catch (e) {
        if (e.code !== 'ENOENT') console.error('⚠️  Не удалось удалить файл', url, ':', e.message);
      }
    }
    db.incrementalVacuum(500); // вернуть место от удалённых строк БД системе

    const cleared = db.findById('conversations', conv.id);
    broadcastToConversation(cleared, { type: 'history-cleared', conversationId: conv.id }, null);
    return sendJSON(res, 200, { ok: true, removedMessages, removedFiles, freedBytes });
  }

  if (convItemMatch && method === 'DELETE') {
    const conv = db.findById('conversations', convItemMatch[1]);
    if (!conv) return sendJSON(res, 404, { error: 'Не найдено' });
    const isOwner = (conv.type === 'channel' || conv.type === 'group') && conv.ownerId === user.id;
    if (!isOwner && !user.isAdmin) return sendJSON(res, 403, { error: 'Недостаточно прав' });
    broadcastToConversation(conv, { type: 'conversation-deleted', conversationId: conv.id }, null);
    db.remove('conversations', conv.id);
    db.removeManyBy('messages', 'conversationId', conv.id);
    removeConvFromAllFolders(conv.id);
    return sendJSON(res, 200, { ok: true });
  }

  // Список публичных каналов (для поиска/подписки) — группы в общий список
  // намеренно не попадают, в них вступают только по пригласительной ссылке.
  if (pathname === '/api/channels' && method === 'GET') {
    const channels = db.all('conversations').filter((c) => c.type === 'channel').map((c) => enrichConversation(c, user.id));
    return sendJSON(res, 200, { channels });
  }

  if (pathname === '/api/upload' && method === 'POST') {
    const uploadLimit = REGULAR_MAX_UPLOAD_BYTES;
    let body;
    try {
      body = await readBody(req, uploadLimit);
    } catch (e) {
      const limitMb = Math.round(uploadLimit / (1024 * 1024));
      return sendJSON(res, 413, { error: `Файл больше ${limitMb} МБ.` });
    }
    const { filename, dataBase64, kind } = body;
    if (!dataBase64) return sendJSON(res, 400, { error: 'Нет файла' });
    // расширение берём только «нормальное» (буквы/цифры, до 10 знаков) —
    // иначе в имя файла на диске могли попасть произвольные символы
    let ext = path.extname(filename || '') || '';
    if (!/^\.[A-Za-z0-9]{1,10}$/.test(ext)) ext = '';
    const safeName = genId('file') + ext.toLowerCase();
    const subdir = kind === 'avatar' ? 'avatars' : kind === 'story' ? 'stories' : kind === 'wallpaper' ? 'wallpapers' : kind === 'ringtone' ? 'ringtones' : '';
    const dir = subdir ? path.join(UPLOADS_DIR, subdir) : UPLOADS_DIR;
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const filePath = path.join(dir, safeName);
    const base64 = dataBase64.split(',').pop();
    fs.writeFileSync(filePath, Buffer.from(base64, 'base64'));
    const urlPath = '/uploads/' + (subdir ? subdir + '/' : '') + safeName;
    return sendJSON(res, 200, { url: urlPath });
  }

  // Кто видит историю. «Контакты» — те, кого автор сам добавил в контакты (через профиль;
  // сюда же старое имя, заданное при создании чата). «Все» — контакты ПЛЮС все, с кем у автора
  // просто есть личная переписка, но кто не добавлен в контакты.
  const storyAuthorHasContact = (authorId, viewerId) => {
    if (db.findById('contacts', `contact_${authorId}_${viewerId}`)) return true;
    return db.all('conversations').some((c) => c.type === 'dm' && c.participants.includes(authorId) && c.participants.includes(viewerId)
      && c.nicknames && c.nicknames[authorId]);
  };
  const storyAuthorHasDM = (authorId, viewerId) => db.all('conversations')
    .some((c) => c.type === 'dm' && c.participants.includes(authorId) && c.participants.includes(viewerId));
  const canViewStory = (viewerId, s) => {
    if (s.userId === viewerId) return true;
    if (s.audience === 'contacts') return storyAuthorHasContact(s.userId, viewerId);
    return storyAuthorHasDM(s.userId, viewerId) || storyAuthorHasContact(s.userId, viewerId);
  };

  if (pathname === '/api/stories' && method === 'GET') {
    const now = Date.now();
    // Срок жизни истории хранится в самой истории (ttlMs).
    const stories = db.all('stories').filter((s) => {
      if (!canViewStory(user.id, s)) return false;
      const author = db.findById('users', s.userId);
      const ttl = storyTtlMs(s, author);
      return s.createdAt > now - ttl;
    });
    // Реакции видит только автор (кто и чем отреагировал); остальным отдаём
    // лишь их собственную реакцию — чтобы подсветить сердечко в просмотрщике.
    const out = stories.map((s) => {
      const reactions = s.reactions || {};
      const mine = reactions[user.id] || null;
      const { reactions: _drop, ...rest } = s;
      return s.userId === user.id ? { ...rest, reactions, myReaction: mine } : { ...rest, myReaction: mine };
    });
    return sendJSON(res, 200, { stories: out });
  }

  if (pathname === '/api/stories' && method === 'POST') {
    const body = await readBody(req);
    // Текстовые наклейки поверх медиа: координаты — доли 0..1 от размера кадра,
    // чтобы одинаково выглядеть на любом экране. Всё приходящее от клиента чистим.
    const clamp = (n, a, b) => Math.min(b, Math.max(a, Number.isFinite(+n) ? +n : a));
    const texts = (Array.isArray(body.texts) ? body.texts : []).slice(0, 8).map((t) => ({
      text: String((t && t.text) || '').slice(0, 200),
      x: clamp(t && t.x, 0, 1),
      y: clamp(t && t.y, 0, 1),
      size: clamp(t && t.size, 12, 64),
      color: /^#[0-9a-fA-F]{6}$/.test((t && t.color) || '') ? t.color : '#ffffff',
      bg: !!(t && t.bg),
    })).filter((t) => t.text.trim());
    // Ссылка — только http(s), иначе javascript:/data: URL мог бы выполниться у зрителей.
    let link = null;
    if (body.link && typeof body.link.url === 'string') {
      let u = body.link.url.trim();
      if (u && !/^[a-z][a-z0-9+.-]*:/i.test(u)) u = 'https://' + u;
      try {
        const parsed = new URL(u);
        if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
          link = { url: parsed.toString().slice(0, 500), label: String(body.link.label || '').trim().slice(0, 40) };
        }
      } catch (e) { /* неверная ссылка — просто без ссылки */ }
    }
    const hours = STORY_TTL_CHOICES_H.includes(Number(body.hours)) ? Number(body.hours) : 24;
    const story = db.insert('stories', {
      id: genId('story'),
      userId: user.id,
      ttlMs: hours * 60 * 60 * 1000,
      audience: body.audience === 'contacts' ? 'contacts' : 'all',
      mediaUrl: body.mediaUrl || null,
      mediaType: body.mediaType === 'video' ? 'video' : 'image',
      caption: String(body.caption || '').slice(0, 500),
      texts,
      link,
      reactions: {},
      createdAt: Date.now(),
    });
    return sendJSON(res, 200, { story });
  }

  // Реакция на историю: тот же эмодзи повторно — снимает реакцию, другой — заменяет.
  const storyReactMatch = pathname.match(/^\/api\/stories\/([^/]+)\/react$/);
  if (storyReactMatch && method === 'POST') {
    const story = db.findById('stories', storyReactMatch[1]);
    if (!story) return sendJSON(res, 404, { error: 'История не найдена' });
    if (!canViewStory(user.id, story)) return sendJSON(res, 403, { error: 'Недостаточно прав' });
    const body = await readBody(req);
    const emoji = String(body.emoji || '');
    if (!STORY_REACTIONS.includes(emoji)) return sendJSON(res, 400, { error: 'Недопустимая реакция' });
    const reactions = { ...(story.reactions || {}) };
    if (reactions[user.id] === emoji) delete reactions[user.id];
    else reactions[user.id] = emoji;
    db.update('stories', story.id, { reactions });
    if (story.userId !== user.id && reactions[user.id]) {
      sendToUser(story.userId, { type: 'story-reaction', storyId: story.id, userId: user.id, userName: user.displayName, emoji });
    }
    return sendJSON(res, 200, { myReaction: reactions[user.id] || null });
  }

  const storyItemMatch = pathname.match(/^\/api\/stories\/([^/]+)$/);
  if (storyItemMatch && method === 'DELETE') {
    const story = db.findById('stories', storyItemMatch[1]);
    if (!story) return sendJSON(res, 404, { error: 'История не найдена' });
    if (story.userId !== user.id && !user.isAdmin) return sendJSON(res, 403, { error: 'Недостаточно прав' });
    db.remove('stories', story.id);
    if (story.mediaUrl) deleteUploadedFile(story.mediaUrl);
    return sendJSON(res, 200, { ok: true });
  }

  const msgItemMatch = pathname.match(/^\/api\/messages\/([^/]+)$/);
  if (msgItemMatch && method === 'PATCH') {
    const message = db.findById('messages', msgItemMatch[1]);
    if (!message) return sendJSON(res, 404, { error: 'Сообщение не найдено' });
    if (message.senderId !== user.id && !user.isAdmin) return sendJSON(res, 403, { error: 'Недостаточно прав' });
    // БАГ: пересланное сообщение хранится с senderId = того, кто переслал
    // (см. msg.type === 'forward' выше — forwardFrom описывает исходного
    // автора отдельным полем именно для этого), поэтому проверка выше
    // ("это моё сообщение") проходила и для пересланных сообщений тоже.
    // Из-за этого можно было переслать чужое сообщение себе/в другой чат
    // и затем отредактировать текст — получатели видели бы поддельное
    // содержимое под меткой "Переслано от <автор>", как будто это
    // реальные слова исходного отправителя. Содержимое пересылки должно
    // быть неизменяемым слепком оригинала.
    if (message.forwardFrom && !user.isAdmin) return sendJSON(res, 403, { error: 'Пересланные сообщения нельзя редактировать' });
    const body = await readBody(req);
    if (typeof body.content !== 'string' || !body.content.trim()) return sendJSON(res, 400, { error: 'Пустое сообщение' });
    const newContent = body.content.trim();
    const updated = db.update('messages', message.id, { content: encryptMessageText(message.conversationId, newContent), edited: true, editedAt: Date.now() });
    // БАГ-ФИКС: тут раньше рассылался "сырой" updated-объект из БД поверх
    // подмены только content — а вложенный replyPreview.content (снимок
    // текста цитируемого сообщения) в БД хранится зашифрованным и никогда
    // не расшифровывался на этом пути. В итоге у собеседников, уже открывших
    // чат, после любого редактирования ЛЮБОГО сообщения цитата в ответах на
    // это сообщение начинала показывать шифротекст вместо текста. Проходим
    // updated через тот же decryptMessage(), что и обычное чтение истории
    // (расшифрует replyPreview.content), и уже поверх подставляем свежий
    // newContent — сам updated.content расшифровывать не нужно, он и так
    // известен нам в открытом виде.
    const outUpdated = { ...decryptMessage(updated), content: newContent };
    const conv = db.findById('conversations', message.conversationId);
    if (conv) broadcastToConversation(conv, { type: 'message-edit', message: outUpdated }, null);
    return sendJSON(res, 200, { message: outUpdated });
  }

  if (msgItemMatch && method === 'DELETE') {
    const message = db.findById('messages', msgItemMatch[1]);
    if (!message) return sendJSON(res, 404, { error: 'Сообщение не найдено' });
    const msgConv = db.findById('conversations', message.conversationId);
    const canModerate = isChannelOrGroup(msgConv) && convPerm(msgConv, user, 'deleteMessages');
    if (message.senderId !== user.id && !user.isAdmin && !canModerate) return sendJSON(res, 403, { error: 'Недостаточно прав' });
    db.remove('messages', message.id);
    // Каждый загруженный файл сообщения получает уникальное сгенерированное
    // имя (см. /api/upload) и никогда не используется другим сообщением —
    // значит, удалить его прямо сейчас безопасно, не оставляя "сироту" на
    // диске навсегда.
    if (message.mediaUrl) deleteUploadedFile(message.mediaUrl);
    const conv = db.findById('conversations', message.conversationId);
    if (conv) {
      broadcastToConversation(conv, { type: 'message-delete', messageId: message.id, conversationId: message.conversationId }, null);
      if (conv.pinnedMessageId === message.id) {
        db.update('conversations', conv.id, { pinnedMessageId: null });
        broadcastToConversation(conv, { type: 'pin-update', conversationId: conv.id, pinnedMessage: null }, null);
      }
    }
    return sendJSON(res, 200, { ok: true });
  }

  // ---------- Админ-панель (доступ только для user.isAdmin) ----------
  if (pathname === '/api/admin/users' && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    const users = db.all('users').map(publicUser);
    return sendJSON(res, 200, { users });
  }

  // ---------- Полная выгрузка базы данных ----------
  // Два формата на выбор в 5-й вкладке админ-панели:
  //   1) настоящий файл SQLite (.db) — самый надёжный вариант бэкапа:
  //      просто кладёте его обратно вместо ~/.asteria-data/db/asteria.db
  //      при восстановлении, ничего не нужно пересобирать/парсить заново.
  //   2) человекочитаемый JSON — удобно, если нужно just посмотреть данные
  //      глазами или перенести их во что-то другое, не обязательно в SQLite.
  if (pathname === '/api/admin/export/db' && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    // WAL-режим означает, что часть самых свежих записей может физически
    // лежать ещё не в основном файле .db, а в соседнем файле -wal — если
    // отдать на скачивание только сам .db, не сделав чекпоинт, в выгрузке
    // могли бы не оказаться последние сообщения/действия. TRUNCATE-чекпоинт
    // сбрасывает всё содержимое WAL в основной файл и опустошает сам WAL —
    // после него отдаваемый .db гарантированно самодостаточен и актуален.
    db.exec('PRAGMA wal_checkpoint(TRUNCATE);');
    if (!fs.existsSync(db.DB_PATH)) return sendJSON(res, 500, { error: 'Файл базы данных не найден' });
    const stat = fs.statSync(db.DB_PATH);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    res.writeHead(200, {
      'Content-Type': 'application/octet-stream',
      'Content-Length': stat.size,
      'Content-Disposition': `attachment; filename="asteria-backup-${stamp}.db"`,
      'Cache-Control': 'no-store',
    });
    fs.createReadStream(db.DB_PATH).pipe(res);
    return;
  }
  if (pathname === '/api/admin/export/json' && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    const dump = { exportedAt: new Date().toISOString(), tables: {} };
    db.TABLES.forEach((t) => { dump.tables[t] = db.all(t); });
    const json = JSON.stringify(dump, null, 2);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(json),
      'Content-Disposition': `attachment; filename="asteria-export-${stamp}.json"`,
      'Cache-Control': 'no-store',
    });
    res.end(json);
    return;
  }

  // ---------- Полный архив для переезда на другой сервер ----------
  // В отличие от .db/.json выше, сюда же кладём и все загруженные файлы
  // (аватарки, обои, сторис) — без них одной базы недостаточно, чтобы
  // картинки не превратились в "битые" ссылки на новом сервере.
  //
  // Структура внутри архива НАРОЧНО повторяет структуру постоянного
  // каталога данных (".asteria-data/db/asteria.db", ".asteria-data/uploads/...")
  // — см. PERSIST_ROOT в lib/db.js и здесь же выше. Благодаря этому на
  // новом сервере ничего руками раскладывать по подпапкам не нужно:
  // распаковать архив прямо в домашнюю директорию пользователя, от
  // которого будет запущен сервер (по умолчанию именно там сервер и ищет
  // данные — ~/.asteria-data), и всё встанет на свои места само.
  if (pathname === '/api/admin/export/archive' && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    db.exec('PRAGMA wal_checkpoint(TRUNCATE);'); // см. пояснение у /api/admin/export/db выше
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="asteria-full-backup-${stamp}.zip"`,
      'Cache-Control': 'no-store',
    });

    const zip = new ZipWriter(res);
    try {
      if (fs.existsSync(db.DB_PATH)) {
        await zip.addFile('.asteria-data/db/asteria.db', db.DB_PATH);
      }
      // Человекочитаемый JSON той же базы — не обязателен для восстановления
      // (для этого достаточно .db) и НЕ является частью реальной структуры
      // ~/.asteria-data, поэтому лежит рядом отдельным файлом, а не внутри
      // db/, чтобы случайно ничего там не перепутать при распаковке.
      const dump = { exportedAt: new Date().toISOString(), tables: {} };
      db.TABLES.forEach((t) => { dump.tables[t] = db.all(t); });
      await zip.addFile('.asteria-data/_readable-export.json', Buffer.from(JSON.stringify(dump, null, 2), 'utf8'));

      async function addDirToZip(dir, zipPrefix) {
        let entries;
        try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
        for (const entry of entries) {
          if (zip.aborted) return;
          const fullPath = path.join(dir, entry.name);
          if (entry.isDirectory()) { await addDirToZip(fullPath, zipPrefix + entry.name + '/'); continue; }
          await zip.addFile('.asteria-data/uploads/' + zipPrefix + entry.name, fullPath);
        }
      }
      await addDirToZip(UPLOADS_DIR, '');

      await zip.finalize();
    } catch (e) {
      console.error('⚠️  Ошибка при формировании полного архива экспорта:', e.message);
    } finally {
      res.end();
    }
    return;
  }

  // Текущая загруженная версия приложения — для отображения в 3-й вкладке
  // админ-панели ("Новый APK"): что сейчас раздаётся пользователям.
  if (pathname === '/api/admin/app-release' && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    return sendJSON(res, 200, { release: readAppReleaseMeta() });
  }

  // Загрузка нового APK. Как и /api/upload — файл целиком одним JSON-
  // запросом (base64), это ок для редкого админского действия (не хот-пас,
  // в отличие от загрузки медиа пользователями). versionCode обязателен и
  // должен быть числом — именно по нему приложения на телефонах понимают,
  // что появилась более новая версия (см. GET /api/app/version ниже).
  if (pathname === '/api/admin/app-release' && method === 'POST') {
    if (!requireAdmin(user, res)) return;
    const body = await readBody(req, APP_RELEASE_MAX_BYTES);
    const versionCode = parseInt(body.versionCode, 10);
    const versionName = String(body.versionName || '').trim().slice(0, 50);
    const notes = String(body.notes || '').trim().slice(0, 2000);
    const dataBase64 = String(body.dataBase64 || '');
    if (!Number.isInteger(versionCode) || versionCode <= 0) {
      return sendJSON(res, 400, { error: 'versionCode должен быть положительным целым числом (тем самым android.defaultConfig.versionCode из build.gradle новой сборки)' });
    }
    if (!versionName) return sendJSON(res, 400, { error: 'Укажите versionName (например, "1.1")' });
    const base64Payload = dataBase64.includes(',') ? dataBase64.split(',').pop() : dataBase64;
    let apkBuffer;
    try {
      apkBuffer = Buffer.from(base64Payload, 'base64');
    } catch (e) {
      return sendJSON(res, 400, { error: 'Не удалось прочитать файл APK' });
    }
    if (!apkBuffer.length) return sendJSON(res, 400, { error: 'Пустой файл APK' });
    // Простая сигнатура ZIP (APK — это ZIP-архив: "PK\x03\x04") — хоть
    // какая-то защита от случайной загрузки не того файла.
    if (apkBuffer[0] !== 0x50 || apkBuffer[1] !== 0x4b) {
      return sendJSON(res, 400, { error: 'Файл не похож на APK (не ZIP-архив) — проверьте, тот ли файл выбран' });
    }
    fs.mkdirSync(APP_RELEASE_DIR, { recursive: true });
    fs.writeFileSync(APP_RELEASE_APK_PATH, apkBuffer);
    const meta = {
      versionCode,
      versionName,
      notes,
      sizeBytes: apkBuffer.length,
      uploadedAt: Date.now(),
      uploadedBy: user.displayName,
      // Новая версия при загрузке всегда публикуется включённой — выключить
      // раздачу (без удаления самого файла) можно отдельным переключателем,
      // см. POST /api/admin/app-release/toggle ниже, тем же принципом, что
      // и у обычного баннера (see /api/admin/banner/toggle).
      enabled: true,
    };
    fs.writeFileSync(APP_RELEASE_META_PATH, JSON.stringify(meta, null, 2));
    console.log(`📦 Загружена новая версия Android-приложения: versionCode=${versionCode}, versionName=${versionName} (${(apkBuffer.length / 1024 / 1024).toFixed(1)} МБ) — админ: ${user.displayName}`);
    broadcastAppUpdateAvailable(meta);
    return sendJSON(res, 200, { release: meta });
  }

  // Быстрое включение/выключение автообновления без удаления самого APK и
  // без изменения его метаданных — тот же принцип, что и у переключателя
  // баннера (см. /api/admin/banner/toggle). Пока выключено:
  //   - GET /api/app/version отдаёт available:false — значит, ни нативный
  //     диалог обновления в приложении (AppUpdateManager.checkForUpdate),
  //     ни веб-баннер на случай совсем старых версий (checkAppUpdateBanner
  //     в app.js) ничего не покажут — оба спрашивают именно этот эндпоинт;
  //   - GET /api/app/download перестаёт отдавать файл (404) — то есть сам
  //     APK при выключенном автообновлении не раздаётся вообще никому,
  //     даже по прямой ссылке.
  if (pathname === '/api/admin/app-release/toggle' && method === 'POST') {
    if (!requireAdmin(user, res)) return;
    const current = readAppReleaseMeta();
    if (!current) return sendJSON(res, 404, { error: 'Ещё ничего не загружено' });
    current.enabled = !current.enabled;
    fs.writeFileSync(APP_RELEASE_META_PATH, JSON.stringify(current, null, 2));
    return sendJSON(res, 200, { release: current });
  }

  // Регистрация: чтение и переключение (только админ).
  if (pathname === '/api/admin/registration' && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    return sendJSON(res, 200, { open: isRegistrationOpen() });
  }
  if (pathname === '/api/admin/registration' && method === 'POST') {
    if (!requireAdmin(user, res)) return;
    const body = await readBody(req);
    const open = body.open === true;
    fs.mkdirSync(PERSIST_ROOT, { recursive: true });
    fs.writeFileSync(REGISTRATION_PATH, JSON.stringify({ open, updatedAt: Date.now(), updatedBy: user.displayName }, null, 2));
    return sendJSON(res, 200, { open });
  }

  // Текущий баннер — для формы редактирования в админ-панели.
  if (pathname === '/api/admin/banner' && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    return sendJSON(res, 200, { banner: readBanner() });
  }

  // Сохранение/публикация баннера. Каждое сохранение — это как бы новая
  // версия баннера (новый id): значит, если админ уже показывал баннер и
  // кто-то его закрыл крестиком, а потом админ поменял текст/картинку и
  // сохранил заново — баннер снова покажется всем, в том числе тем, кто
  // раньше его закрыл. Логично: раз содержимое новое — стоит показать
  // ещё раз. Просто переключить "показан/скрыт" можно тем же запросом,
  // не трогая остальные поля.
  if (pathname === '/api/admin/banner' && method === 'POST') {
    if (!requireAdmin(user, res)) return;
    const body = await readBody(req);
    const title = String(body.title || '').trim().slice(0, 120);
    const description = String(body.description || '').trim().slice(0, 300);
    const imageUrl = String(body.imageUrl || '').trim();
    const enabled = body.enabled !== false;
    if (!title) return sendJSON(res, 400, { error: 'Укажите заголовок баннера' });
    if (imageUrl && !imageUrl.startsWith('/uploads/')) return sendJSON(res, 400, { error: 'Некорректная картинка' });
    const previous = readBanner();
    const banner = {
      id: 'banner_' + Date.now().toString(36),
      title,
      description,
      imageUrl: imageUrl || null,
      enabled,
      updatedAt: Date.now(),
      updatedBy: user.displayName,
    };
    fs.mkdirSync(PERSIST_ROOT, { recursive: true });
    fs.writeFileSync(BANNER_PATH, JSON.stringify(banner, null, 2));
    // Старая картинка баннера заменена новой (или убрана вовсе) — удаляем её
    // сразу, не дожидаясь ночной уборки "осиротевших" файлов.
    if (previous && previous.imageUrl && previous.imageUrl !== banner.imageUrl) {
      deleteUploadedFile(previous.imageUrl);
    }
    return sendJSON(res, 200, { banner });
  }

  // Полное удаление баннера (не просто выключение) — вместе с картинкой,
  // сразу, а не через ночную уборку.
  if (pathname === '/api/admin/banner' && method === 'DELETE') {
    if (!requireAdmin(user, res)) return;
    const current = readBanner();
    if (!current) return sendJSON(res, 200, { ok: true });
    if (current.imageUrl) deleteUploadedFile(current.imageUrl);
    try { fs.unlinkSync(BANNER_PATH); } catch (e) { /* уже нет файла — не критично */ }
    return sendJSON(res, 200, { ok: true });
  }

  // Быстрое включение/выключение без изменения содержимого и без смены id
  // (значит, тем, кто уже закрыл баннер крестиком, включение его обратно
  // повторно не покажет — они его уже видели).
  if (pathname === '/api/admin/banner/toggle' && method === 'POST') {
    if (!requireAdmin(user, res)) return;
    const current = readBanner();
    if (!current) return sendJSON(res, 404, { error: 'Баннер ещё не создан' });
    current.enabled = !current.enabled;
    fs.writeFileSync(BANNER_PATH, JSON.stringify(current, null, 2));
    return sendJSON(res, 200, { banner: current });
  }

  const adminUserMatch = pathname.match(/^\/api\/admin\/users\/([^/]+)$/);
  if (adminUserMatch && method === 'PATCH') {
    if (!requireAdmin(user, res)) return;
    const target = db.findById('users', adminUserMatch[1]);
    if (!target) return sendJSON(res, 404, { error: 'Пользователь не найден' });
    const body = await readBody(req);
    const patch = {};
    ['displayName', 'status', 'avatar'].forEach((k) => { if (body[k] !== undefined) patch[k] = body[k]; });
    if (body.username !== undefined) {
      const newUsername = String(body.username).trim();
      if (newUsername.length < 3) return sendJSON(res, 400, { error: 'Логин должен быть не короче 3 символов' });
      const existing = db.findOneBy('users', 'username', newUsername);
      if (existing && existing.id !== target.id) return sendJSON(res, 400, { error: 'Такой логин уже занят' });
      patch.username = newUsername;
    }
    if (body.newPassword) {
      if (body.newPassword.length < 4) return sendJSON(res, 400, { error: 'Пароль слишком короткий' });
      patch.passwordHash = hashPassword(body.newPassword);
    }
    if (body.isAdmin !== undefined) {
      // снять/выдать права администратора. Можно снять и с самого себя —
      // именно так работает кнопка «Снять с себя права» в админ-панели.
      patch.isAdmin = !!body.isAdmin;
    }
    if (body.isVerified !== undefined) {
      patch.isVerified = !!body.isVerified;
    }
    const updated = db.update('users', target.id, patch);
    if (patch.isAdmin === false) sendToUser(target.id, { type: 'admin-revoked' });
    if (patch.isAdmin === true) sendToUser(target.id, { type: 'admin-granted' });
    return sendJSON(res, 200, { user: publicUser(updated) });
  }

  if (adminUserMatch && method === 'DELETE') {
    if (!requireAdmin(user, res)) return;
    const target = db.findById('users', adminUserMatch[1]);
    if (!target) return sendJSON(res, 404, { error: 'Пользователь не найден' });
    if (target.isBot) return sendJSON(res, 400, { error: 'Нельзя удалить бота' });
    if (target.id === user.id) return sendJSON(res, 400, { error: 'Нельзя удалить самого себя. Сначала снимите с себя права администратора, если нужно, а удаление собственного аккаунта делайте из-под обычной сессии.' });

    // разлогиниваем удаляемого пользователя везде
    db.removeManyBy('sessions', 'userId', target.id);

    // каскадно чистим его чаты и каналы
    db.all('conversations').forEach((conv) => {
      const inGroupOrChannelAsMember = (conv.type === 'channel' || conv.type === 'group') && (conv.participants || []).includes(target.id) && conv.ownerId !== target.id;
      const shouldDeleteWhole = (conv.type === 'dm' && conv.participants.includes(target.id)) ||
        ((conv.type === 'channel' || conv.type === 'group') && conv.ownerId === target.id);
      if (shouldDeleteWhole) {
        broadcastToConversation(conv, { type: 'conversation-deleted', conversationId: conv.id }, null);
        db.remove('conversations', conv.id);
        db.removeManyBy('messages', 'conversationId', conv.id);
        removeConvFromAllFolders(conv.id);
      } else if (inGroupOrChannelAsMember) {
        const participants = conv.participants.filter((p) => p !== target.id);
        const updated = db.update('conversations', conv.id, { participants });
        broadcastToConversation(updated, { type: 'conversation-updated', conversation: updated }, null);
      }
    });

    db.remove('users', target.id);
    sendToUser(target.id, { type: 'account-deleted' });
    return sendJSON(res, 200, { ok: true });
  }

  if (pathname === '/api/admin/conversations' && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    const conversations = db.all('conversations').map(enrichConversationAdmin);
    return sendJSON(res, 200, { conversations });
  }

  // Верификация канала/группы ("✔️" у названия) — выдаётся исключительно
  // администратором, точно так же, как isVerified у пользователей выше.
  const adminConvVerifyMatch = pathname.match(/^\/api\/admin\/conversations\/([^/]+)$/);
  if (adminConvVerifyMatch && method === 'PATCH') {
    if (!requireAdmin(user, res)) return;
    const conv = db.findById('conversations', adminConvVerifyMatch[1]);
    if (!conv) return sendJSON(res, 404, { error: 'Не найдено' });
    if (conv.type !== 'channel' && conv.type !== 'group') return sendJSON(res, 400, { error: 'Верифицировать можно только каналы и группы' });
    const body = await readBody(req);
    const patch = {};
    if (body.isVerified !== undefined) patch.isVerified = !!body.isVerified;
    // Метка «A+»: канал/чат есть в перечне Дарккомнадзора (выдаётся только администратором).
    if (body.isRegistered !== undefined) patch.isRegistered = !!body.isRegistered;
    const updated = db.update('conversations', conv.id, patch);
    broadcastToConversation(updated, { type: 'conversation-updated', conversation: updated }, null);
    return sendJSON(res, 200, { conversation: enrichConversationAdmin(updated) });
  }

  const adminConvMsgsMatch = pathname.match(/^\/api\/admin\/conversations\/([^/]+)\/messages$/);
  if (adminConvMsgsMatch && method === 'GET') {
    if (!requireAdmin(user, res)) return;
    const messages = db.findManyBy('messages', 'conversationId', adminConvMsgsMatch[1]);
    return sendJSON(res, 200, { messages: decryptMessages(messages) });
  }

  // ---------- История звонков ----------
  if (pathname === '/api/calls' && method === 'GET') {
    const myConvIds = new Set(userConversations(user.id).filter((c) => c.type === 'channel' || c.type === 'group').map((c) => c.id));
    const calls = db.all('calls')
      .filter((c) => {
        if (c.mode === '1:1') return c.callerId === user.id || c.calleeId === user.id;
        if (c.mode === 'group') return myConvIds.has(c.conversationId);
        return false;
      })
      .sort((a, b) => b.startedAt - a.startedAt)
      .slice(0, 200)
      .map((c) => {
        const out = { ...c };
        if (c.mode === '1:1') {
          const otherId = c.callerId === user.id ? c.calleeId : c.callerId;
          out.peer = publicUser(db.findById('users', otherId));
          out.direction = c.callerId === user.id ? 'outgoing' : 'incoming';
        } else {
          const conv = db.findById('conversations', c.conversationId);
          out.channelName = conv ? conv.name : 'Канал';
        }
        return out;
      });
    return sendJSON(res, 200, { calls });
  }

  // ---------- ICE-конфигурация для WebRTC-звонков (STUN + собственный TURN) ----------
  // Раньше мессенджер жил в локальной сети, и браузерам хватало обычного
  // STUN (или вообще прямого host-соединения). В глобальной сети этого часто
  // недостаточно — если у одного из собеседников NAT/файрвол не пускает
  // прямое соединение, звонок просто не устанавливается. TURN-сервер решает
  // это, ретранслируя медиапоток. Чтобы не подключать сторонние сервисы,
  // используется собственный TURN (lib/mini-turn.js); креденшлы выдаются
  // авторизованным пользователям на ограниченное время (TURN REST API-схема).
  if (pathname === '/api/turn-credentials' && method === 'GET') {
    const creds = generateTurnCredentials(TURN_SECRET, user.id, 6 * 3600);
    const iceServers = [
      { urls: `stun:${TURN_HOST}:${TURN_PORT}` },
      {
        // Оба варианта транспорта клиент-сервер (UDP и TCP) — браузер сам
        // попробует оба и использует тот, что реально прошёл через сеть.
        // См. подробный комментарий в lib/mini-turn.js про TCP-фолбэк —
        // без него звонки могли не устанавливаться в сетях, блокирующих
        // исходящий UDP на нестандартные порты (частая причина того, что
        // звонок работает в одном Wi-Fi, но не работает между разными
        // сетями/через мобильный интернет).
        urls: [`turn:${TURN_HOST}:${TURN_PORT}?transport=udp`, `turn:${TURN_HOST}:${TURN_PORT}?transport=tcp`],
        username: creds.username,
        credential: creds.credential,
      },
      // Публичный STUN как дополнительный запасной вариант (был и раньше).
      { urls: 'stun:stun.l.google.com:19302' },
    ];
    return sendJSON(res, 200, { iceServers, ttl: creds.ttl });
  }

  // ---------- Боты (BotCreator) ----------
  // Глобальный каталог ботов — как со списком каналов, отдаём всех
  // созданных пользователями ботов (без токена и команд), чтобы их можно
  // было найти глобальным поиском, даже если ты ещё не писал этому боту.
  if (pathname === '/api/bots' && method === 'GET') {
    const allBots = db.all('bots').filter((b) => b.id !== BOT_ID);
    return sendJSON(res, 200, { bots: allBots.map(publicBot) });
  }

  if (pathname === '/api/bots/mine' && method === 'GET') {
    const mine = db.findManyBy('bots', 'ownerId', user.id);
    return sendJSON(res, 200, { bots: mine });
  }

  if (pathname === '/api/bots' && method === 'POST') {
    const body = await readBody(req);
    const name = String(body.name || '').trim().slice(0, 64);
    const uname = String(body.username || '').trim().replace(/^@/, '');
    if (!name) return sendJSON(res, 400, { error: 'Укажите имя бота' });
    if (!isValidBotUsername(uname)) {
      return sendJSON(res, 400, { error: 'Логин должен быть латиницей/цифрами/подчёркиванием (3–32 симв.) и заканчиваться на «bot»' });
    }
    if (isBotUsernameTaken(uname)) {
      return sendJSON(res, 400, { error: 'Такой логин уже занят' });
    }
    const bot = createUserBot(user.id, name, uname);
    return sendJSON(res, 200, { bot });
  }

  const botMatch = pathname.match(/^\/api\/bots\/([^/]+)$/);
  if (botMatch && method === 'GET') {
    const bot = db.findById('bots', botMatch[1]);
    if (!bot || bot.ownerId !== user.id) return sendJSON(res, 404, { error: 'Бот не найден' });
    return sendJSON(res, 200, { bot });
  }

  if (botMatch && method === 'PATCH') {
    const bot = db.findById('bots', botMatch[1]);
    if (!bot || bot.ownerId !== user.id) return sendJSON(res, 404, { error: 'Бот не найден' });
    const body = await readBody(req);
    const patch = {};
    if (body.displayName !== undefined) {
      const dn = String(body.displayName).trim().slice(0, 64);
      if (dn) { patch.displayName = dn; db.update('users', bot.id, { displayName: dn }); }
    }
    if (body.avatar !== undefined) {
      patch.avatar = String(body.avatar || '');
      db.update('users', bot.id, { avatar: patch.avatar });
    }
    if (body.commands !== undefined && Array.isArray(body.commands)) {
      patch.commands = body.commands
        .map((c) => ({
          trigger: String((c && c.trigger) || '').trim().slice(0, 64),
          response: String((c && c.response) || '').trim().slice(0, 2000),
        }))
        .filter((c) => c.trigger && c.response)
        .slice(0, 100);
    }
    if (body.miniApp !== undefined) {
      const enabled = !!(body.miniApp && body.miniApp.enabled);
      let miniUrl = String((body.miniApp && body.miniApp.url) || '').trim().slice(0, 500);
      // Многие вставляют ссылку без "https://" (например example.com/app) —
      // вместо того чтобы молча отклонять сохранение, аккуратно
      // подставляем протокол сами.
      if (miniUrl && !/^https?:\/\//i.test(miniUrl)) miniUrl = 'https://' + miniUrl.replace(/^\/+/, '');
      patch.miniApp = { enabled: enabled && !!miniUrl, url: miniUrl };
    }
    const updated = db.update('bots', bot.id, patch);
    return sendJSON(res, 200, { bot: updated });
  }

  if (botMatch && method === 'DELETE') {
    const bot = db.findById('bots', botMatch[1]);
    // Владелец бота может удалить своего бота сам; администратор — любого
    // бота (в т.ч. чужого) прямо из админ-панели. Встроенных системных
    // ботов (главный ассистент и BotCreator) удалить нельзя — без них
    // сломается часть базового функционала приложения.
    if (!bot || (bot.ownerId !== user.id && !user.isAdmin)) return sendJSON(res, 404, { error: 'Бот не найден' });
    if (bot.id === BOT_ID || bot.id === BOTCREATOR_ID || bot.id === CODEBOT_ID) return sendJSON(res, 400, { error: 'Этого системного бота удалить нельзя' });
    const convs = db.all('conversations').filter((c) => c.type === 'dm' && c.participants.includes(bot.id));
    convs.forEach((c) => {
      broadcastToConversation(c, { type: 'conversation-deleted', conversationId: c.id }, null);
      db.removeManyBy('messages', 'conversationId', c.id);
      removeConvFromAllFolders(c.id);
      db.remove('conversations', c.id);
    });
    db.remove('bots', bot.id);
    db.remove('users', bot.id);
    return sendJSON(res, 200, { ok: true });
  }

  // ---------- Riveo ID: мини-приложение цифрового ID (паспорт/карта) ----------
  // Открытый и полный текст персональных данных наружу не возвращается
  // никогда — только заранее посчитанный маскированный preview (см.
  // riveoPreview/saveRiveoPassport/saveRiveoCard выше). Полноценное
  // "прочитать сохранённое обратно" тут намеренно отсутствует.
  if (pathname === '/api/riveo/me' && method === 'GET') {
    return sendJSON(res, 200, riveoPreview(user.id));
  }
  if (pathname === '/api/riveo/passport' && method === 'POST') {
    const body = await readBody(req);
    const result = saveRiveoPassport(user.id, body);
    if (result.error) return sendJSON(res, 400, { error: result.error });
    return sendJSON(res, 200, { passport: result.preview });
  }
  if (pathname === '/api/riveo/passport' && method === 'DELETE') {
    deleteRiveoPassport(user.id);
    return sendJSON(res, 200, { ok: true });
  }
  if (pathname === '/api/riveo/card' && method === 'POST') {
    const body = await readBody(req);
    const result = saveRiveoCard(user.id, body);
    if (result.error) return sendJSON(res, 400, { error: result.error });
    return sendJSON(res, 200, { card: result.preview });
  }
  const riveoDocMatch = pathname.match(/^\/api\/riveo\/doc\/([a-z]+)$/);
  if (riveoDocMatch && method === 'POST') {
    const body = await readBody(req);
    const result = saveRiveoDoc(user.id, riveoDocMatch[1], body);
    if (result.error) return sendJSON(res, 400, { error: result.error });
    return sendJSON(res, 200, { doc: result.preview });
  }
  if (riveoDocMatch && method === 'DELETE') {
    deleteRiveoDoc(user.id, riveoDocMatch[1]);
    return sendJSON(res, 200, { ok: true });
  }
  if (pathname === '/api/riveo/card' && method === 'DELETE') {
    deleteRiveoCard(user.id);
    return sendJSON(res, 200, { ok: true });
  }

  // ---------- Папки с чатами (персональные для каждого пользователя) ----------
  if (pathname === '/api/folders' && method === 'GET') {
    const folders = db.findManyBy('folders', 'userId', user.id);
    return sendJSON(res, 200, { folders });
  }

  if (pathname === '/api/folders' && method === 'POST') {
    const body = await readBody(req);
    const name = String(body.name || '').trim();
    if (!name) return sendJSON(res, 400, { error: 'Укажите название папки' });
    const folder = db.insert('folders', {
      id: genId('folder'),
      userId: user.id,
      name,
      convIds: Array.isArray(body.convIds) ? body.convIds : [],
      createdAt: Date.now(),
    });
    return sendJSON(res, 200, { folder });
  }

  const folderMatch = pathname.match(/^\/api\/folders\/([^/]+)$/);
  if (folderMatch && method === 'PATCH') {
    const folder = db.findById('folders', folderMatch[1]);
    if (!folder || folder.userId !== user.id) return sendJSON(res, 404, { error: 'Папка не найдена' });
    const body = await readBody(req);
    const patch = {};
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return sendJSON(res, 400, { error: 'Пустое название папки' });
      patch.name = name;
    }
    if (body.convIds !== undefined) patch.convIds = Array.isArray(body.convIds) ? body.convIds : [];
    const updated = db.update('folders', folder.id, patch);
    return sendJSON(res, 200, { folder: updated });
  }

  if (folderMatch && method === 'DELETE') {
    const folder = db.findById('folders', folderMatch[1]);
    if (!folder || folder.userId !== user.id) return sendJSON(res, 404, { error: 'Папка не найдена' });
    db.remove('folders', folder.id);
    return sendJSON(res, 200, { ok: true });
  }

  return sendJSON(res, 404, { error: 'Не найдено' });
}

function enrichConversationAdmin(conv) {
  const out = { ...conv };
  if (conv.type === 'dm') {
    out.title = (conv.participants || []).map((pid) => {
      const u = db.findById('users', pid);
      return u ? u.displayName : '?';
    }).join(' ↔ ');
  } else {
    out.title = conv.name;
  }
  out.messageCount = db.countMessagesBy(conv.id);
  out.lastMessage = decryptMessage(db.findLastBy('messages', 'conversationId', conv.id));
  return out;
}

function enrichConversation(conv, viewerId) {
  const out = { ...conv };
  if (conv.type === 'dm') {
    const otherId = conv.participants.find((p) => p !== viewerId);
    const other = db.findById('users', otherId);
    out.peer = publicUserForViewer(other, viewerId);
    // Отпечаток ключа шифрования ЭТОЙ переписки (см. conversationKeyFingerprint
    // в lib/util.js) — не сам ключ (его показывать нельзя, это и есть
    // секрет), а его безопасный хэш-"отпечаток". У обеих сторон переписки он
    // совпадает (детерминированно порождается из id одной и той же
    // conversations-записи) — можно свериться визуально, как номер
    // безопасности в Signal.
    out.peer.encryptionKeyFingerprint = conversationKeyFingerprint(conv.id);
    out.blockedByMe = userBlocked(viewerId, otherId);
    // Локальное имя контакта — как этот собеседник подписан именно у меня
    // (например вместо «Саша» → «сыночек»), не видно второй стороне.
    // Приоритет: имя из "Контактов" (задаётся кнопкой "Изменить" в профиле)
    // важнее старого имени, заданного при создании чата через поиск — так
    // человек, осознанно добавивший контакт и переименовавший его позже,
    // видит именно актуальное имя, а не то, что ввёл мимоходом когда-то
    // при первом сообщении.
    const contactRec = db.findById('contacts', `contact_${viewerId}_${otherId}`);
    out.peerNickname = (contactRec && contactRec.nickname) || (conv.nicknames && conv.nicknames[viewerId]) || '';
    // Если собеседник — бот с подключённым мини-приложением (BotCreator или
    // бот, созданный через него), сообщаем клиенту его конфиг, чтобы
    // показать кнопку мини-приложения в поле ввода.
    if (out.peer && out.peer.isBot) {
      const botRecord = db.findById('bots', otherId);
      out.peer.miniApp = (botRecord && botRecord.miniApp && botRecord.miniApp.enabled && botRecord.miniApp.url)
        ? { url: botRecord.miniApp.url }
        : null;
      out.peer.isBotOwner = !!(botRecord && botRecord.ownerId === viewerId);
    }
  }
  if (conv.type === 'channel' || conv.type === 'group') {
    const room = groupCallRooms.get(conv.id);
    out.groupCallCount = room ? room.size : 0;
  }
  out.lastMessage = decryptMessage(db.findLastBy('messages', 'conversationId', conv.id));
  // Отметки о прочтении (для галочек в личных чатах) + счётчик непрочитанных
  // (для бейджа в списке чатов слева) — считаем прямо в SQLite (COUNT(*)),
  // не поднимая в память и не парся всю историю чата ради этого, как было
  // раньше (см. db.countMessagesBy).
  out.reads = visibleReadsFor(conv, viewerId);
  const myLastRead = (conv.reads && conv.reads[viewerId]) || 0;
  out.unreadCount = db.countMessagesBy(conv.id, { excludeSenderId: viewerId, afterCreatedAt: myLastRead });
  if (conv.pinnedMessageId) {
    const pinned = decryptMessage(db.findById('messages', conv.pinnedMessageId));
    if (pinned) {
      out.pinnedMessage = pinned;
    } else {
      // закреплённое сообщение удалили — тихо снимаем закрепление
      out.pinnedMessage = null;
      out.pinnedMessageId = null;
      db.update('conversations', conv.id, { pinnedMessageId: null });
    }
  } else {
    out.pinnedMessage = null;
  }
  return out;
}

// ---------- Сервер ----------
function requestHandler(req, res) {
  const parsed = url.parse(req.url, true);
  const pathname = decodeURIComponent(parsed.pathname);

  if (pathname.startsWith('/api/')) {
    handleAPI(req, res, pathname, parsed.query).catch((err) => {
      console.error(err);
      sendJSON(res, 500, { error: 'Внутренняя ошибка сервера' });
    });
    return;
  }

  if (pathname.startsWith('/uploads/')) {
    serveStatic(req, res, UPLOADS_DIR, pathname.replace('/uploads/', ''), {
      isUpload: true,
      download: parsed.query && parsed.query.dl === '1',
      name: parsed.query && typeof parsed.query.name === 'string' ? parsed.query.name : '',
    });
    return;
  }

  if (pathname === '/' || pathname === '') {
    serveStatic(req, res, PUBLIC_DIR, '/index.html');
    return;
  }

  // Глубокие ссылки (приглашение в группу/канал, профиль) — это чисто
  // клиентские маршруты в SPA: отдаём index.html, а сам путь разбирает уже
  // app.js на клиенте (см. handleDeepLinkIfPresent).
  if (/^\/j\/[^/]+$/.test(pathname) || /^\/u\/[^/]+$/.test(pathname) || /^\/qr\/[^/]+$/.test(pathname)) {
    serveStatic(req, res, PUBLIC_DIR, '/index.html');
    return;
  }

  serveStatic(req, res, PUBLIC_DIR, pathname);
}

const server = http.createServer(requestHandler);
wss.attach(server);

function localAddrs() {
  const nets = os.networkInterfaces();
  const addrs = [];
  Object.values(nets).forEach((ifaces) => (ifaces || []).forEach((i) => {
    if (i.family === 'IPv4' && !i.internal) addrs.push(i.address);
  }));
  return addrs;
}

const CERT_DIR = path.join(__dirname, 'certs');
const KEY_PATH = path.join(CERT_DIR, 'key.pem');
const CERT_PATH = path.join(CERT_DIR, 'cert.pem');
const HTTPS_PORT = process.env.HTTPS_PORT || 3443;
let httpsServer = null;

// Без HTTPS браузер не даёт доступ к камере/микрофону нигде, кроме
// localhost, — значит не работают звонки, голосовые и видео-кружки. Раньше
// это решалось локальным IP + отдельным ручным шагом (node generate-cert.js).
// Теперь, если сертификата ещё нет, сервер при старте пытается сделать это
// сам (тем же openssl, без сторонних сервисов), чтобы это не забывали
// сделать при переезде из локальной сети в интернет. Публичный домен/IP
// можно подсказать переменной PUBLIC_HOST — тогда сертификат будет выписан и
// на него тоже.
if (!fs.existsSync(KEY_PATH) || !fs.existsSync(CERT_PATH)) {
  try {
    const { generateCert } = require('./generate-cert');
    const extra = (process.env.PUBLIC_HOST || process.env.PUBLIC_IP || '')
      .split(',').map((s) => s.trim()).filter(Boolean);
    generateCert(extra, { quiet: true });
  } catch (e) {
    console.error('⚠️  Автоматическая генерация HTTPS-сертификата не удалась:', e.message);
  }
}

if (fs.existsSync(KEY_PATH) && fs.existsSync(CERT_PATH)) {
  try {
    httpsServer = https.createServer({
      key: fs.readFileSync(KEY_PATH),
      cert: fs.readFileSync(CERT_PATH),
    }, requestHandler);
    wss.attach(httpsServer);
  } catch (e) {
    console.error('⚠️  Не удалось запустить HTTPS (проверьте certs/key.pem и certs/cert.pem):', e.message);
    httpsServer = null;
  }
}

// ---------- Автоматический доверенный HTTPS-сертификат (Let's Encrypt) ----------
// Самоподписанный сертификат выше ВСЕГДА работает как надёжный запасной
// вариант — сервер и звонки работают в любом случае. Но браузер каждый раз
// показывает предупреждение "соединение не защищено", и пользователям
// приходится вручную кликать "всё равно перейти". Здесь — попытка
// автоматически получить НАСТОЯЩИЙ, доверенный браузерами сертификат от
// Let's Encrypt, полностью самостоятельно и без единого шага руками: ни
// ключей, ни аккаунтов, ни ручного certbot/сторонних сервисов — см.
// lib/acme.js. Если публичного домена нет (только PUBLIC_HOST/публичный IP),
// используется бесплатный wildcard-DNS sslip.io, чтобы превратить голый IP в
// настоящее имя (203.0.113.10 → 203-0-113-10.sslip.io) — Let's Encrypt не
// умеет выдавать сертификаты на голые IP, а покупать домен ради этого не
// нужно. Если порт 80 недоступен снаружи или что-то ещё пошло не так —
// сервер просто продолжает работать на самоподписанном, как и раньше.
// Отключить эту попытку совсем можно переменной ASTERIA_DISABLE_AUTO_HTTPS=1.
const ACME_DIR = path.join(PERSIST_ROOT, 'acme');
const ACME_CERT_PATH = path.join(ACME_DIR, 'cert.pem');
const ACME_KEY_PATH = path.join(ACME_DIR, 'key.pem');
const ACME_ACCOUNT_KEY_PATH = path.join(ACME_DIR, 'account-key.pem');
const ACME_RENEW_BEFORE_MS = 30 * 24 * 60 * 60 * 1000; // Let's Encrypt выдаёт на 90 дней — обновляем за 30 до истечения
const acmeChallengeResponses = new Map(); // token -> keyAuthorization, для /.well-known/acme-challenge/:token
let acmeChallengeServer = null;

function certExpiryDate(certPath) {
  try {
    const out = execSync(`openssl x509 -in "${certPath}" -noout -enddate`).toString();
    const m = out.match(/notAfter=(.+)/);
    return m ? new Date(m[1].trim()) : null;
  } catch (e) {
    return null;
  }
}

// Let's Encrypt всегда проверяет http-01 challenge именно на порту 80 (это
// не настраивается) — поэтому под это нужен отдельный слушатель, даже если
// сам сервер обычно работает на другом порту. Если порт занят или нет прав
// на него (не root) — тихо отступаем, ничего не ломая.
function startAcmeChallengeServer() {
  if (acmeChallengeServer) return Promise.resolve(true);
  return new Promise((resolve) => {
    const srv = http.createServer((req, res) => {
      const m = req.url.match(/^\/\.well-known\/acme-challenge\/([A-Za-z0-9_-]+)$/);
      if (m && acmeChallengeResponses.has(m[1])) {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end(acmeChallengeResponses.get(m[1]));
        return;
      }
      res.writeHead(404);
      res.end('not found');
    });
    srv.once('error', (e) => {
      console.log(`ℹ️  Автоматический доверенный HTTPS: порт 80 недоступен (${e.code}) — это нормально, если он занят или нет прав root. Самоподписанный сертификат продолжает работать как обычно.`);
      resolve(false);
    });
    srv.listen(80, '0.0.0.0', () => {
      acmeChallengeServer = srv;
      resolve(true);
    });
  });
}

function applyAcmeCert() {
  if (!httpsServer) return;
  try {
    httpsServer.setSecureContext({ key: fs.readFileSync(ACME_KEY_PATH), cert: fs.readFileSync(ACME_CERT_PATH) });
  } catch (e) {
    console.error('⚠️  Не удалось применить полученный доверенный сертификат:', e.message);
  }
}

async function tryAutoHttps() {
  if (process.env.ASTERIA_DISABLE_AUTO_HTTPS === '1') return;
  if (!httpsServer) return; // самоподписанный HTTPS не поднялся — обновлять нечего
  try {
    let domain = (process.env.PUBLIC_HOST || '').split(',')[0].trim() || null;
    if (!domain && /^\d{1,3}(\.\d{1,3}){3}$/.test(TURN_HOST || '')) {
      // Публичный IP уже определён (через STUN, см. startTurnServer) — своего
      // домена нет, заворачиваем через sslip.io, чтобы не просить админа
      // ничего покупать/настраивать вручную.
      domain = TURN_HOST.split('.').join('-') + '.sslip.io';
    } else if (domain && /^\d{1,3}(\.\d{1,3}){3}$/.test(domain)) {
      domain = domain.split('.').join('-') + '.sslip.io';
    }
    if (!domain || domain === 'localhost') {
      return; // нет публичного адреса — автоматический HTTPS тут просто не имеет смысла (локальная сеть)
    }

    if (fs.existsSync(ACME_CERT_PATH) && fs.existsSync(ACME_KEY_PATH)) {
      const expiry = certExpiryDate(ACME_CERT_PATH);
      if (expiry && (expiry.getTime() - Date.now()) > ACME_RENEW_BEFORE_MS) {
        applyAcmeCert();
        printTrustedUrlBanner(domain);
        return; // уже есть свежий сертификат — Let's Encrypt лишний раз не дёргаем
      }
    }

    const challengeServerUp = await startAcmeChallengeServer();
    if (!challengeServerUp) return;

    console.log(`🔒 Пытаюсь автоматически получить доверенный HTTPS-сертификат от Let's Encrypt для ${domain}…`);
    const { AcmeClient } = require('./lib/acme');
    const client = new AcmeClient({
      accountKeyPath: ACME_ACCOUNT_KEY_PATH,
      directoryUrl: process.env.ASTERIA_ACME_DIRECTORY_URL || undefined,
    });
    const { certPem, keyPem } = await client.obtainCertificate({
      domain,
      registerChallenge: (token, keyAuth) => acmeChallengeResponses.set(token, keyAuth),
      unregisterChallenge: (token) => acmeChallengeResponses.delete(token),
    });

    fs.mkdirSync(ACME_DIR, { recursive: true });
    fs.writeFileSync(ACME_CERT_PATH, certPem);
    fs.writeFileSync(ACME_KEY_PATH, keyPem);
    applyAcmeCert();
    printTrustedUrlBanner(domain);
  } catch (e) {
    console.log(`ℹ️  Не удалось автоматически получить доверенный HTTPS-сертификат (не критично — сервер продолжает работать на самоподписанном): ${e.message}`);
  }
}

// ВАЖНО: сертификат Let's Encrypt выписан на ИМЯ (домен/sslip.io), а не на
// голый IP-адрес — это принципиальное ограничение самого протокола ACME,
// обойти его нельзя. Значит, если открывать сервер по голому IP
// (https://46.8.227.207:3443), браузер по-прежнему будет считать соединение
// "незащищённым", даже когда сертификат настоящий и валидный — потому что
// имя в адресной строке не совпадает с именем в сертификате. Пользоваться
// нужно именно этим адресом — печатаем его отдельно и заметно, чтобы это
// было не потерять среди остальных строк лога.
function printTrustedUrlBanner(domain) {
  console.log('');
  console.log(`🔒✅ Доверенный адрес (без предупреждений браузера): https://${domain}:${HTTPS_PORT}`);
  console.log('   Раздавайте пользователям именно этот адрес — не голый IP. По голому IP');
  console.log('   браузер будет показывать "не защищено", даже с настоящим сертификатом:');
  console.log('   сертификат Let\'s Encrypt выписывается на имя, а не на IP-адрес.');
  console.log('');
}
// Первая попытка — после того как определён публичный адрес (см.
// startTurnServer ниже), дальше раз в сутки (заодно проверяет и продлевает
// истекающий сертификат).
setInterval(tryAutoHttps, 24 * 60 * 60 * 1000);

// ---------- TURN/STUN (нужен, чтобы звонки соединялись через интернет, а не только в LAN) ----------
// Секрет для выдачи временных TURN-креденшлов — генерируется один раз и
// хранится рядом с базой данных, как и остальные локальные данные сервера.
const TURN_SECRET_PATH = path.join(PERSIST_ROOT, 'turn-secret.txt');
function getOrCreateTurnSecret() {
  try {
    if (fs.existsSync(TURN_SECRET_PATH)) return fs.readFileSync(TURN_SECRET_PATH, 'utf8').trim();
  } catch (e) {}
  const secret = crypto.randomBytes(32).toString('hex');
  try {
    if (!fs.existsSync(path.dirname(TURN_SECRET_PATH))) fs.mkdirSync(path.dirname(TURN_SECRET_PATH), { recursive: true });
    fs.writeFileSync(TURN_SECRET_PATH, secret);
  } catch (e) {}
  return secret;
}
const TURN_SECRET = getOrCreateTurnSecret();
const TURN_PORT = Number(process.env.TURN_PORT) || 3478;
// Диапазон UDP-портов для РЕЛЕЯ медиапотока (не путать с TURN_PORT — тот
// только для служебных STUN/TURN-сообщений). Без него каждый звонок брал
// случайный порт от ОС, который невозможно заранее пробросить через
// файрвол/облако — из-за этого Allocate проходил успешно, а сам медиапоток
// снаружи не доходил, и звонок зависал на "checking"/"connecting". По
// умолчанию — небольшой фиксированный диапазон (100 портов, хватает на
// полсотни одновременных релей-соединений), который достаточно один раз
// пробросить наружу так же, как TURN_PORT. Можно переопределить
// переменными окружения TURN_RELAY_MIN_PORT / TURN_RELAY_MAX_PORT.
const TURN_RELAY_MIN_PORT = Number(process.env.TURN_RELAY_MIN_PORT) || 49160;
const TURN_RELAY_MAX_PORT = Number(process.env.TURN_RELAY_MAX_PORT) || 49260;
// Адрес, который сообщаем клиентам как адрес STUN/TURN-сервера. По умолчанию —
// первый локальный (не loopback) IP; если сервер стоит за NAT/в облаке, где
// внешний адрес отличается от адреса сетевого интерфейса, задайте его явно
// переменной окружения PUBLIC_HOST (например PUBLIC_HOST=messenger.example.com
// или PUBLIC_HOST=203.0.113.10). Иначе ниже пробуем определить его сами через STUN.
let TURN_HOST = process.env.PUBLIC_HOST || process.env.PUBLIC_IP || localAddrs()[0] || 'localhost';
let turnServerReady = null;

async function startTurnServer() {
  let publicIp = process.env.PUBLIC_HOST || process.env.PUBLIC_IP || null;
  if (!publicIp) {
    // Лучший эффорт: спрашиваем публичный STUN-сервер, какой у нас "снаружи"
    // виден адрес, и используем его и как TURN_HOST, и как relay-адрес.
    // Если интернета нет (чисто локальный запуск) — просто остаёмся на LAN IP.
    try {
      const discovered = await require('./lib/mini-turn').stunDiscover();
      if (discovered && discovered.address) {
        publicIp = discovered.address;
        TURN_HOST = discovered.address;
      }
    } catch (e) { /* offline/LAN — не страшно, останемся на локальном адресе */ }
  } else {
    TURN_HOST = publicIp;
  }
  try {
    await createTurnServer({
      secret: TURN_SECRET,
      port: TURN_PORT,
      publicIp,
      relayPortMin: TURN_RELAY_MIN_PORT,
      relayPortMax: TURN_RELAY_MAX_PORT,
      log: (m) => console.error('TURN:', m),
    });
    console.log(`🧊 TURN/STUN сервер запущен на порту ${TURN_PORT} (адрес для клиентов: ${TURN_HOST})`);

    // Лучший эффорт: сами пытаемся открыть нужные порты в файрволе ОС
    // (ufw/firewalld/iptables), чтобы звонки работали сразу, без ручного
    // "проброса портов" — самая частая причина, почему на свежем VPS всё
    // остальное работает, а звонки зависают. Если сервер работает без прав
    // root, или порты блокируются "снаружи" ОС (роутер дома / облачный
    // firewall провайдера) — это НЕ решить кодом внутри сервера, ниже будет
    // явное предупреждение об этом.
    const { autoOpenPorts } = require('./lib/firewall');
    const portRules = [
      { port: PORT, proto: 'tcp' },
      { port: HTTPS_PORT, proto: 'tcp' },
      { port: TURN_PORT, proto: 'udp' },
      { port: TURN_PORT, proto: 'tcp' },
      { portStart: TURN_RELAY_MIN_PORT, portEnd: TURN_RELAY_MAX_PORT, proto: 'udp' },
    ];
    const fw = autoOpenPorts(portRules, (m) => console.log('🔥 Файрвол:', m));
    if (fw.attempted) {
      console.log(`🔥 Файрвол: порты открыты автоматически через ${fw.tool}.`);
    } else {
      console.log('🔥 Файрвол: не удалось настроить автоматически (нет root или подходящего инструмента).');
      console.log(`   Откройте вручную (в панели хостинга или на сервере): ${PORT}/TCP, ${HTTPS_PORT}/TCP,`);
      console.log(`   ${TURN_PORT}/UDP+TCP, ${TURN_RELAY_MIN_PORT}-${TURN_RELAY_MAX_PORT}/UDP.`);
    }
    console.log('   Если сервер стоит дома за обычным Wi-Fi-роутером ИЛИ хостинг-провайдер держит');
    console.log('   отдельный "облачный" файрвол (AWS Security Group, DO/Timeweb Cloud Firewall и');
    console.log('   т.п.) — это отдельная настройка вне этого сервера, автоматически её не открыть,');
    console.log('   нужно один раз включить эти же порты в панели роутера/хостинга (см. README).');
  } catch (e) {
    console.error('⚠️  Не удалось запустить TURN/STUN сервер (звонки за пределами LAN могут не работать):', e.message);
  }
}
turnServerReady = startTurnServer();
turnServerReady.then(() => tryAutoHttps()).catch(() => {});

// ---------- Фоновое обслуживание: чистка неиспользуемого, экономия диска ----------
//
// На слабом сервере (мало ОЗУ, мало диска) особенно важно не копить мусор:
// удалённые сообщения/сторис раньше оставляли сами файлы (фото, видео,
// голосовые) на диске НАВСЕГДА, даже когда на них никто больше не
// ссылается. Здесь — разовая (при старте) и затем периодическая уборка.

// Свежие файлы (моложе этого времени) не трогаем НИКОГДА, даже если они
// пока ни на что не похожи — защита от гонки: файл мог только что
// загрузиться через /api/upload, а само сообщение с ссылкой на него ещё не
// успело долететь и сохраниться в базу.
const UPLOAD_ORPHAN_GRACE_MS = 24 * 60 * 60 * 1000; // 24 часа

// Собирает множество всех "/uploads/..." URL, которые ещё где-либо
// используются. messages — самая большая таблица, поэтому для неё берём
// только нужное поле (см. distinctFieldValues в lib/db.js), не поднимая в
// память сами сообщения. Остальные таблицы малы (ограничены числом
// пользователей/чатов/историй, а не сообщений) — грузить их целиком безопасно.
function collectNonMessageUploadUrls() {
  const urls = new Set();
  const add = (u) => { if (u && typeof u === 'string' && u.startsWith('/uploads/')) urls.add(u); };
  db.all('users').forEach((u) => { add(u.avatar); add(u.chatWallpaper); });
  db.all('conversations').forEach((c) => add(c.avatar));
  db.all('bots').forEach((b) => add(b.avatar));
  db.all('stories').forEach((s) => add(s.mediaUrl));
  const banner = readBanner();
  if (banner) add(banner.imageUrl);
  return urls;
}

function collectReferencedUploadUrls() {
  const urls = collectNonMessageUploadUrls();
  db.distinctFieldValues('messages', 'mediaUrl').forEach((u) => {
    if (u && typeof u === 'string' && u.startsWith('/uploads/')) urls.add(u);
  });
  return urls;
}

function sweepOrphanUploads() {
  try {
    const referenced = collectReferencedUploadUrls();
    const now = Date.now();
    let removedCount = 0;
    let removedBytes = 0;

    function walk(dir, urlPrefix) {
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        const url = urlPrefix + entry.name;
        if (entry.isDirectory()) { walk(fullPath, url + '/'); continue; }
        if (referenced.has(url)) continue;
        let st;
        try { st = fs.statSync(fullPath); } catch (e) { continue; }
        if (now - st.mtimeMs < UPLOAD_ORPHAN_GRACE_MS) continue; // слишком свежий — пропускаем на всякий случай
        try {
          fs.unlinkSync(fullPath);
          removedCount++;
          removedBytes += st.size;
        } catch (e) { /* не критично — попробуем в следующий раз */ }
      }
    }

    walk(UPLOADS_DIR, '/uploads/');
    if (removedCount > 0) {
      console.log(`🧹 Очистка загрузок: удалено ${removedCount} неиспользуемых файлов, освобождено ${(removedBytes / (1024 * 1024)).toFixed(1)} МБ.`);
    }
  } catch (e) {
    console.error('⚠️  Ошибка при очистке неиспользуемых загрузок (не критично):', e.message);
  }
}

// Просроченные сторис (по TTL) и так уже не показываются в /api/stories, но
// сами строки и файлы раньше оставались в базе навсегда — убираем и то, и
// другое, чтобы таблица stories и диск не росли бесконечно.
function sweepExpiredStories() {
  try {
    const now = Date.now();
    let removed = 0;
    db.all('stories').forEach((s) => {
      const author = db.findById('users', s.userId);
      const ttl = storyTtlMs(s, author);
      if (s.createdAt <= now - ttl) {
        db.remove('stories', s.id);
        if (s.mediaUrl) deleteUploadedFile(s.mediaUrl);
        removed++;
      }
    });
    if (removed > 0) console.log(`🧹 Убрано просроченных сторис: ${removed}.`);
  } catch (e) {
    console.error('⚠️  Ошибка при очистке просроченных сторис (не критично):', e.message);
  }
}

function runMaintenanceSweep() {
  sweepExpiredStories();
  sweepOrphanUploads();
  db.incrementalVacuum(500); // небольшими порциями возвращаем место от удалённого на диск
}

// Первый проход — через минуту после старта (не соревнуемся за диск/CPU с
// самим запуском сервера), дальше — раз в сутки. incrementalVacuum при этом
// дополнительно подёргиваем почаще (раз в час) небольшими порциями, чтобы
// место с диска освобождалось постепенно, а не одним долгим рывком раз в день.
setTimeout(runMaintenanceSweep, 60 * 1000);
setTimeout(runCallSweep, 90 * 1000);
setInterval(runCallSweep, 60 * 60 * 1000);
setInterval(runMaintenanceSweep, 24 * 60 * 60 * 1000);
setInterval(() => db.incrementalVacuum(200), 60 * 60 * 1000);

server.listen(PORT, '0.0.0.0', () => {
  const addrs = localAddrs();
  console.log('\n🚀 Asteria запущена!');
  console.log(`   Локально:      http://localhost:${PORT}`);
  addrs.forEach((a) => console.log(`   В сети (LAN):  http://${a}:${PORT}`));

  if (httpsServer) {
    httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
      console.log(`\n🔒 HTTPS (самоподписанный сертификат):`);
      console.log(`   Локально:      https://localhost:${HTTPS_PORT}`);
      addrs.forEach((a) => console.log(`   В сети (LAN):  https://${a}:${HTTPS_PORT}`));
      console.log('   При первом заходе браузер покажет предупреждение "Соединение не защищено" —');
      console.log('   это нормально для самоподписанного сертификата, нажмите "Дополнительно" → "Всё равно перейти".');
    });
  } else {
    console.log('\n💡 HTTPS не запущен: сертификат не найден. Чтобы включить HTTPS (нужно для звонков и');
    console.log('   микрофона/камеры на телефонах и не-localhost адресах), выполните один раз:');
    console.log('       node generate-cert.js');
    console.log('   и перезапустите сервер.');
  }

  console.log('\nОстановить сервер: Ctrl+C\n');
});
